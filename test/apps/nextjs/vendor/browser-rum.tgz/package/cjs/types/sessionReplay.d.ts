/**
 * DO NOT MODIFY IT BY HAND. Run `yarn json-schemas:sync` instead.
 */
/**
 * Browser-specific. Schema of a Session Replay data Segment.
 */
export type BrowserSegment = BrowserSegmentMetadata & {
    /**
     * The records contained by this Segment.
     */
    readonly records: BrowserRecord[];
};
/**
 * Browser-specific. Schema of a Session Replay Segment metadata.
 */
export type BrowserSegmentMetadata = SegmentContext & CommonSegmentMetadataSchema & {
    /**
     * The source of this record
     */
    source: 'browser';
    creation_reason: CreationReason;
};
/**
 * The reason this Segment was created. For mobile there is only one possible value for this, which is always the default value.
 */
export type CreationReason = 'init' | 'segment_duration_limit' | 'segment_bytes_limit' | 'view_change' | 'before_unload' | 'visibility_hidden' | 'page_frozen';
/**
 * Browser-specific. Schema of a Session Replay Record.
 */
export type BrowserRecord = BrowserFullSnapshotRecord | BrowserIncrementalSnapshotRecord | MetaRecord | FocusRecord | ViewEndRecord | VisualViewportRecord | FrustrationRecord | BrowserChangeRecord;
/**
 * Browser-specific. Schema of a Record type which contains the full snapshot of a screen.
 */
export type BrowserFullSnapshotRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 2;
    data: BrowserNode;
};
/**
 * Schema of common properties for a Record event type that is supported by slots.
 */
export type SlotSupportedCommonRecordSchema = CommonRecordSchema & {
    /**
     * Unique ID of the slot that generated this record.
     */
    readonly slotId?: string;
};
/**
 * Serialized node contained by this Record.
 */
export type SerializedNodeWithId = {
    id: number;
} & SerializedNode;
/**
 * Serialized node contained by this Record.
 */
export type SerializedNode = DocumentNode | DocumentFragmentNode | DocumentTypeNode | ElementNode | TextNode | CDataNode;
/**
 * Browser-specific. Schema of a Record type which contains mutations of a screen.
 */
export type BrowserIncrementalSnapshotRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 3;
    data: BrowserIncrementalData;
    id?: number;
};
/**
 * Browser-specific. Schema of a Session Replay IncrementalData type.
 */
export type BrowserIncrementalData = BrowserMutationData | MousemoveData | MouseInteractionData | ScrollData | InputData | MediaInteractionData | StyleSheetRuleData | ViewportResizeData | PointerInteractionData;
/**
 * Browser-specific. Schema of a MutationData.
 */
export type BrowserMutationData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 0;
} & BrowserMutationPayload;
/**
 * Browser-specific. Schema of a MutationPayload.
 */
export type BrowserMutationPayload = {
    /**
     * Contains the newly added nodes.
     */
    adds: AddedNodeMutation[];
    /**
     * Contains the removed nodes.
     */
    removes: RemovedNodeMutation[];
    /**
     * Contains the updated attribute mutations.
     */
    attributes: AttributeMutation[];
    /**
     * Contains the updated text mutations.
     */
    texts: TextMutation[];
};
/**
 * Browser-specific. Schema of a MouseInteractionData.
 */
export type MouseInteractionData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 2;
} & MouseInteraction;
/**
 * Browser-specific. Schema of a MouseInteraction.
 */
export type MouseInteraction = {
    /**
     * The type of MouseInteraction: 0=mouseup, 1=mousedown, 2=click, 3=contextmenu, 4=dblclick, 7=touchstart, 9=touchend
     */
    readonly type: 0 | 1 | 2 | 3 | 4 | 7 | 9;
    /**
     * Id for the target node for this MouseInteraction.
     */
    id: number;
    /**
     * X-axis coordinate for this MouseInteraction.
     */
    x: number;
    /**
     * Y-axis coordinate for this MouseInteraction.
     */
    y: number;
} | {
    /**
     * The type of MouseInteraction: 5=focus, 6=blur
     */
    readonly type: 5 | 6;
    /**
     * Id for the target node for this MouseInteraction.
     */
    id: number;
};
/**
 * Browser-specific. Schema of a ScrollData.
 */
export type ScrollData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 3;
} & ScrollPosition;
/**
 * Browser-specific. Schema of an InputData.
 */
export type InputData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 5;
    /**
     * Id for the target node for this InputData.
     */
    id: number;
} & InputState;
/**
 * Browser-specific. Schema of an InputState.
 */
export type InputState = {
    /**
     * Text value for this InputState.
     */
    text: string;
} | {
    /**
     * Checked state for this InputState.
     */
    isChecked: boolean;
};
/**
 * Browser-specific. Schema of a MediaInteractionData.
 */
export type MediaInteractionData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 7;
} & MediaInteraction;
/**
 * Browser-specific. Schema of a StyleSheetRuleData.
 */
export type StyleSheetRuleData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 8;
} & StyleSheetRule;
/**
 * Schema of a ViewportResizeData.
 */
export type ViewportResizeData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 4;
} & ViewportResizeDimension;
/**
 * Schema of a PointerInteractionData.
 */
export type PointerInteractionData = {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 9;
} & PointerInteraction;
/**
 * Schema of a Record which contains the screen properties.
 */
export type MetaRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 4;
    /**
     * The data contained by this record.
     */
    data: {
        /**
         * The width of the screen in pixels, normalized based on the device pixels per inch density (DPI). Example: if a device has a DPI = 2, the normalized width is the current width divided by 2.
         */
        width: number;
        /**
         * The height of the screen in pixels, normalized based on the device pixels per inch density (DPI). Example: if a device has a DPI = 2, the normalized height is the current height divided by 2.
         */
        height: number;
        /**
         * Browser-specific. URL of the view described by this record.
         */
        href?: string;
    };
};
/**
 * Schema of a Record type which contains focus information.
 */
export type FocusRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 6;
    data: {
        /**
         * Whether this screen has a focus or not. For now it will always be true for mobile.
         */
        readonly has_focus: boolean;
    };
};
/**
 * Schema of a Record which signifies that view lifecycle ended.
 */
export type ViewEndRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 7;
};
/**
 * Schema of a Record which signifies that the viewport properties have changed.
 */
export type VisualViewportRecord = SlotSupportedCommonRecordSchema & {
    data: {
        height: number;
        offsetLeft: number;
        offsetTop: number;
        pageLeft: number;
        pageTop: number;
        scale: number;
        width: number;
    };
    /**
     * The type of this Record.
     */
    readonly type: 8;
};
/**
 * Schema of a Record which signifies a collection of frustration signals.
 */
export type FrustrationRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 9;
    /**
     * Schema of a Session Replay FrustrationRecord data structure type.
     */
    data: {
        /**
         * Collection of frustration signal types.
         */
        frustrationTypes: ('rage_click' | 'error_click' | 'dead_click')[];
        /**
         * Collection of frustration signal event IDs.
         */
        recordIds: number[];
    };
};
/**
 * Browser-specific. Schema of a record type which represents changes using a compact encoding. (Experimental; subject to change.)
 */
export type BrowserChangeRecord = SlotSupportedCommonRecordSchema & {
    /**
     * The type of this Record.
     */
    readonly type: 12;
    data: Change[];
    id?: number;
};
/**
 * Browser-specific. Schema representing an individual change within a BrowserChangeData collection.
 */
export type Change = [0, ...AddStringChange[]] | [1, ...AddNodeChange[]] | [2, ...RemoveNodeChange[]] | [3, ...AttributeChange[]] | [4, ...TextChange[]] | [5, ...SizeChange[]] | [6, ...ScrollPositionChange[]] | [7, ...AddStyleSheetChange[]] | [8, ...AttachedStyleSheetsChange[]] | [9, ...MediaPlaybackStateChange[]] | [10, ...VisualViewportChange[]];
/**
 * Browser-specific. Schema representing the addition of a string to the string table.
 */
export type AddStringChange = string;
/**
 * Browser-specific. Schema representing the addition of a new node to the document.
 */
export type AddNodeChange = AddCDataSectionNodeChange | AddDocTypeNodeChange | AddDocumentNodeChange | AddDocumentFragmentNodeChange | AddElementNodeChange | AddShadowRootNodeChange | AddTextNodeChange;
/**
 * Schema representing the addition of a new #cdata-section node.
 *
 * @minItems 2
 */
export type AddCDataSectionNodeChange = [InsertionPoint, '#cdata-section' | StringReference];
/**
 * Browser-specific. Schema representing the insertion point of a node which is being added to the document.
 */
export type InsertionPoint = AppendChildInsertionPoint | InsertAfterPreviousInsertionPoint | InsertBeforeInsertionPoint | RootInsertionPoint;
/**
 * A positive integer insertion point. Inserting a node at positive integer N indicates that the new node's parent is the node with an id N lower than the new node, and that we should insert the new node at the end of its parent's child list, as if the DOM method appendChild() was being used.
 */
export type AppendChildInsertionPoint = number;
/**
 * A zero insertion point. Inserting a node at zero indicates that the new node should be inserted after the node with an id one lower than the new node, as if the DOM method after() is being used. Using a zero insertion point repeatedly is thus a quick way to insert a sequence of sibling elements.
 */
export type InsertAfterPreviousInsertionPoint = 0;
/**
 * A negative integer insertion point. Inserting a node at negative integer -N indicates that the new node's next sibling is the node with an id N lower than the new node, and that we should insert the new node before its next sibling, as if the DOM method insertBefore() was being used.
 */
export type InsertBeforeInsertionPoint = number;
/**
 * A null insertion point, indicating that the node should be inserted at the root of the document.
 */
export type RootInsertionPoint = null;
/**
 * Browser-specific. Schema representing a string, expressed as an index into the string table.
 */
export type StringReference = number;
/**
 * Schema representing the addition of a new #doctype node, using the format [#doctype, name, public ID, system ID].
 *
 * @minItems 5
 */
export type AddDocTypeNodeChange = [
    InsertionPoint,
    '#doctype' | StringReference,
    StringOrStringReference,
    StringOrStringReference,
    StringOrStringReference
];
/**
 * Browser-specific. Schema representing a string, either expressed as a literal or as an index into the string table.
 */
export type StringOrStringReference = string | StringReference;
/**
 * Schema representing the addition of a new #document node.
 *
 * @minItems 2
 */
export type AddDocumentNodeChange = [InsertionPoint, '#document' | StringReference];
/**
 * Schema representing the addition of a new #document-fragment node.
 *
 * @minItems 2
 */
export type AddDocumentFragmentNodeChange = [InsertionPoint, '#document-fragment' | StringReference];
/**
 * Schema representing the addition of a new element node.
 *
 * @minItems 2
 */
export type AddElementNodeChange = [InsertionPoint, string | StringReference, ...AttributeAssignment[]];
/**
 * Schema representing an assignment of a value to an attribute. The format is [name, value].
 *
 * @minItems 2
 */
export type AttributeAssignment = [StringOrStringReference, StringOrStringReference];
/**
 * Schema representing the addition of a new #shadow-root node.
 *
 * @minItems 2
 */
export type AddShadowRootNodeChange = [InsertionPoint, '#shadow-root' | StringReference];
/**
 * Schema representing the addition of a new #text node.
 *
 * @minItems 3
 */
export type AddTextNodeChange = [InsertionPoint, '#text' | StringReference, StringOrStringReference];
/**
 * Browser-specific. Schema representing the removal of a node from the document.
 */
export type RemoveNodeChange = number;
/**
 * Browser-specific. Schema representing a change to an node's attributes.
 *
 * @minItems 1
 */
export type AttributeChange = [NodeId, ...AttributeAssignmentOrDeletion[]];
/**
 * Browser-specific. Schema representing the ID of a DOM node.
 */
export type NodeId = number;
/**
 * Schema representing a change to an attribute, either by assignment of a new value or by deletion of the attribute.
 */
export type AttributeAssignmentOrDeletion = AttributeAssignment | AttributeDeletion;
/**
 * Schema representing the deletion of an attribute.
 *
 * @minItems 1
 */
export type AttributeDeletion = [StringOrStringReference];
/**
 * Browser-specific. Schema representing a change to the text content of a #text node.
 *
 * @minItems 2
 */
export type TextChange = [NodeId, StringOrStringReference];
/**
 * Browser-specific. Schema representing a change in an element's size.
 *
 * @minItems 3
 */
export type SizeChange = [NodeId, number, number];
/**
 * Browser-specific. Schema representing a scroll position change.
 *
 * @minItems 3
 */
export type ScrollPositionChange = [NodeId, number, number];
/**
 * Browser-specific. Schema representing the addition of a new stylesheet to the document.
 */
export type AddStyleSheetChange = StyleSheetSnapshot;
/**
 * Schema representing a snapshot of a CSS stylesheet.
 *
 * @minItems 1
 */
export type StyleSheetSnapshot = [StyleSheetRules] | [StyleSheetRules, StyleSheetMediaList] | [StyleSheetRules, StyleSheetMediaList, boolean];
/**
 * Schema representing a CSS stylesheet's rules, encoded either as a single string or as an array containing a separate string for each rule.
 */
export type StyleSheetRules = StringOrStringReference | StringOrStringReference[];
/**
 * If non-empty, the list of medias for which this stylesheet is active. Defaults to the empty list if not present.
 */
export type StyleSheetMediaList = StringOrStringReference[];
/**
 * Browser-specific. Schema representing a change to the stylesheets attached to a DOM node. For <link> or <style> elements, which use classic CSSOM APIs, at most one stylesheet can be attached. For #document, #document-fragment, or #shadow-root nodes, which use the `adoptedStyleSheets` API, any number of stylesheets can be attached.
 *
 * @minItems 1
 */
export type AttachedStyleSheetsChange = [NodeId, ...StyleSheetId[]];
/**
 * Browser-specific. Schema representing the ID of a stylesheet.
 */
export type StyleSheetId = number;
/**
 * Browser-specific. Schema representing a change to the playback state of the media associated with an <audio> or <video> element.
 *
 * @minItems 2
 */
export type MediaPlaybackStateChange = [NodeId, PlaybackStatePlaying | PlaybackStatePaused];
/**
 * A playback state indicating that the associated media is playing.
 */
export type PlaybackStatePlaying = 0;
/**
 * A playback state indicating that the associated media is paused.
 */
export type PlaybackStatePaused = 1;
/**
 * Browser-specific. Schema representing a change to the visual viewport, defined in terms of the web platform VisualViewport API.
 *
 * @minItems 7
 */
export type VisualViewportChange = [
    VisualViewportOffsetLeft,
    VisualViewportOffsetTop,
    VisualViewportPageLeft,
    VisualViewportPageTop,
    VisualViewportWidth,
    VisualViewportHeight,
    VisualViewportScale
];
/**
 * The offset of the left edge of the visual viewport from the left edge of the layout viewport in CSS pixels.
 */
export type VisualViewportOffsetLeft = number;
/**
 * The offset of the top edge of the visual viewport from the top edge of the layout viewport in CSS pixels.
 */
export type VisualViewportOffsetTop = number;
/**
 * The x coordinate of the visual viewport relative to the initial containing block origin of the top edge in CSS pixels.
 */
export type VisualViewportPageLeft = number;
/**
 * The y coordinate of the visual viewport relative to the initial containing block origin of the top edge in CSS pixels.
 */
export type VisualViewportPageTop = number;
/**
 * The width of the visual viewport in CSS pixels.
 */
export type VisualViewportWidth = number;
/**
 * The height of the visual viewport in CSS pixels.
 */
export type VisualViewportHeight = number;
/**
 * The pinch-zoom scaling factor applied to the visual viewport.
 */
export type VisualViewportScale = number;
/**
 * Schema of a Session Replay Segment context.
 */
export interface SegmentContext {
    /**
     * Application properties
     */
    application: {
        /**
         * UUID of the application
         */
        id: string;
    };
    /**
     * Session properties
     */
    session: {
        /**
         * UUID of the session
         */
        id: string;
    };
    /**
     * View properties
     */
    view: {
        /**
         * UUID of the view
         */
        id: string;
    };
}
/**
 * Schema of common properties for a Segment Metadata type.
 */
export interface CommonSegmentMetadataSchema {
    /**
     * The start UTC timestamp in milliseconds corresponding to the first record in the Segment data. Each timestamp is computed as the UTC interval since 00:00:00.000 01.01.1970.
     */
    start: number;
    /**
     * The end UTC timestamp in milliseconds corresponding to the last record in the Segment data. Each timestamp is computed as the UTC interval since 00:00:00.000 01.01.1970.
     */
    end: number;
    /**
     * The number of records in this Segment.
     */
    records_count: number;
    /**
     * The index of this Segment in the segments list that was recorded for this view ID. Starts from 0.
     */
    index_in_view?: number;
    /**
     * Whether this Segment contains a full snapshot record or not.
     */
    has_full_snapshot?: boolean;
}
/**
 * Schema of common properties for a Record event type.
 */
export interface CommonRecordSchema {
    /**
     * Defines the UTC time in milliseconds when this Record was performed.
     */
    timestamp: number;
}
/**
 * Schema of a Node type.
 */
export interface BrowserNode {
    node: SerializedNodeWithId;
    /**
     * Initial node offset position.
     */
    initialOffset: {
        /**
         * Top position offset for this node.
         */
        top: number;
        /**
         * Left position offset for this node.
         */
        left: number;
    };
}
/**
 * Schema of a Document Node.
 */
export interface DocumentNode {
    /**
     * The type of this Node.
     */
    readonly type: 0;
    /**
     * Stylesheet added dynamically
     */
    readonly adoptedStyleSheets?: StyleSheet[];
    childNodes: SerializedNodeWithId[];
}
/**
 * Browser-specific. Schema of a StyleSheet
 */
export interface StyleSheet {
    /**
     * CSS rules applied (rule.cssText)
     */
    cssRules: string[];
    /**
     * MediaList of the stylesheet
     */
    media?: string[];
    /**
     * Is the stylesheet disabled
     */
    disabled?: boolean;
}
/**
 * Schema of a Document FragmentNode.
 */
export interface DocumentFragmentNode {
    /**
     * The type of this Node.
     */
    readonly type: 11;
    /**
     * Stylesheet added dynamically
     */
    readonly adoptedStyleSheets?: StyleSheet[];
    /**
     * Is this node a shadow root or not
     */
    readonly isShadowRoot: boolean;
    childNodes: SerializedNodeWithId[];
}
/**
 * Schema of a Document Type Node.
 */
export interface DocumentTypeNode {
    /**
     * The type of this Node.
     */
    readonly type: 1;
    /**
     * Name for this DocumentType
     */
    name: string;
    /**
     * PublicId for this DocumentType
     */
    publicId: string;
    /**
     * SystemId for this DocumentType
     */
    systemId: string;
}
/**
 * Schema of an Element Node.
 */
export interface ElementNode {
    /**
     * The type of this Node.
     */
    readonly type: 2;
    /**
     * TagName for this Node
     */
    tagName: string;
    attributes: Attributes;
    childNodes: SerializedNodeWithId[];
    /**
     * Is this node a SVG instead of a HTML
     */
    isSVG?: true;
}
/**
 * Schema of an Attributes type.
 */
export interface Attributes {
    [k: string]: string | number | boolean;
}
/**
 * Schema of a Text Node.
 */
export interface TextNode {
    /**
     * The type of this Node.
     */
    readonly type: 3;
    /**
     * Text value for this Text Node
     */
    textContent: string;
    isStyle?: true;
}
/**
 * Schema of a CData Node.
 */
export interface CDataNode {
    /**
     * The type of this Node.
     */
    readonly type: 4;
    textContent: '';
}
/**
 * Schema of an AddedNodeMutation.
 */
export interface AddedNodeMutation {
    node: SerializedNodeWithId;
    /**
     * Id for the parent node for this AddedNodeMutation.
     */
    parentId: number;
    nextId: number | null;
    previousId?: number | null;
}
/**
 * Schema of a RemovedNodeMutation.
 */
export interface RemovedNodeMutation {
    /**
     * Id of the mutated node.
     */
    id: number;
    /**
     * Id for the parent node for this RemovedNodeMutation
     */
    parentId: number;
}
/**
 * Schema of an AttributeMutation.
 */
export interface AttributeMutation {
    /**
     * Id of the mutated node.
     */
    id: number;
    /**
     * Attributes for this AttributeMutation
     */
    attributes: {
        [k: string]: string | null;
    };
}
/**
 * Schema of a TextMutation.
 */
export interface TextMutation {
    /**
     * Id of the mutated node.
     */
    id: number;
    /**
     * Value for this TextMutation
     */
    value: null | string;
}
/**
 * Browser-specific. Schema of a MousemoveData.
 */
export interface MousemoveData {
    /**
     * The source of this type of incremental data.
     */
    readonly source: 1 | 6;
    /**
     * Positions reported for this MousemoveData.
     */
    positions: MousePosition[];
}
/**
 * Browser-specific. Schema of a MousePosition.
 */
export interface MousePosition {
    /**
     * X-axis coordinate for this MousePosition.
     */
    x: number;
    /**
     * Y-axis coordinate for this MousePosition.
     */
    y: number;
    /**
     * Id for the target node for this MousePosition.
     */
    id: number;
    /**
     * Observed time offset for this MousePosition.
     */
    timeOffset: number;
}
/**
 * Browser-specific. Schema of a ScrollPosition.
 */
export interface ScrollPosition {
    /**
     * Id for the target node for this ScrollPosition.
     */
    id: number;
    /**
     * X-axis coordinate for this ScrollPosition.
     */
    x: number;
    /**
     * Y-axis coordinate for this ScrollPosition.
     */
    y: number;
}
/**
 * Browser-specific. Schema of a MediaInteraction.
 */
export interface MediaInteraction {
    /**
     * Id for the target node for this MediaInteraction.
     */
    id: number;
    /**
     * The type of MediaInteraction.
     */
    readonly type: 0 | 1;
}
/**
 * Browser-specific. Schema of a StyleSheetRule.
 */
export interface StyleSheetRule {
    /**
     * Id of the owner node for this StyleSheetRule.
     */
    readonly id: number;
    /**
     * Rules added to this StyleSheetRule.
     */
    adds?: StyleSheetAddRule[];
    /**
     * Rules deleted from this StyleSheetRule.
     */
    removes?: StyleSheetDeleteRule[];
}
/**
 * Browser-specific. Schema of a StyleSheetAddRule.
 */
export interface StyleSheetAddRule {
    /**
     * Text content for this StyleSheetAddRule.
     */
    rule: string;
    /**
     * Index of this StyleSheetAddRule in its StyleSheet.
     */
    index?: number | number[];
}
/**
 * Browser-specific. Schema of a StyleSheetDeleteRule.
 */
export interface StyleSheetDeleteRule {
    /**
     * Index of this StyleSheetDeleteRule in its StyleSheet.
     */
    index: number | number[];
}
/**
 * Schema of a ViewportResizeDimension.
 */
export interface ViewportResizeDimension {
    /**
     * The new width of the screen in pixels, normalized based on the device pixels per inch density (DPI). Example: if a device has a DPI = 2, the width is divided by 2 to get a normalized width.
     */
    width: number;
    /**
     * The new height of the screen in pixels, normalized based on the device pixels per inch density (DPI). Example: if a device has a DPI = 2, the height is divided by 2 to get a normalized height.
     */
    height: number;
}
/**
 * Schema of a PointerInteraction.
 */
export interface PointerInteraction {
    /**
     * Schema of an PointerEventType
     */
    readonly pointerEventType: 'down' | 'up' | 'move';
    /**
     * Schema of an PointerType
     */
    readonly pointerType: 'mouse' | 'touch' | 'pen';
    /**
     * Id of the pointer of this PointerInteraction.
     */
    pointerId: number;
    /**
     * X-axis coordinate for this PointerInteraction.
     */
    x: number;
    /**
     * Y-axis coordinate for this PointerInteraction.
     */
    y: number;
}
