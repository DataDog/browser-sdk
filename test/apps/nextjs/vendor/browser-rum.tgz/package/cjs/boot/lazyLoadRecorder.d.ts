import type { startRecording } from './startRecording';
export declare function lazyLoadRecorder(): Promise<typeof startRecording | undefined>;
export declare function importRecorder(): Promise<typeof startRecording>;
