import type { RecorderApi } from '@datadog/browser-rum-core';
import type { StartRecording } from './postStartStrategy';
export declare function makeRecorderApi(loadRecorder: () => Promise<StartRecording | undefined>): RecorderApi;
