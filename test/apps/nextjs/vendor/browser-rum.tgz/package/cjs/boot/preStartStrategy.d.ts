import type { RumConfiguration } from '@datadog/browser-rum-core';
import type { Strategy } from './postStartStrategy';
export declare function createPreStartStrategy(): {
    strategy: Strategy;
    shouldStartImmediately: (configuration: RumConfiguration) => boolean;
};
