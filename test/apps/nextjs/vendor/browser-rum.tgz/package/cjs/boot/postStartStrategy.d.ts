import type { LifeCycle, RumConfiguration, RumSessionManager, StartRecordingOptions, ViewHistory } from '@datadog/browser-rum-core';
import type { Telemetry, DeflateEncoder } from '@datadog/browser-core';
import type { startRecording } from './startRecording';
export type StartRecording = typeof startRecording;
export declare const enum RecorderStatus {
    Stopped = 0,
    IntentToStart = 1,
    Starting = 2,
    Started = 3
}
export type RecorderInitEvent = {
    type: 'start';
    forced: boolean;
} | {
    type: 'document-ready';
} | {
    type: 'recorder-settled';
} | {
    type: 'aborted';
} | {
    type: 'deflate-encoder-load-failed';
} | {
    type: 'recorder-load-failed';
} | {
    type: 'succeeded';
};
export interface Strategy {
    start: (options?: StartRecordingOptions) => void;
    stop: () => void;
    isRecording: () => boolean;
    getSessionReplayLink: () => string | undefined;
}
export declare function createPostStartStrategy(configuration: RumConfiguration, lifeCycle: LifeCycle, sessionManager: RumSessionManager, viewHistory: ViewHistory, loadRecorder: () => Promise<StartRecording | undefined>, getOrCreateDeflateEncoder: () => DeflateEncoder | undefined, telemetry: Telemetry): Strategy;
