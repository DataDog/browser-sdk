import type { HttpRequest, DeflateEncoder, Telemetry } from '@datadog/browser-core';
import type { LifeCycle, ViewHistory, RumConfiguration, RumSessionManager } from '@datadog/browser-rum-core';
import type { ReplayPayload } from '../domain/segmentCollection';
export declare function startRecording(lifeCycle: LifeCycle, configuration: RumConfiguration, sessionManager: RumSessionManager, viewHistory: ViewHistory, encoder: DeflateEncoder, telemetry: Telemetry, httpRequest?: HttpRequest<ReplayPayload>): {
    stop: () => void;
};
