import type { createRumProfiler } from '../domain/profiling/profiler';
export declare function lazyLoadProfiler(): Promise<typeof createRumProfiler | undefined>;
export declare function importProfiler(): Promise<typeof createRumProfiler>;
