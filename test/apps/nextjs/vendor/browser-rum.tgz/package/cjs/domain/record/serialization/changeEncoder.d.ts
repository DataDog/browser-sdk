import type { Change } from '../../../types';
import { ChangeType } from '../../../types';
import type { StringIds } from '../itemIds';
type ChangeData<T extends ChangeType> = Extract<Change, [T, ...unknown[]]> extends [T, ...infer Rest] ? Rest[number] : never;
/**
 * ChangeEncoder handles the low-level work of building compact, optimized sequences of
 * Changes. In particular, it:
 * - Converts literal strings to string table references, to eliminate the duplication
 * of transferring the same strings repeatedly.
 * - Groups changes by type, instead of transmitting them strictly in order, so that we
 * can avoid transmitting a separate Change data structure with an independent type tag
 * for each small mutation. (It's safe to do this for changes that occur within the same
 * SerializationTransaction since they logically happen at the same time.)
 */
export interface ChangeEncoder {
    /** Encode a Change of the given type and add it to the internal buffer. */
    add<T extends ChangeType>(type: T, data: ChangeData<T>): void;
    /** Flush the internal buffer, returning all Changes added since the last flush(). */
    flush(): Change[];
}
export declare function createChangeEncoder(stringIds: StringIds): ChangeEncoder;
export {};
