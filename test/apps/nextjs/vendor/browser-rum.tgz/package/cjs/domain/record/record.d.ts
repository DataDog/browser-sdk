import type { LifeCycle, RumConfiguration, ViewHistory } from '@datadog/browser-rum-core';
import type { ShadowRootsController } from './shadowRootsController';
import type { EmitRecordCallback, EmitStatsCallback } from './record.types';
export interface RecordOptions {
    emitRecord: EmitRecordCallback;
    emitStats: EmitStatsCallback;
    configuration: RumConfiguration;
    lifeCycle: LifeCycle;
    viewHistory: ViewHistory;
}
export interface RecordAPI {
    stop: () => void;
    flushMutations: () => void;
    shadowRootsController: ShadowRootsController;
}
export declare function record(options: RecordOptions): RecordAPI;
