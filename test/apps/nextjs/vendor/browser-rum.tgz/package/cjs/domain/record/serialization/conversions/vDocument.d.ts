import type { BrowserFullSnapshotRecord, BrowserIncrementalSnapshotRecord } from '../../../../types';
import type { NodeId, StyleSheetId } from '../../itemIds';
import type { MutationLog } from './mutationLog';
import type { V1RenderOptions } from './renderOptions';
import type { VNode, VNodeData } from './vNode';
import type { VStyleSheet, VStyleSheetData } from './vStyleSheet';
export interface VDocument {
    createNode(data: VNodeData): VNode;
    getNodeById(id: NodeId): VNode;
    createStyleSheet(data: VStyleSheetData): VStyleSheet;
    getStyleSheetById(id: StyleSheetId): VStyleSheet;
    onAttributeChanged(node: VNode, name: string): void;
    onNodeConnected(node: VNode, parent: VNode | undefined): void;
    onNodeDisconnected(node: VNode, parent: VNode | undefined): void;
    onTextChanged(node: VNode): void;
    get mutations(): MutationLog;
    naturalRendering(): BrowserFullSnapshotRecord['type'] | BrowserIncrementalSnapshotRecord['type'];
    render(options?: Partial<V1RenderOptions>): BrowserFullSnapshotRecord | BrowserIncrementalSnapshotRecord;
    renderAsFullSnapshot(options?: Partial<V1RenderOptions>): BrowserFullSnapshotRecord;
    renderAsIncrementalSnapshot(options?: Partial<V1RenderOptions>): BrowserIncrementalSnapshotRecord;
    root: VNode | undefined;
}
export declare function createVDocument(): VDocument;
