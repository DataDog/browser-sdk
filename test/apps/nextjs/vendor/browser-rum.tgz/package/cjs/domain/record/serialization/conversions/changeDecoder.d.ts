import type { BrowserChangeRecord } from '../../../../types';
import type { StringTable } from './stringTable';
/**
 * ChangeDecoder converts a BrowserChangeRecord, or a stream of BrowserChangeRecords, into
 * a more human-readable form by:
 * - Removing AddString changes (string table definitions).
 * - Replacing string table references in all other changes with their literal values.
 *
 * This makes it easier to visualize the contents of BrowserChangeRecords or to write test
 * expectations against the record's content.
 */
export interface ChangeDecoder {
    decode(record: BrowserChangeRecord): BrowserChangeRecord;
    stringTable: StringTable;
}
export declare function createChangeDecoder(): ChangeDecoder;
