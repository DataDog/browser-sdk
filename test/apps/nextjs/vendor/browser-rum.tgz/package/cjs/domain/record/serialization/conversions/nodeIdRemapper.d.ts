import type { NodeId, NodeIds } from '../../itemIds';
export interface NodeIdRemapper {
    remap(inputNodeId: NodeId): NodeId;
}
export declare function createIdentityNodeIdRemapper(): NodeIdRemapper;
export interface CopyingNodeIdRemapper extends NodeIdRemapper {
    inputNodeIds: NodeIds;
    outputNodeIds: NodeIds;
}
export declare function createCopyingNodeIdRemapper(): CopyingNodeIdRemapper;
