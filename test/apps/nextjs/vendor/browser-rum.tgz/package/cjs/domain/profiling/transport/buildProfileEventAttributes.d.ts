import type { BrowserProfilerTrace } from '../../../types';
export interface ProfileEventAttributes {
    application: {
        id: string;
    };
    session?: {
        id: string;
    };
    view?: {
        id: string[];
        name: string[];
    };
    long_task?: {
        id: string[];
    };
    action?: {
        id: string[];
        label: string[];
    };
    vital?: {
        id: string[];
        label: string[];
    };
}
/**
 * Builds attributes for the Profile Event.
 *
 * @param profilerTrace - Profiler trace
 * @param applicationId - application id.
 * @param sessionId - session id.
 * @returns Additional attributes.
 */
export declare function buildProfileEventAttributes(profilerTrace: BrowserProfilerTrace, applicationId: string, sessionId: string | undefined): ProfileEventAttributes;
