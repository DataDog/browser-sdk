import type { RumConfiguration, RumSessionManager, ViewHistory } from '@datadog/browser-rum-core';
export declare function getSessionReplayLink(configuration: RumConfiguration, sessionManager: RumSessionManager, viewHistory: ViewHistory, isRecordingStarted: boolean): string | undefined;
