import type { FocusRecord } from '../../../types';
import type { RecordingScope } from '../recordingScope';
import type { EmitRecordCallback } from '../record.types';
import type { Tracker } from './tracker.types';
export declare function trackFocus(emitRecord: EmitRecordCallback<FocusRecord>, scope: RecordingScope): Tracker;
