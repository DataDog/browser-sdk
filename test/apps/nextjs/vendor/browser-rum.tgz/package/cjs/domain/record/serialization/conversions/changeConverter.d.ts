import type { BrowserChangeRecord, BrowserFullSnapshotRecord, BrowserIncrementalSnapshotRecord } from '../../../../types';
import type { V1RenderOptions } from './renderOptions';
import type { StringTable } from './stringTable';
import type { VDocument } from './vDocument';
export interface ChangeConverter {
    convert(record: BrowserChangeRecord, options?: Partial<V1RenderOptions>): BrowserFullSnapshotRecord | BrowserIncrementalSnapshotRecord;
    document: VDocument;
    stringTable: StringTable;
}
export declare function createChangeConverter(): ChangeConverter;
