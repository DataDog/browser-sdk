export declare function getDefaultViewName(viewPathUrl: string): string;
