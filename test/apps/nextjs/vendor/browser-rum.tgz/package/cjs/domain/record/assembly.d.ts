import type { TimeStamp } from '@datadog/browser-core';
import type { BrowserIncrementalData, BrowserIncrementalSnapshotRecord } from '../../types';
export declare function assembleIncrementalSnapshot<Data extends BrowserIncrementalData>(source: Data['source'], data: Omit<Data, 'source'>, timestamp?: TimeStamp): BrowserIncrementalSnapshotRecord;
