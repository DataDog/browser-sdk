import type { ClocksState, Duration } from '@datadog/browser-core';
import type { LifeCycle } from '@datadog/browser-rum-core';
export declare const VITAL_ID_HISTORY_TIME_OUT_DELAY: number;
export interface VitalContext {
    id: string;
    label: string;
    duration?: Duration;
    startClocks: ClocksState;
}
export declare function createVitalHistory(lifeCycle: LifeCycle): import("@datadog/browser-core").ValueHistory<VitalContext>;
