import { NodePrivacyLevel } from '@datadog/browser-rum-core';
import type { RumConfiguration } from '@datadog/browser-rum-core';
export declare const MAX_ATTRIBUTE_VALUE_CHAR_LENGTH = 1000000;
export declare function serializeAttribute(element: Element, nodePrivacyLevel: NodePrivacyLevel, attributeName: string, configuration: RumConfiguration): string | null;
