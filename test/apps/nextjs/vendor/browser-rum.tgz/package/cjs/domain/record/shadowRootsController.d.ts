import type { RecordingScope } from './recordingScope.ts';
import type { EmitRecordCallback, EmitStatsCallback } from './record.types';
export type AddShadowRootCallBack = (shadowRoot: ShadowRoot, scope: RecordingScope) => void;
export type RemoveShadowRootCallBack = (shadowRoot: ShadowRoot) => void;
export interface ShadowRootsController {
    addShadowRoot: AddShadowRootCallBack;
    removeShadowRoot: RemoveShadowRootCallBack;
    stop: () => void;
    flush: () => void;
}
export declare const initShadowRootsController: (emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback) => ShadowRootsController;
