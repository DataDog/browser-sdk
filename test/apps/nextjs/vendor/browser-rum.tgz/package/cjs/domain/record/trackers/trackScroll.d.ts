import type { BrowserIncrementalSnapshotRecord } from '../../../types';
import type { RecordingScope } from '../recordingScope';
import type { EmitRecordCallback } from '../record.types';
import type { Tracker } from './tracker.types';
export declare function trackScroll(target: Document | ShadowRoot, emitRecord: EmitRecordCallback<BrowserIncrementalSnapshotRecord>, scope: RecordingScope): Tracker;
