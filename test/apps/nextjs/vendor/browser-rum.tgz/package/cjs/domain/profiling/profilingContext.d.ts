import type { Hooks, ProfilingInternalContextSchema } from '@datadog/browser-rum-core';
export interface ProfilingContextManager {
    set: (next: ProfilingInternalContextSchema) => void;
    get: () => ProfilingInternalContextSchema | undefined;
}
export declare function startProfilingContext(hooks: Hooks): ProfilingContextManager;
