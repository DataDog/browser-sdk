import type { ClocksState, Duration } from '@datadog/browser-core';
import type { LifeCycle } from '@datadog/browser-rum-core';
export declare const ACTION_ID_HISTORY_TIME_OUT_DELAY: number;
export interface ActionContext {
    id: string;
    label: string;
    duration?: Duration;
    startClocks: ClocksState;
}
export declare function createActionHistory(lifeCycle: LifeCycle): import("@datadog/browser-core").ValueHistory<ActionContext>;
