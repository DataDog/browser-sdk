import type { RumMutationRecord } from '@datadog/browser-rum-core';
import type { TimeStamp } from '@datadog/browser-core';
import type { RecordingScope } from '../recordingScope';
import type { EmitRecordCallback, EmitStatsCallback } from '../record.types';
import type { NodeIds } from '../itemIds';
export type NodeWithSerializedNode = Node & {
    __brand: 'NodeWithSerializedNode';
};
export declare function serializeMutations(timestamp: TimeStamp, mutations: RumMutationRecord[], emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback, scope: RecordingScope): void;
export declare function sortAddedAndMovedNodes(nodes: Node[]): void;
export declare function idsAreAssignedForNodeAndAncestors(node: Node, nodeIds: NodeIds): node is NodeWithSerializedNode;
