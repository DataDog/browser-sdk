import type { DeflateEncoder, HttpRequest } from '@datadog/browser-core';
import type { LifeCycle, ViewHistory, RumSessionManager, RumConfiguration } from '@datadog/browser-rum-core';
import type { BrowserRecord, SegmentContext } from '../../types';
import type { SerializationStats } from '../record';
import type { ReplayPayload } from './buildReplayPayload';
export declare const SEGMENT_DURATION_LIMIT: number;
/**
 * beacon payload max queue size implementation is 64kb
 * ensure that we leave room for logs, rum and potential other users
 */
export declare let SEGMENT_BYTES_LIMIT: number;
interface SegmentCollector {
    addRecord(this: void, record: BrowserRecord): void;
    addStats(this: void, stats: SerializationStats): void;
    stop(this: void): void;
}
export declare function startSegmentCollection(lifeCycle: LifeCycle, configuration: RumConfiguration, sessionManager: RumSessionManager, viewHistory: ViewHistory, httpRequest: HttpRequest<ReplayPayload>, encoder: DeflateEncoder): SegmentCollector;
export declare function doStartSegmentCollection(lifeCycle: LifeCycle, getSegmentContext: () => SegmentContext | undefined, httpRequest: HttpRequest<ReplayPayload>, encoder: DeflateEncoder): SegmentCollector;
export declare function computeSegmentContext(applicationId: string, sessionManager: RumSessionManager, viewHistory: ViewHistory): {
    application: {
        id: string;
    };
    session: {
        id: string;
    };
    view: {
        id: string;
    };
} | undefined;
export declare function setSegmentBytesLimit(newSegmentBytesLimit?: number): void;
export {};
