import type { Encoder } from '@datadog/browser-core';
import { DeflateEncoderStreamId } from '@datadog/browser-core';
import type { LifeCycle, RumConfiguration, RumSessionManager, ViewHistory } from '@datadog/browser-rum-core';
import type { RUMProfiler, RUMProfilerConfiguration } from './types';
import type { ProfilingContextManager } from './profilingContext';
export declare const DEFAULT_RUM_PROFILER_CONFIGURATION: RUMProfilerConfiguration;
export declare function createRumProfiler(configuration: RumConfiguration, lifeCycle: LifeCycle, session: RumSessionManager, profilingContextManager: ProfilingContextManager, createEncoder: (streamId: DeflateEncoderStreamId) => Encoder, viewHistory: ViewHistory, profilerConfiguration?: RUMProfilerConfiguration): RUMProfiler;
