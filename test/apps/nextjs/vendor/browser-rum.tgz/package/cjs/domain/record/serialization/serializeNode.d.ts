import type { DocumentNode, SerializedNodeWithId, ElementNode } from '../../../types';
import type { ParentNodePrivacyLevel } from './serialization.types';
import type { SerializationTransaction } from './serializationTransaction';
export declare function serializeNode(node: Element, parentNodePrivacyLevel: ParentNodePrivacyLevel, transaction: SerializationTransaction): (SerializedNodeWithId & ElementNode) | null;
export declare function serializeNode(node: Node, parentNodePrivacyLevel: ParentNodePrivacyLevel, transaction: SerializationTransaction): SerializedNodeWithId | null;
export declare function serializeChildNodes(node: Node, parentNodePrivacyLevel: ParentNodePrivacyLevel, transaction: SerializationTransaction): SerializedNodeWithId[];
export declare function serializeDocumentNode(document: Document, parentNodePrivacyLevel: ParentNodePrivacyLevel, transaction: SerializationTransaction): DocumentNode & SerializedNodeWithId;
