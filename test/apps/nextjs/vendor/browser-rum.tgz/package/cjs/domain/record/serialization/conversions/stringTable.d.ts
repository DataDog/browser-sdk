export interface StringTable {
    add(newString: string): void;
    decode(stringOrStringId: number | string): string;
}
export declare function createStringTable(): StringTable;
