import type { HttpRequestEvent, Observable, Telemetry } from '@datadog/browser-core';
import { noop } from '@datadog/browser-core';
import type { ReplayPayload } from './buildReplayPayload';
export declare function startSegmentTelemetry(telemetry: Telemetry, requestObservable: Observable<HttpRequestEvent<ReplayPayload>>): {
    stop: typeof noop;
};
