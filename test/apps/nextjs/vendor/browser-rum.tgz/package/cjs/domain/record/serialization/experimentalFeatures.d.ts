export declare function isFullSnapshotChangeRecordsEnabled(): boolean;
export declare function isIncrementalSnapshotChangeRecordsEnabled(): boolean;
