import type { ViewHistory } from '@datadog/browser-rum-core';
import type { BrowserRecord } from '../types';
export declare function startRecordBridge(viewHistory: ViewHistory): {
    addRecord: (record: BrowserRecord) => void;
};
