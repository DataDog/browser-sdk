import type { StyleSheet } from '../../../types';
import type { SerializationTransaction } from './serializationTransaction';
export declare function serializeStyleSheets(cssStyleSheets: CSSStyleSheet[] | undefined, transaction: SerializationTransaction): StyleSheet[] | undefined;
