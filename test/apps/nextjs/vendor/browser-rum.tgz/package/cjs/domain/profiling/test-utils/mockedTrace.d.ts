import type { ProfilerTrace } from '../types';
export declare const mockedEmptyTrace: ProfilerTrace;
export declare const mockedTrace: ProfilerTrace;
