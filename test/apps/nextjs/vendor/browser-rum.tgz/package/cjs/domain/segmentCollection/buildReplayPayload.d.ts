import type { Payload, Uint8ArrayBuffer } from '@datadog/browser-core';
import type { BrowserSegmentMetadata } from '../../types';
import type { SerializationMetric, SerializationStats } from '../record';
export type BrowserSegmentMetadataAndSegmentSizes = BrowserSegmentMetadata & {
    raw_segment_size: number;
    compressed_segment_size: number;
};
export type ReplayPayload = Payload & {
    cssText: SerializationMetric;
    isFullSnapshot: boolean;
    rawSize: number;
    recordCount: number;
    serializationDuration: SerializationMetric;
};
export declare function buildReplayPayload(data: Uint8ArrayBuffer, metadata: BrowserSegmentMetadata, stats: SerializationStats, rawSegmentBytesCount: number): ReplayPayload;
