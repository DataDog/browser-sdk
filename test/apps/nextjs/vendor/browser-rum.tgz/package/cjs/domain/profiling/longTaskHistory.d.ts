import type { ClocksState, Duration } from '@datadog/browser-core';
import type { LifeCycle } from '@datadog/browser-rum-core';
import { RumPerformanceEntryType } from '@datadog/browser-rum-core';
export declare const LONG_TASK_ID_HISTORY_EXPIRE_DELAY: number;
export interface LongTaskContext {
    id: string;
    startClocks: ClocksState;
    duration: Duration;
    entryType: RumPerformanceEntryType.LONG_ANIMATION_FRAME | RumPerformanceEntryType.LONG_TASK;
}
export declare function createLongTaskHistory(lifeCycle: LifeCycle): import("@datadog/browser-core").ValueHistory<LongTaskContext>;
