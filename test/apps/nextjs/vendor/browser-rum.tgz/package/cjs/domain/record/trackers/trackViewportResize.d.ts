import type { BrowserIncrementalSnapshotRecord, VisualViewportRecord } from '../../../types';
import type { EmitRecordCallback } from '../record.types';
import type { RecordingScope } from '../recordingScope';
import type { Tracker } from './tracker.types';
export declare function trackViewportResize(emitRecord: EmitRecordCallback<BrowserIncrementalSnapshotRecord>, scope: RecordingScope): Tracker;
export declare function trackVisualViewportResize(emitRecord: EmitRecordCallback<VisualViewportRecord>, scope: RecordingScope): Tracker;
