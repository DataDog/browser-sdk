import type { BrowserIncrementalSnapshotRecord } from '../../../types';
import type { EmitRecordCallback } from '../record.types';
import type { RecordingScope } from '../recordingScope';
import type { Tracker } from './tracker.types';
export declare function trackMediaInteraction(emitRecord: EmitRecordCallback<BrowserIncrementalSnapshotRecord>, scope: RecordingScope): Tracker;
