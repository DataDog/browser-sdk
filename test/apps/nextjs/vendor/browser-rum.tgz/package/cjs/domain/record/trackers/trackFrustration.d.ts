import type { LifeCycle } from '@datadog/browser-rum-core';
import type { FrustrationRecord } from '../../../types';
import type { EmitRecordCallback } from '../record.types';
import type { RecordingScope } from '../recordingScope';
import type { Tracker } from './tracker.types';
export declare function trackFrustration(lifeCycle: LifeCycle, emitRecord: EmitRecordCallback<FrustrationRecord>, scope: RecordingScope): Tracker;
