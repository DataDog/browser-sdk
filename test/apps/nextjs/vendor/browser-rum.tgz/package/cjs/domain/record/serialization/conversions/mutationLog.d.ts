import type { NodeId } from '../../itemIds';
type ParentNodeId = NodeId;
export interface MutationLog {
    onAttributeChanged(nodeId: NodeId, name: string): void;
    onNodeConnected(nodeId: NodeId): void;
    onNodeDisconnected(nodeId: NodeId, parentId: ParentNodeId): void;
    onTextChanged(nodeId: NodeId): void;
    clear(): void;
    attributeChanges: Map<NodeId, Set<string>>;
    nodeAdds: Set<NodeId>;
    nodeRemoves: Map<NodeId, ParentNodeId>;
    textChanges: Set<NodeId>;
}
export declare function createMutationLog(): MutationLog;
export {};
