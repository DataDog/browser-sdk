import type { RecordingScope } from './recordingScope';
/**
 * SerializationVerifier compares the output of the V1 and Change serialization
 * algorithms. It's designed to seamlessly add verification to existing test suites which
 * are written against the V1 serialization algorithm.
 *
 * To use it, create a SerializationVerifier configured with the same RecordingScope used
 * by the current test. The SerializationVerifier will automatically listen for V1
 * serializations being performed by the test code and will perform the corresponding
 * Change serialization. It will then convert the resulting BrowserChangeRecord to the old
 * V1 format and compare the results to verify that the two algorithms produce the same
 * output.
 */
export interface SerializationVerifier {
    stop(this: void): void;
}
export type OnVerificationError = (message: string, context?: any) => void;
export declare function createSerializationVerifier(scope: RecordingScope, onError: OnVerificationError): SerializationVerifier;
