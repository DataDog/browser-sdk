import type { NodePrivacyLevel } from '@datadog/browser-rum-core';
/**
 * Get the element "value" to be serialized as an attribute or an input update record. It respects
 * the input privacy mode of the element.
 * PERFROMANCE OPTIMIZATION: Assumes that privacy level `HIDDEN` is never encountered because of earlier checks.
 */
export declare function getElementInputValue(element: Element, nodePrivacyLevel: NodePrivacyLevel): string | undefined;
export declare const URL_IN_CSS_REF: RegExp;
export declare const ABSOLUTE_URL: RegExp;
export declare const DATA_URI: RegExp;
export declare function switchToAbsoluteUrl(cssText: string, cssHref: string | null): string;
export declare function getValidTagName(tagName: string): string;
/**
 * Returns the tag name of the given element, normalized to ensure a consistent lowercase
 * representation regardless of whether the element is HTML, XHTML, or SVG.
 */
export declare function normalizedTagName(element: Element): string;
export declare function censoredImageForSize(width: number, height: number): string;
