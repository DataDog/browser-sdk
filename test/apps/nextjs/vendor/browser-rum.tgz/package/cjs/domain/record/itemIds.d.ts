export type EventId = number & {
    __brand: 'EventId';
};
export type EventIds = ItemIds<Event, EventId>;
export declare const enum EventIdConstants {
    FIRST_ID = 1
}
export declare function createEventIds(): EventIds;
export type NodeId = number & {
    __brand: 'NodeId';
};
export type NodeIds = ItemIds<Node, NodeId>;
export declare const enum NodeIdConstants {
    FIRST_ID = 0
}
export declare function createNodeIds(): NodeIds;
export type StringId = number & {
    __brand: 'StringId';
};
export type StringIds = ItemIds<string, StringId>;
export declare const enum StringIdConstants {
    FIRST_ID = 0
}
export declare function createStringIds(): StringIds;
export type StyleSheetId = number & {
    __brand: 'StyleSheetId';
};
export type StyleSheetIds = ItemIds<CSSStyleSheet, StyleSheetId>;
export declare const enum StyleSheetIdConstants {
    FIRST_ID = 0
}
export declare function createStyleSheetIds(): StyleSheetIds;
export interface ItemIds<ItemType, ItemId extends number> {
    clear(this: void): void;
    delete(this: void, item: ItemType): void;
    get(this: void, item: ItemType): ItemId | undefined;
    getOrInsert(this: void, item: ItemType): ItemId;
    get nextId(): ItemId;
    get size(): number;
}
