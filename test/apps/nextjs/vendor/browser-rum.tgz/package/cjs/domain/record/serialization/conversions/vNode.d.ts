import type { SerializedNodeWithId } from '../../../../types';
import { PlaybackState } from '../../../../types';
import type { NodeId } from '../../itemIds';
import type { V1RenderOptions } from './renderOptions';
import type { VDocument } from './vDocument';
import type { VStyleSheet } from './vStyleSheet';
export interface VNode {
    after(node: VNode): void;
    appendChild(node: VNode): void;
    before(node: VNode): void;
    remove(): void;
    setAttachedStyleSheets(sheets: VStyleSheet[]): void;
    setAttribute(name: string, value: string | null): void;
    setPlaybackState(state: PlaybackState): void;
    setScrollPosition(left: number, top: number): void;
    setSize(width: number, height: number): void;
    setTextContent(value: string): void;
    forEachAddedNodeRoot(nodeAdds: Set<NodeId>, action: (node: VNode) => void): void;
    forSelfAndEachDescendant(action: (node: VNode) => void): void;
    mapChildren<Result>(action: (node: VNode) => Result): Result[];
    render(options: V1RenderOptions): SerializedNodeWithId;
    get data(): VNodeData;
    get id(): NodeId;
    get ownerDocument(): VDocument;
    state: VNodeState;
    firstChild: VNode | undefined;
    lastChild: VNode | undefined;
    previousSibling: VNode | undefined;
    nextSibling: VNode | undefined;
    parent: VNode | undefined;
}
export type VNodeState = 'new' | 'connected' | 'disconnected';
export type VNodeData = {
    kind: '#cdata-section';
} | {
    kind: '#document';
    attachedStyleSheets?: VStyleSheet[] | undefined;
    scrollLeft?: number;
    scrollTop?: number;
} | {
    kind: '#doctype';
    name: string;
    publicId: string;
    systemId: string;
} | {
    kind: '#document-fragment';
    attachedStyleSheets?: VStyleSheet[] | undefined;
} | {
    kind: '#element';
    tag: string;
    attachedStyleSheets?: VStyleSheet[] | undefined;
    attributes: Record<string, string>;
    isSVG?: boolean;
    playbackState?: PlaybackState;
    scrollLeft?: number;
    scrollTop?: number;
    width?: number;
    height?: number;
} | {
    kind: '#shadow-root';
    attachedStyleSheets?: VStyleSheet[] | undefined;
} | {
    kind: '#text';
    textContent: string;
};
export declare function createVNode(document: VDocument, id: NodeId, data: VNodeData): VNode;
