import type { LifeCycle } from '@datadog/browser-rum-core';
import type { TimeStamp } from '@datadog/browser-core';
import { SerializationKind } from './serialization';
import type { RecordingScope } from './recordingScope';
import type { EmitRecordCallback, EmitStatsCallback } from './record.types';
export type SerializeFullSnapshotCallback = (timestamp: TimeStamp, kind: SerializationKind, document: Document, emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback, scope: RecordingScope) => void;
export declare function startFullSnapshots(lifeCycle: LifeCycle, emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback, flushMutations: () => void, scope: RecordingScope, serialize?: SerializeFullSnapshotCallback): {
    stop: () => void;
};
export declare function takeFullSnapshot(timestamp: TimeStamp, kind: SerializationKind, emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback, scope: RecordingScope, serialize?: SerializeFullSnapshotCallback): void;
