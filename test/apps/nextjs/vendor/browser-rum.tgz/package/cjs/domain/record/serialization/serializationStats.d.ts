export interface SerializationMetric {
    count: number;
    max: number;
    sum: number;
}
export interface SerializationStats {
    cssText: SerializationMetric;
    serializationDuration: SerializationMetric;
}
export declare function createSerializationStats(): SerializationStats;
export declare function updateSerializationStats(stats: SerializationStats, metric: keyof SerializationStats, value: number): void;
export declare function aggregateSerializationStats(aggregateStats: SerializationStats, stats: SerializationStats): void;
