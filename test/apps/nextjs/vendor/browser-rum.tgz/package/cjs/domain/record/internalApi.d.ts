import type { RumConfiguration } from '@datadog/browser-rum-core';
import type { BrowserRecord, SerializedNodeWithId } from '../../types';
/**
 * Take a full snapshot of the document, generating the same records that the browser SDK
 * would generate.
 *
 * This is an internal API function. Be sure to update Datadog-internal callers if you
 * change its signature or behavior.
 */
export declare function takeFullSnapshot({ configuration, }?: {
    configuration?: Partial<RumConfiguration>;
}): BrowserRecord[];
/**
 * Take a snapshot of a DOM node, generating the serialized representation that the
 * browser SDK would generate.
 *
 * This is an internal API function. Be sure to update Datadog-internal callers if you
 * change its signature or behavior.
 */
export declare function takeNodeSnapshot(node: Node, { configuration }?: {
    configuration?: Partial<RumConfiguration>;
}): SerializedNodeWithId | null;
