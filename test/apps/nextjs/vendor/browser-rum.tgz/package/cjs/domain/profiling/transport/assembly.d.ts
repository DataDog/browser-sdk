import type { RumConfiguration } from '@datadog/browser-rum-core';
import type { BrowserProfileEvent, BrowserProfilerTrace } from '../../../types';
export interface ProfileEventPayload {
    event: BrowserProfileEvent;
    'wall-time.json': BrowserProfilerTrace;
}
export declare function assembleProfilingPayload(profilerTrace: BrowserProfilerTrace, configuration: RumConfiguration, sessionId: string | undefined): ProfileEventPayload;
