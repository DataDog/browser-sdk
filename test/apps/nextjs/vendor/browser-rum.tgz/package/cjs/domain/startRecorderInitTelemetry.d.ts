import type { Context, Telemetry, Observable } from '@datadog/browser-core';
import { noop } from '@datadog/browser-core';
import type { RecorderInitEvent } from '../boot/postStartStrategy';
type RecorderInitResult = 'aborted' | 'deflate-encoder-load-failed' | 'recorder-load-failed' | 'succeeded';
export interface RecorderInitMetrics extends Context {
    forced: boolean;
    loadRecorderModuleDuration: number | undefined;
    recorderInitDuration: number;
    result: RecorderInitResult;
    waitForDocReadyDuration: number | undefined;
}
export declare function startRecorderInitTelemetry(telemetry: Telemetry, observable: Observable<RecorderInitEvent>): {
    stop: typeof noop;
};
export {};
