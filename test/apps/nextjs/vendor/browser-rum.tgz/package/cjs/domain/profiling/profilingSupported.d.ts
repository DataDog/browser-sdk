export declare function isProfilingSupported(): boolean;
