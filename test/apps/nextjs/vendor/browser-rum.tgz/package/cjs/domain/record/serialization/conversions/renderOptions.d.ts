import type { NodeIdRemapper } from './nodeIdRemapper';
export interface V1RenderOptions {
    nodeIdRemapper: NodeIdRemapper;
    timestamp: number;
}
export declare function createV1RenderOptions(options?: Partial<V1RenderOptions>): V1RenderOptions;
