import type { StyleSheet } from '../../../../types';
import type { StyleSheetId } from '../../itemIds';
import type { VDocument } from './vDocument';
export interface VStyleSheet {
    renderAsAdoptedStyleSheet(): StyleSheet;
    renderAsCssText(): string;
    get data(): VStyleSheetData;
    get id(): StyleSheetId;
    get ownerDocument(): VDocument;
}
export interface VStyleSheetData {
    disabled: boolean;
    mediaList: string[];
    rules: string | string[];
}
export declare function createVStyleSheet(document: VDocument, id: StyleSheetId, data: VStyleSheetData): VStyleSheet;
