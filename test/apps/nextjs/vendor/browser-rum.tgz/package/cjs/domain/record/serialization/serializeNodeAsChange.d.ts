import { NodePrivacyLevel } from '@datadog/browser-rum-core';
import type { InsertionCursor } from './insertionCursor';
import type { ChangeSerializationTransaction } from './serializationTransaction';
export declare function serializeNodeAsChange(cursor: InsertionCursor, node: Node, parentPrivacyLevel: NodePrivacyLevel, transaction: ChangeSerializationTransaction): void;
