import { NodePrivacyLevel } from '@datadog/browser-rum-core';
import type { ChangeSerializationTransaction, SerializationTransaction } from './serializationTransaction';
import type { VirtualAttributes } from './serialization.types';
export declare function serializeAttributes(element: Element, nodePrivacyLevel: NodePrivacyLevel, transaction: ChangeSerializationTransaction | SerializationTransaction): Record<string, number | string>;
export declare function serializeDOMAttributes(element: Element, nodePrivacyLevel: NodePrivacyLevel, transaction: ChangeSerializationTransaction | SerializationTransaction): Record<string, string>;
export declare function serializeVirtualAttributes(element: Element, nodePrivacyLevel: NodePrivacyLevel, transaction: ChangeSerializationTransaction | SerializationTransaction): VirtualAttributes;
export declare function getCssRulesString(cssStyleSheet: CSSStyleSheet | undefined | null): string | null;
