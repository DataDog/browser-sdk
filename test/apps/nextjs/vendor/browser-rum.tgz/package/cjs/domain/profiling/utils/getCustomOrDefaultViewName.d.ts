export declare const getCustomOrDefaultViewName: (customViewName: string | undefined, viewPathUrl: string) => string;
