import type { TimeStamp } from '@datadog/browser-core';
import type { EmitRecordCallback, EmitStatsCallback } from '../record.types';
import type { RecordingScope } from '../recordingScope';
import type { SerializationKind } from './serializationTransaction';
export declare function serializeFullSnapshotAsChange(timestamp: TimeStamp, kind: SerializationKind, document: Document, emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback, scope: RecordingScope): void;
