import type { TimeStamp } from '@datadog/browser-core';
import type { RumMutationRecord } from '@datadog/browser-rum-core';
import type { RecordingScope } from '../recordingScope';
import type { EmitRecordCallback, EmitStatsCallback } from '../record.types';
export declare function serializeMutationsAsChange(timestamp: TimeStamp, mutations: RumMutationRecord[], emitRecord: EmitRecordCallback, emitStats: EmitStatsCallback, scope: RecordingScope): void;
