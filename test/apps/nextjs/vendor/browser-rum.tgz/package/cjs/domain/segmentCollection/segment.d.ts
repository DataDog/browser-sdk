import type { Encoder, EncoderResult, Uint8ArrayBuffer } from '@datadog/browser-core';
import type { BrowserRecord, BrowserSegmentMetadata, CreationReason, SegmentContext } from '../../types';
import type { SerializationStats } from '../record';
export type FlushReason = Exclude<CreationReason, 'init'> | 'stop';
export type FlushCallback = (metadata: BrowserSegmentMetadata, stats: SerializationStats, encoderResult: EncoderResult<Uint8ArrayBuffer>) => void;
export type AddRecordCallback = (encodedBytesCount: number) => void;
export interface Segment {
    addRecord: (record: BrowserRecord, callback: AddRecordCallback) => void;
    addStats: (stats: SerializationStats) => void;
    flush: (callback: FlushCallback) => void;
}
export declare function createSegment({ context, creationReason, encoder, }: {
    context: SegmentContext;
    creationReason: CreationReason;
    encoder: Encoder<Uint8ArrayBuffer>;
}): Segment;
