import type { LifeCycle } from '@datadog/browser-rum-core';
import type { ViewEndRecord } from '../../../types';
import type { EmitRecordCallback } from '../record.types';
import type { Tracker } from './tracker.types';
export declare function trackViewEnd(lifeCycle: LifeCycle, emitRecord: EmitRecordCallback<ViewEndRecord>, flushMutations: () => void): Tracker;
