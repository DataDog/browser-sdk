import type { RecordingScope } from '../recordingScope';
import type { EmitRecordCallback } from '../record.types';
import type { Tracker } from './tracker.types';
export declare function trackInput(target: Document | ShadowRoot, emitRecord: EmitRecordCallback, scope: RecordingScope): Tracker;
