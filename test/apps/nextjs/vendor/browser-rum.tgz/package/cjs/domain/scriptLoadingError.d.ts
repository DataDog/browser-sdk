export declare function reportScriptLoadingError({ configuredUrl, error, source, scriptType, }: {
    configuredUrl?: string | undefined;
    error: unknown;
    source: string;
    scriptType: 'module' | 'worker';
}): void;
