export { takeFullSnapshot, takeNodeSnapshot } from './internalApi'
export { record } from './record'
export type { SerializationMetric, SerializationStats } from './serialization'
export {
  aggregateSerializationStats,
  createSerializationStats,
  isFullSnapshotChangeRecordsEnabled,
  isIncrementalSnapshotChangeRecordsEnabled,
  serializeNode,
} from './serialization'
export { createElementsScrollPositions } from './elementsScrollPositions'
export type { ShadowRootsController } from './shadowRootsController'
