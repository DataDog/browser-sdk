import type {
  NodePrivacyLevelCache,
  RumMutationRecord,
  RumChildListMutationRecord,
  RumCharacterDataMutationRecord,
  RumAttributesMutationRecord,
} from '@datadog/browser-rum-core'
import {
  isNodeShadowHost,
  getParentNode,
  forEachChildNodes,
  getNodePrivacyLevel,
  getTextContent,
  NodePrivacyLevel,
  isNodeShadowRoot,
} from '@datadog/browser-rum-core'
import type { TimeStamp } from '@datadog/browser-core'
import { IncrementalSource } from '../../../types'
import type {
  BrowserMutationData,
  AddedNodeMutation,
  AttributeMutation,
  RemovedNodeMutation,
  TextMutation,
} from '../../../types'
import type { RecordingScope } from '../recordingScope'
import type { RemoveShadowRootCallBack } from '../shadowRootsController'
import { assembleIncrementalSnapshot } from '../assembly'
import type { EmitRecordCallback, EmitStatsCallback } from '../record.types'
import type { NodeId, NodeIds } from '../itemIds'
import type { SerializationTransaction } from './serializationTransaction'
import { SerializationKind, serializeInTransaction } from './serializationTransaction'
import { serializeNode } from './serializeNode'
import { serializeAttribute } from './serializeAttribute'
import { getElementInputValue } from './serializationUtils'

export type NodeWithSerializedNode = Node & { __brand: 'NodeWithSerializedNode' }
type WithSerializedTarget<T> = T & { target: NodeWithSerializedNode }

export function serializeMutations(
  timestamp: TimeStamp,
  mutations: RumMutationRecord[],
  emitRecord: EmitRecordCallback,
  emitStats: EmitStatsCallback,
  scope: RecordingScope
): void {
  serializeInTransaction(
    SerializationKind.INCREMENTAL_SNAPSHOT,
    emitRecord,
    emitStats,
    scope,
    (transaction: SerializationTransaction) => processMutations(timestamp, mutations, transaction)
  )
}

function processMutations(
  timestamp: TimeStamp,
  mutations: RumMutationRecord[],
  transaction: SerializationTransaction
): void {
  const nodePrivacyLevelCache: NodePrivacyLevelCache = new Map()

  mutations
    .filter((mutation): mutation is RumChildListMutationRecord => mutation.type === 'childList')
    .forEach((mutation) => {
      mutation.removedNodes.forEach((removedNode) => {
        traverseRemovedShadowDom(removedNode, transaction.scope.shadowRootsController.removeShadowRoot)
      })
    })

  // Discard any mutation with a 'target' node that:
  // * isn't injected in the current document or isn't known/serialized yet: those nodes are likely
  // part of a mutation occurring in a parent Node
  // * should be hidden or ignored
  const filteredMutations = mutations.filter(
    (mutation): mutation is WithSerializedTarget<RumMutationRecord> =>
      mutation.target.isConnected &&
      idsAreAssignedForNodeAndAncestors(mutation.target, transaction.scope.nodeIds) &&
      getNodePrivacyLevel(
        mutation.target,
        transaction.scope.configuration.defaultPrivacyLevel,
        nodePrivacyLevelCache
      ) !== NodePrivacyLevel.HIDDEN
  )

  const { adds, removes, hasBeenSerialized } = processChildListMutations(
    filteredMutations.filter(
      (mutation): mutation is WithSerializedTarget<RumChildListMutationRecord> => mutation.type === 'childList'
    ),
    nodePrivacyLevelCache,
    transaction
  )

  const texts = processCharacterDataMutations(
    filteredMutations.filter(
      (mutation): mutation is WithSerializedTarget<RumCharacterDataMutationRecord> =>
        mutation.type === 'characterData' && !hasBeenSerialized(mutation.target)
    ),
    nodePrivacyLevelCache,
    transaction
  )

  const attributes = processAttributesMutations(
    filteredMutations.filter(
      (mutation): mutation is WithSerializedTarget<RumAttributesMutationRecord> =>
        mutation.type === 'attributes' && !hasBeenSerialized(mutation.target)
    ),
    nodePrivacyLevelCache,
    transaction
  )

  if (!texts.length && !attributes.length && !removes.length && !adds.length) {
    return
  }

  const record = assembleIncrementalSnapshot<BrowserMutationData>(
    IncrementalSource.Mutation,
    {
      adds,
      removes,
      texts,
      attributes,
    },
    timestamp
  )
  transaction.add(record)

  transaction.scope.serializeObservable.notify({
    type: 'incremental',
    target: mutations,
    timestamp,
    v1: record,
  })
}

function processChildListMutations(
  mutations: Array<WithSerializedTarget<RumChildListMutationRecord>>,
  nodePrivacyLevelCache: NodePrivacyLevelCache,
  transaction: SerializationTransaction
) {
  // First, we iterate over mutations to collect:
  //
  // * nodes that have been added in the document and not removed by a subsequent mutation
  // * nodes that have been removed from the document but were not added in a previous mutation
  //
  // For this second category, we also collect their previous parent (mutation.target) because we'll
  // need it to emit a 'remove' mutation.
  //
  // Those two categories may overlap: if a node moved from a position to another, it is reported as
  // two mutation records, one with a "removedNodes" and the other with "addedNodes". In this case,
  // the node will be in both sets.
  const addedAndMovedNodes = new Set<Node>()
  const removedNodes = new Map<Node, NodeWithSerializedNode>()
  for (const mutation of mutations) {
    mutation.addedNodes.forEach((node) => {
      addedAndMovedNodes.add(node)
    })
    mutation.removedNodes.forEach((node) => {
      if (!addedAndMovedNodes.has(node)) {
        removedNodes.set(node, mutation.target)
      }
      addedAndMovedNodes.delete(node)
    })
  }

  // Then, we sort nodes that are still in the document by topological order, for two reasons:
  //
  // * We will serialize each added nodes with their descendants. We don't want to serialize a node
  // twice, so we need to iterate over the parent nodes first and skip any node that is contained in
  // a precedent node.
  //
  // * To emit "add" mutations, we need references to the parent and potential next sibling of each
  // added node. So we need to iterate over the parent nodes first, and when multiple nodes are
  // siblings, we want to iterate from last to first. This will ensure that any "next" node is
  // already serialized and have an id.
  const sortedAddedAndMovedNodes = Array.from(addedAndMovedNodes)
  sortAddedAndMovedNodes(sortedAddedAndMovedNodes)

  // Then, we iterate over our sorted node sets to emit mutations. We collect the newly serialized
  // node ids in a set to be able to skip subsequent related mutations.
  transaction.serializedNodeIds = new Set<NodeId>()

  const addedNodeMutations: AddedNodeMutation[] = []
  for (const node of sortedAddedAndMovedNodes) {
    if (hasBeenSerialized(node)) {
      continue
    }

    const parentNodePrivacyLevel = getNodePrivacyLevel(
      node.parentNode!,
      transaction.scope.configuration.defaultPrivacyLevel,
      nodePrivacyLevelCache
    )
    if (parentNodePrivacyLevel === NodePrivacyLevel.HIDDEN || parentNodePrivacyLevel === NodePrivacyLevel.IGNORE) {
      continue
    }

    const serializedNode = serializeNode(node, parentNodePrivacyLevel, transaction)
    if (!serializedNode) {
      continue
    }

    const parentNode = getParentNode(node)!
    addedNodeMutations.push({
      nextId: getNextSibling(node),
      parentId: transaction.scope.nodeIds.get(parentNode)!,
      node: serializedNode,
    })
  }
  // Finally, we emit remove mutations.
  const removedNodeMutations: RemovedNodeMutation[] = []
  removedNodes.forEach((parent, node) => {
    const parentId = transaction.scope.nodeIds.get(parent)
    const id = transaction.scope.nodeIds.get(node)
    if (parentId !== undefined && id !== undefined) {
      removedNodeMutations.push({ parentId, id })
    }
  })

  return { adds: addedNodeMutations, removes: removedNodeMutations, hasBeenSerialized }

  function hasBeenSerialized(node: Node) {
    const id = transaction.scope.nodeIds.get(node)
    return id !== undefined && transaction.serializedNodeIds?.has(id)
  }

  function getNextSibling(node: Node): null | number {
    let nextSibling = node.nextSibling
    while (nextSibling) {
      const id = transaction.scope.nodeIds.get(nextSibling)
      if (id !== undefined) {
        return id
      }
      nextSibling = nextSibling.nextSibling
    }

    return null
  }
}

function processCharacterDataMutations(
  mutations: Array<WithSerializedTarget<RumCharacterDataMutationRecord>>,
  nodePrivacyLevelCache: NodePrivacyLevelCache,
  transaction: SerializationTransaction
) {
  const textMutations: TextMutation[] = []

  // Deduplicate mutations based on their target node
  const handledNodes = new Set<Node>()
  const filteredMutations = mutations.filter((mutation) => {
    if (handledNodes.has(mutation.target)) {
      return false
    }
    handledNodes.add(mutation.target)
    return true
  })

  // Emit mutations
  for (const mutation of filteredMutations) {
    const value = mutation.target.textContent
    if (value === mutation.oldValue) {
      continue
    }

    const id = transaction.scope.nodeIds.get(mutation.target)
    if (id === undefined) {
      continue
    }

    const parentNodePrivacyLevel = getNodePrivacyLevel(
      getParentNode(mutation.target)!,
      transaction.scope.configuration.defaultPrivacyLevel,
      nodePrivacyLevelCache
    )
    if (parentNodePrivacyLevel === NodePrivacyLevel.HIDDEN || parentNodePrivacyLevel === NodePrivacyLevel.IGNORE) {
      continue
    }

    textMutations.push({
      id,
      value: getTextContent(mutation.target, parentNodePrivacyLevel) ?? null,
    })
  }

  return textMutations
}

function processAttributesMutations(
  mutations: Array<WithSerializedTarget<RumAttributesMutationRecord>>,
  nodePrivacyLevelCache: NodePrivacyLevelCache,
  transaction: SerializationTransaction
) {
  const attributeMutations: AttributeMutation[] = []

  // Deduplicate mutations based on their target node and changed attribute
  const handledElements = new Map<Element, Set<string>>()
  const filteredMutations = mutations.filter((mutation) => {
    const handledAttributes = handledElements.get(mutation.target)
    if (handledAttributes && handledAttributes.has(mutation.attributeName)) {
      return false
    }
    if (!handledAttributes) {
      handledElements.set(mutation.target, new Set([mutation.attributeName]))
    } else {
      handledAttributes.add(mutation.attributeName)
    }
    return true
  })

  // Emit mutations
  const emittedMutations = new Map<Element, AttributeMutation>()
  for (const mutation of filteredMutations) {
    const uncensoredValue = mutation.target.getAttribute(mutation.attributeName)
    if (uncensoredValue === mutation.oldValue) {
      continue
    }

    const id = transaction.scope.nodeIds.get(mutation.target)
    if (id === undefined) {
      continue
    }

    const privacyLevel = getNodePrivacyLevel(
      mutation.target,
      transaction.scope.configuration.defaultPrivacyLevel,
      nodePrivacyLevelCache
    )
    const attributeValue = serializeAttribute(
      mutation.target,
      privacyLevel,
      mutation.attributeName,
      transaction.scope.configuration
    )

    let transformedValue: string | null
    if (mutation.attributeName === 'value') {
      const inputValue = getElementInputValue(mutation.target, privacyLevel)
      if (inputValue === undefined) {
        continue
      }
      transformedValue = inputValue
    } else if (typeof attributeValue === 'string') {
      transformedValue = attributeValue
    } else {
      transformedValue = null
    }

    let emittedMutation = emittedMutations.get(mutation.target)
    if (!emittedMutation) {
      emittedMutation = { id, attributes: {} }
      attributeMutations.push(emittedMutation)
      emittedMutations.set(mutation.target, emittedMutation)
    }

    emittedMutation.attributes[mutation.attributeName] = transformedValue
  }

  return attributeMutations
}

export function sortAddedAndMovedNodes(nodes: Node[]) {
  nodes.sort((a, b) => {
    const position = a.compareDocumentPosition(b)
    /* eslint-disable no-bitwise */
    if (position & Node.DOCUMENT_POSITION_CONTAINED_BY) {
      return -1
    } else if (position & Node.DOCUMENT_POSITION_CONTAINS) {
      return 1
    } else if (position & Node.DOCUMENT_POSITION_FOLLOWING) {
      return 1
    } else if (position & Node.DOCUMENT_POSITION_PRECEDING) {
      return -1
    }
    /* eslint-enable no-bitwise */
    return 0
  })
}

function traverseRemovedShadowDom(removedNode: Node, shadowDomRemovedCallback: RemoveShadowRootCallBack) {
  if (isNodeShadowHost(removedNode)) {
    shadowDomRemovedCallback(removedNode.shadowRoot)
  }
  forEachChildNodes(removedNode, (childNode) => traverseRemovedShadowDom(childNode, shadowDomRemovedCallback))
}

export function idsAreAssignedForNodeAndAncestors(node: Node, nodeIds: NodeIds): node is NodeWithSerializedNode {
  let current: Node | null = node
  while (current) {
    if (nodeIds.get(current) === undefined && !isNodeShadowRoot(current)) {
      return false
    }
    current = getParentNode(current)
  }
  return true
}
