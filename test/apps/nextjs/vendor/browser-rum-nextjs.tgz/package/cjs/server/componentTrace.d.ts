interface ComponentTraceContext {
    componentName: string;
}
interface Store {
    run<T>(context: ComponentTraceContext, fn: () => T): T;
    getStore(): ComponentTraceContext | undefined;
}
/**
 * Initialises the component trace store with an AsyncLocalStorage instance.
 * Called by the server component loader which imports AsyncLocalStorage at the
 * app level (where bundlers resolve node: built-ins correctly).
 */
export declare function initComponentTraceStore(AsyncLocalStorage: {
    new (): Store;
}): void;
/**
 * Allows tests to inject a mock store implementation.
 * @internal
 */
export declare function setComponentTraceStoreForTesting(mockStore: Store | undefined): void;
/**
 * Returns the current component trace context, if any.
 * Can be used to read the active component name from within fetch interceptors.
 */
export declare function getComponentTraceContext(): ComponentTraceContext | undefined;
/**
 * Wraps a React Server Component to create a tracing span around its execution.
 *
 * In Node.js runtime, it uses dd-trace to create a parent span so that fetch calls
 * within the component automatically appear as child spans in APM traces.
 *
 * In Edge runtime, it uses the lightweight edge tracer to create a standalone span.
 *
 * @param componentName - The name to use for the span (e.g. 'UserProfile')
 * @param Component - The async server component function to wrap
 */
export declare function withComponentTrace<P>(componentName: string, Component: (props: P) => Promise<React.ReactElement | null>): (props: P) => Promise<React.ReactElement | null>;
export {};
