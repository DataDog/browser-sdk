/**
 * Detects if the current environment is a Vercel Edge Runtime or similar
 * where dd-trace is not available.
 */
export declare function isEdgeRuntime(): boolean;
/**
 * Minimal span interface matching the subset we use from dd-trace.
 * Used as a fallback when dd-trace is not available in Edge Runtime.
 */
export interface EdgeSpan {
    setTag(key: string, value: any): void;
    finish(): void;
    context(): {
        toTraceId(): string;
        toSpanId(): string;
    };
}
export interface EdgeTracerOptions {
    /** Datadog API key (DD_API_KEY env var) */
    apiKey?: string;
    /** Datadog site (e.g., 'datadoghq.com') */
    site?: string;
    /** Service name */
    service?: string;
    /** Environment */
    env?: string;
    /** Version */
    version?: string;
}
/**
 * Creates a lightweight edge-compatible tracer that sends traces
 * via HTTP to the Datadog intake.
 */
export declare function createEdgeTracer(options?: EdgeTracerOptions): {
    startSpan(operationName: string, spanOptions?: {
        tags?: Record<string, any>;
    }): EdgeSpan;
};
