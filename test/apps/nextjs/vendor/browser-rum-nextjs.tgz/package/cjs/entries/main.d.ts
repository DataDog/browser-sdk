export { nextjsPlugin, onRouterTransitionStart } from '../domain/nextjsPlugin';
export type { NextjsPlugin } from '../domain/nextjsPlugin';
export { DatadogAppRouter } from '../domain/nextJSRouter/datadogAppRouter';
export { DatadogPagesRouter } from '../domain/nextJSRouter/datadogPagesRouter';
export { addNextjsError } from '../domain/error/addNextjsError';
