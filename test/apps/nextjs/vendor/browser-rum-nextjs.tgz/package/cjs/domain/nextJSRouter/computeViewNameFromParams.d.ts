import type { useParams } from 'next/navigation';
type Params = ReturnType<typeof useParams>;
export declare function computeViewNameFromParams(pathname: string, params: Params): string;
export {};
