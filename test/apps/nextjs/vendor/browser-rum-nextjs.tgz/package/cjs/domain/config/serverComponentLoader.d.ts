/**
 * Webpack/Turbopack loader that automatically wraps React Server Component
 * default exports with `withComponentTrace` for APM tracing.
 *
 * Detection: A file is treated as a server component if it does NOT start
 * with a 'use client' or "use client" directive.
 *
 * The loader handles these default export patterns:
 * - export default async function Name() {}
 * - export default function Name() {}
 * - export default async function() {}   (uses filename)
 * - export default function() {}          (uses filename)
 * - export default Name                   (identifier reference)
 */
export default function serverComponentLoader(this: {
    resourcePath: string;
}, source: string): string;
