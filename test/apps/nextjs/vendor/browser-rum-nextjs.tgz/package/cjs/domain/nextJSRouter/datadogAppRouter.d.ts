export declare function DatadogAppRouter(): null;
