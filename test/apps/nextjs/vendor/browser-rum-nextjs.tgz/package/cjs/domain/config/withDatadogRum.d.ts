export interface WithDatadogRumOptions {
    /** Enable document-policy: js-profiling header for browser profiling */
    profilingSampleRate?: number;
    /** Automatically wrap server components with tracing spans. Defaults to true. */
    traceServerComponents?: boolean;
}
interface NextHeaderEntry {
    source: string;
    headers: Array<{
        key: string;
        value: string;
    }>;
}
type HeadersFunction = () => Promise<NextHeaderEntry[]>;
interface NextConfig {
    env?: Record<string, string | undefined>;
    productionBrowserSourceMaps?: boolean;
    headers?: HeadersFunction;
    [key: string]: any;
}
type NextConfigFn = (phase: string, context: {
    defaultConfig: NextConfig;
}) => NextConfig | Promise<NextConfig>;
type NextConfigInput = NextConfig | NextConfigFn;
export declare function withDatadogRum(nextConfig: NextConfigInput, options?: WithDatadogRumOptions): NextConfigInput;
export {};
