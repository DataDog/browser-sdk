export declare function DatadogPagesRouter(): null;
