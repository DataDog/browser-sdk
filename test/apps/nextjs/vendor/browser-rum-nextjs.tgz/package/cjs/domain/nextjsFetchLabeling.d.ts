import type { RumInitConfiguration } from '@datadog/browser-rum-core';
export declare function setupNextjsFetchLabeling(initConfiguration: RumInitConfiguration): void;
