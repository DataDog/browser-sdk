import type { AnyRouteMatch } from './types';
export declare function startReactRouterView(routeMatches: AnyRouteMatch[]): void;
export declare function computeViewName(routeMatches: AnyRouteMatch[]): string;
