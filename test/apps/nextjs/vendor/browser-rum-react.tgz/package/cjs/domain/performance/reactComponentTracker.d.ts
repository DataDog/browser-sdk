import * as React from 'react';
/**
 * Track the performance of a React component.
 *
 * @experimental
 */
export declare const UNSTABLE_ReactComponentTracker: ({ name: componentName, children, }: {
    name: string;
    children?: React.ReactNode;
}) => React.JSX.Element;
