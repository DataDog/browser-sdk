import type { AnyCreateRouter } from './types';
export declare function wrapCreateRouter<CreateRouter extends AnyCreateRouter<any>>(originalCreateRouter: CreateRouter): CreateRouter;
