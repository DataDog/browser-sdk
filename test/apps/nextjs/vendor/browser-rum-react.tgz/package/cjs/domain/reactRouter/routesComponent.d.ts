import type { AnyLocation, AnyRouteObject, AnyUseRoute } from './types';
export declare function createRoutesComponent<Location extends AnyLocation>(useRoutes: AnyUseRoute<Location>, createRoutesFromChildren: (children: React.ReactNode, parentPath?: number[]) => AnyRouteObject[]): ({ children, location }: {
    children?: React.ReactNode;
    location?: Location;
}) => import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | null;
