import type { Duration, TimeStamp } from '@datadog/browser-core';
export declare function createTimer(): {
    startTimer(this: void): void;
    stopTimer(this: void): void;
    getDuration(this: void): Duration | undefined;
    getStartTime(this: void): TimeStamp | undefined;
};
