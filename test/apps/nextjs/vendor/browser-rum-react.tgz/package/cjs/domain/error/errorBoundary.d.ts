import React from 'react';
import type { ErrorInfo } from 'react';
export interface ErrorBoundaryProps {
    fallback: ErrorBoundaryFallback;
    children: React.ReactNode;
}
export type ErrorBoundaryFallback = React.ComponentType<{
    error: Error;
    resetError: () => void;
}>;
export type State = {
    didCatch: false;
    error: null;
} | {
    didCatch: true;
    error: Error;
};
export declare function createErrorBoundary(reportError: (error: Error, errorInfo: ErrorInfo) => void, displayName?: string): React.ComponentClass<ErrorBoundaryProps, any>;
/**
 * ErrorBoundary component to report React errors to Datadog.
 *
 * For more advanced error handling, you can use the {@link addReactError} function.
 *
 * @category Error
 * @example
 * ```ts
 * import { ErrorBoundary } from '@datadog/browser-rum-react'
 *
 * <ErrorBoundary fallback={() => null}>
 *   <Component />
 * </ErrorBoundary>
 * ```
 */
export declare const ErrorBoundary: React.ComponentClass<ErrorBoundaryProps, any>;
