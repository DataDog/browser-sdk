import type { AnyUseRoute, AnyRouteObject, AnyRouteMatch } from './types';
export declare function wrapUseRoutes<T extends AnyUseRoute<any>>({ useRoutes, useLocation, matchRoutes, }: {
    useRoutes: T;
    useLocation: () => {
        pathname: string;
    };
    matchRoutes: (routes: AnyRouteObject[], pathname: string) => AnyRouteMatch[] | null;
}): T;
