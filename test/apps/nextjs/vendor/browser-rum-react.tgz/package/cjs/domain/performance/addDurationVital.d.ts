import type { RumPublicApi } from '@datadog/browser-rum-core';
export declare const addDurationVital: RumPublicApi['addDurationVital'];
