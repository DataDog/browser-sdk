import type { RumPlugin, RumPublicApi, StartRumResult } from '@datadog/browser-rum-core';
type InitSubscriber = (configuration: ReactPluginConfiguration, rumPublicApi: RumPublicApi) => void;
type StartSubscriber = (addError: StartRumResult['addError']) => void;
/**
 * React plugin configuration.
 *
 * @category Main
 */
export interface ReactPluginConfiguration {
    /**
     * Enable react-router integration. Make sure to use functions from
     * {@link @datadog/browser-rum-react/react-router-v6! | @datadog/browser-rum-react/react-router-v6} or
     * {@link @datadog/browser-rum-react/react-router-v7! | @datadog/browser-rum-react/react-router-v7}
     * to create the router.
     * ```
     */
    router?: boolean;
}
/**
 * React plugin type.
 *
 * The plugins API is unstable and experimental, and may change without notice. Please don't use this type directly.
 *
 * @internal
 */
export type ReactPlugin = Required<RumPlugin>;
/**
 * React plugin constructor.
 *
 * @category Main
 * @example
 * ```ts
 * import { datadogRum } from '@datadog/browser-rum'
 * import { reactPlugin } from '@datadog/browser-rum-react'
 *
 * datadogRum.init({
 *   applicationId: '<DATADOG_APPLICATION_ID>',
 *   clientToken: '<DATADOG_CLIENT_TOKEN>',
 *   site: '<DATADOG_SITE>',
 *   plugins: [reactPlugin()],
 *   // ...
 * })
 * ```
 */
export declare function reactPlugin(configuration?: ReactPluginConfiguration): ReactPlugin;
export declare function onRumInit(callback: InitSubscriber): void;
export declare function onRumStart(callback: StartSubscriber): void;
export declare function resetReactPlugin(): void;
export {};
