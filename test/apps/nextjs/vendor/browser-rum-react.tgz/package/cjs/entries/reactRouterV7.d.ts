/**
 * React Router v7 integration.
 *
 * @packageDocumentation
 * @example
 * ```ts
 * import { RouterProvider } from 'react-router'
 * import { datadogRum } from '@datadog/browser-rum'
 * import { reactPlugin } from '@datadog/browser-rum-react'
 *
 * // ⚠️ Use "createBrowserRouter" from `@datadog/browser-rum-react/react-router-v7` instead of `react-router`
 * import { createBrowserRouter } from '@datadog/browser-rum-react/react-router-v7'
 *
 * datadogRum.init({
 *   applicationId: '<DATADOG_APPLICATION_ID>',
 *   clientToken: '<DATADOG_CLIENT_TOKEN>',
 *   plugins: [reactPlugin({ router: true })],
 *   // ...
 * })
 *
 * const router = createBrowserRouter([
 *   {
 *     path: '/',
 *     element: <Root />,
 *     // ...
 *   },
 * ])
 *
 * ReactDOM.createRoot(document.getElementById('root')).render(<RouterProvider router={router} />)
 * ```
 */
import { createBrowserRouter as originalCreateBrowserRouter, createHashRouter as originalCreateHashRouter, createMemoryRouter as originalCreateMemoryRouter, useRoutes as originalUseRoutes } from 'react-router';
import type { Routes as originalRoutes } from 'react-router';
/**
 * Use this function in place of `react-router-dom` `createBrowserRouter`. Every time a route is
 * rendered, a new RUM view is created.
 *
 * @see https://reactrouter.com/v7/api/data-routers/createBrowserRouter
 */
export declare const createBrowserRouter: typeof originalCreateBrowserRouter;
/**
 * Use this function in place of `react-router-dom` `createHashRouter`. Every time a route is
 * rendered, a new RUM view is created.
 *
 * @see https://reactrouter.com/v7/api/data-routers/createHashRouter
 */
export declare const createHashRouter: typeof originalCreateHashRouter;
/**
 * Use this function in place of `react-router-dom` `createMemoryRouter`. Every time a route is
 * rendered, a new RUM view is created.
 *
 * @see https://reactrouter.com/v7/api/data-routers/createMemoryRouter
 */
export declare const createMemoryRouter: typeof originalCreateMemoryRouter;
/**
 * Use this hook in place of `react-router-dom` `useRoutes`. Every time a route is rendered, a new
 * RUM view is created.
 *
 * @see https://reactrouter.com/v7/api/hooks/useRoutes
 */
export declare const useRoutes: typeof originalUseRoutes;
/**
 * Use this component in place of `react-router-dom` `Routes`. Every time a route is rendered, a new
 * RUM view is created.
 *
 * @see https://reactrouter.com/v7/api/components/Routes
 */
export declare const Routes: typeof originalRoutes;
