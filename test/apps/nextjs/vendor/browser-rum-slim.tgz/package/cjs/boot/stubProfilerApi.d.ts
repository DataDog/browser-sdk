import type { ProfilerApi } from '@datadog/browser-rum-core';
export declare function makeProfilerApiStub(): ProfilerApi;
