import type { RumPublicApi } from '@datadog/browser-rum-core';
export type { User, Account, TraceContextInjection, SessionPersistence, TrackingConsent, MatchOption, ProxyFn, Site, Context, ContextValue, ContextArray, RumInternalContext, } from '@datadog/browser-core';
/**
 * @deprecated Use {@link DatadogRum} instead
 */
export type RumGlobal = RumPublicApi;
export type { RumPublicApi as DatadogRum, RumInitConfiguration, RumBeforeSend, ViewOptions, StartRecordingOptions, AddDurationVitalOptions, DurationVitalOptions, DurationVitalReference, TracingOption, RumPlugin, OnRumStartOptions, PropagatorType, FeatureFlagsForEvents, CommonProperties, RumEvent, RumActionEvent, RumErrorEvent, RumLongTaskEvent, RumResourceEvent, RumViewEvent, RumVitalEvent, RumEventDomainContext, RumViewEventDomainContext, RumErrorEventDomainContext, RumActionEventDomainContext, RumVitalEventDomainContext, RumFetchResourceEventDomainContext, RumXhrResourceEventDomainContext, RumOtherResourceEventDomainContext, RumLongTaskEventDomainContext, } from '@datadog/browser-rum-core';
export { DefaultPrivacyLevel } from '@datadog/browser-core';
/**
 * The global RUM instance. Use this to call RUM methods.
 *
 * @category Main
 * @see {@link DatadogRum}
 * @see [RUM Browser Monitoring Setup](https://docs.datadoghq.com/real_user_monitoring/browser/)
 */
export declare const datadogRum: RumPublicApi;
