export declare function removeDuplicates<T>(array: T[]): T[];
export declare function removeItem<T>(array: T[], item: T): void;
export declare function isNonEmptyArray<T>(value: unknown): value is T[];
