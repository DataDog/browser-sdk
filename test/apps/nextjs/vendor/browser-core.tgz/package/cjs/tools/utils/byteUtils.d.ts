export declare const ONE_KIBI_BYTE = 1024;
export declare const ONE_MEBI_BYTE: number;
export interface Uint8ArrayBuffer extends Uint8Array {
    readonly buffer: ArrayBuffer;
    subarray(begin?: number, end?: number): Uint8ArrayBuffer;
}
export declare function computeBytesCount(candidate: string): number;
export declare function concatBuffers(buffers: Uint8ArrayBuffer[]): Uint8ArrayBuffer;
