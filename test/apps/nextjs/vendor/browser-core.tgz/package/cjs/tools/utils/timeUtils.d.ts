export declare const ONE_SECOND = 1000;
export declare const ONE_MINUTE: number;
export declare const ONE_HOUR: number;
export declare const ONE_DAY: number;
export declare const ONE_YEAR: number;
export type Duration = number & {
    d: 'Duration in ms';
};
export type ServerDuration = number & {
    s: 'Duration in ns';
};
export type TimeStamp = number & {
    t: 'Epoch time';
};
export type RelativeTime = number & {
    r: 'Time relative to navigation start';
} & {
    d: 'Duration in ms';
};
export interface ClocksState {
    relative: RelativeTime;
    timeStamp: TimeStamp;
}
export declare function relativeToClocks(relative: RelativeTime): {
    relative: RelativeTime;
    timeStamp: TimeStamp;
};
export declare function timeStampToClocks(timeStamp: TimeStamp): {
    relative: RelativeTime;
    timeStamp: TimeStamp;
};
export declare function currentDrift(): number;
export declare function toServerDuration(duration: Duration): ServerDuration;
export declare function toServerDuration(duration: Duration | undefined): ServerDuration | undefined;
export declare function dateNow(): number;
export declare function timeStampNow(): TimeStamp;
export declare function relativeNow(): RelativeTime;
export declare function clocksNow(): {
    relative: RelativeTime;
    timeStamp: TimeStamp;
};
export declare function clocksOrigin(): {
    relative: RelativeTime;
    timeStamp: TimeStamp;
};
export declare function elapsed(start: TimeStamp, end: TimeStamp): Duration;
export declare function elapsed(start: RelativeTime, end: RelativeTime): Duration;
export declare function addDuration(a: TimeStamp, b: Duration): TimeStamp;
export declare function addDuration(a: RelativeTime, b: Duration): RelativeTime;
export declare function addDuration(a: Duration, b: Duration): Duration;
export declare function getRelativeTime(timestamp: TimeStamp): RelativeTime;
export declare function getTimeStamp(relativeTime: RelativeTime): TimeStamp;
export declare function looksLikeRelativeTime(time: RelativeTime | TimeStamp): time is RelativeTime;
