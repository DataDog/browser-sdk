export declare const enum Browser {
    CHROMIUM = 0,
    SAFARI = 1,
    OTHER = 2
}
export declare function isChromium(): boolean;
export declare function isSafari(): boolean;
export declare function detectBrowser(browserWindow?: Window): Browser;
