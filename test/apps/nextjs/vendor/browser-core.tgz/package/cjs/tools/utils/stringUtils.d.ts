/**
 * UUID v4
 * from https://gist.github.com/jed/982883
 */
export declare function generateUUID(placeholder?: string): string;
/**
 * Returns the value of the key with the given name
 * If there are multiple values with the same key, returns the first one
 */
export declare function findCommaSeparatedValue(rawString: string, name: string): string | undefined;
/**
 * Returns a map of all the values with the given key
 * If there are multiple values with the same key, returns all the values
 */
export declare function findAllCommaSeparatedValues(rawString: string): Map<string, string[]>;
/**
 * Returns a map of the values with the given key
 * ⚠️ If there are multiple values with the same key, returns the LAST one
 *
 * @deprecated use `findAllCommaSeparatedValues()` instead
 */
export declare function findCommaSeparatedValues(rawString: string): Map<string, string>;
export declare function safeTruncate(candidate: string, length: number, suffix?: string): string;
