export declare function normalizeUrl(url: string): string;
export declare function isValidUrl(url: string): boolean;
export declare function getPathName(url: string): string;
export declare function buildUrl(url: string, base?: string): URL;
export declare function getPristineWindow(): Pick<Window & typeof globalThis, "URL">;
