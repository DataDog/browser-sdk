export interface Subscription {
    unsubscribe: () => void;
}
type Observer<T> = (data: T) => void;
export declare class Observable<T> {
    private onFirstSubscribe?;
    protected observers: Array<Observer<T>>;
    private onLastUnsubscribe?;
    constructor(onFirstSubscribe?: ((observable: Observable<T>) => (() => void) | void) | undefined);
    subscribe(observer: Observer<T>): Subscription;
    notify(data: T): void;
    protected addObserver(observer: Observer<T>): void;
    protected removeObserver(observer: Observer<T>): void;
}
export declare function mergeObservables<T>(...observables: Array<Observable<T>>): Observable<T>;
export declare class BufferedObservable<T> extends Observable<T> {
    private maxBufferSize;
    private buffer;
    constructor(maxBufferSize: number);
    notify(data: T): void;
    subscribe(observer: Observer<T>): Subscription;
    /**
     * Drop buffered data and don't buffer future data. This is to avoid leaking memory when it's not
     * needed anymore. This can be seen as a performance optimization, and things will work probably
     * even if this method isn't called, but still useful to clarify our intent and lowering our
     * memory impact.
     */
    unbuffer(): void;
}
export {};
