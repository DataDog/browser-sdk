/**
 * Maximum amount of time allocated to running tasks when a timeout (`IDLE_CALLBACK_TIMEOUT`) is
 * reached. We should not run tasks for too long as it will hurt performance, but we should still
 * run some tasks to avoid postponing them forever.
 *
 * Rational: Running tasks for 30ms every second (IDLE_CALLBACK_TIMEOUT) should be acceptable.
 */
export declare const MAX_EXECUTION_TIME_ON_TIMEOUT = 30;
export interface TaskQueue {
    push(task: Task): void;
    stop(): void;
}
type Task = () => void;
export declare function createTaskQueue(): TaskQueue;
export {};
