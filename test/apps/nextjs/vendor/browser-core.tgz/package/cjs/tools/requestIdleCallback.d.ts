export interface IdleDeadline {
    readonly didTimeout: boolean;
    timeRemaining(): DOMHighResTimeStamp;
}
/**
 * 'requestIdleCallback' with a shim.
 */
export declare function requestIdleCallback(callback: (deadline: IdleDeadline) => void, opts?: {
    timeout?: number;
}): () => void;
export declare const MAX_TASK_TIME = 50;
export declare function requestIdleCallbackShim(callback: (deadline: IdleDeadline) => void): () => void;
