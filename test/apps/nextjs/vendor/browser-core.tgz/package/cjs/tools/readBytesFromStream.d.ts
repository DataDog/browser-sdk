import type { Uint8ArrayBuffer } from './utils/byteUtils';
interface Options {
    collectStreamBody?: boolean;
}
/**
 * Read bytes from a ReadableStream until the end of the stream.
 * Returns the bytes if collectStreamBody is true, otherwise returns undefined.
 */
export declare function readBytesFromStream(stream: ReadableStream<Uint8ArrayBuffer>, options: Options): Promise<Uint8ArrayBuffer | undefined>;
export {};
