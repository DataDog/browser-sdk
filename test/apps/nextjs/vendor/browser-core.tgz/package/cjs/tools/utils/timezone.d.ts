export declare function getTimeZone(): string | undefined;
