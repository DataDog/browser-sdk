/**
 * BoundedBuffer is a deprecated interface.
 *
 * @deprecated Use `BufferedObservable` instead.
 */
export interface BoundedBuffer<T = void> {
    add: (callback: (arg: T) => void) => void;
    remove: (callback: (arg: T) => void) => void;
    drain: (arg: T) => void;
}
/**
 * createBoundedBuffer creates a BoundedBuffer.
 *
 * @deprecated Use `BufferedObservable` instead.
 */
export declare function createBoundedBuffer<T = void>(): BoundedBuffer<T>;
