/**
 * LIMITATION:
 * For NPM setup, this feature flag singleton is shared between RUM and Logs product.
 * This means that an experimental flag set on the RUM product will be set on the Logs product.
 * So keep in mind that in certain configurations, your experimental feature flag may affect other products.
 *
 * FORMAT:
 * All feature flags should be snake_cased
 */
export declare enum ExperimentalFeature {
    TRACK_INTAKE_REQUESTS = "track_intake_requests",
    USE_TREE_WALKER_FOR_ACTION_NAME = "use_tree_walker_for_action_name",
    FEATURE_OPERATION_VITAL = "feature_operation_vital",
    SHORT_SESSION_INVESTIGATION = "short_session_investigation",
    START_STOP_ACTION = "start_stop_action",
    START_STOP_RESOURCE = "start_stop_resource",
    USE_CHANGE_RECORDS = "use_change_records",
    USE_INCREMENTAL_CHANGE_RECORDS = "use_incremental_change_records",
    LCP_SUBPARTS = "lcp_subparts",
    INP_SUBPARTS = "inp_subparts",
    TOO_MANY_REQUESTS_INVESTIGATION = "too_many_requests_investigation"
}
export declare function initFeatureFlags(enableExperimentalFeatures: string[] | undefined): void;
export declare function addExperimentalFeatures(enabledFeatures: ExperimentalFeature[]): void;
export declare function isExperimentalFeatureEnabled(featureName: ExperimentalFeature): boolean;
export declare function resetExperimentalFeatures(): void;
export declare function getExperimentalFeatures(): Set<ExperimentalFeature>;
