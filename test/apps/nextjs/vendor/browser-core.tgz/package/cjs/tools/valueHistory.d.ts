import type { Duration, RelativeTime } from './utils/timeUtils';
export interface ValueHistoryEntry<T> {
    startTime: RelativeTime;
    endTime: RelativeTime;
    value: T;
    remove(): void;
    close(endTime: RelativeTime): void;
}
export declare const CLEAR_OLD_VALUES_INTERVAL: number;
/**
 * Store and keep track of values spans. This whole cache assumes that values are added in
 * chronological order (i.e. all entries have an increasing start time).
 */
export interface ValueHistory<Value> {
    add: (value: Value, startTime: RelativeTime) => ValueHistoryEntry<Value>;
    find: (startTime?: RelativeTime, options?: {
        returnInactive: boolean;
    }) => Value | undefined;
    closeActive: (endTime: RelativeTime) => void;
    findAll: (startTime?: RelativeTime, duration?: Duration) => Value[];
    getEntries: (startTime: RelativeTime) => Array<ValueHistoryEntry<Value>>;
    reset: () => void;
    stop: () => void;
}
export declare function createValueHistory<Value>({ expireDelay, maxEntries, }: {
    expireDelay: number;
    maxEntries?: number;
}): ValueHistory<Value>;
/**
 * Reset all global state. This is useful for testing to ensure clean state between tests.
 *
 * @internal
 */
export declare function resetValueHistoryGlobals(): void;
