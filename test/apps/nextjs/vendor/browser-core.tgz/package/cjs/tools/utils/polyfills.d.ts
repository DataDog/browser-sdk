export declare function findLast<T, S extends T>(array: readonly T[], predicate: (item: T, index: number, array: readonly T[]) => item is S): S | undefined;
export declare function objectValues<T = unknown>(object: {
    [key: string]: T;
}): T[];
export declare function objectEntries<T = unknown>(object: {
    [key: string]: T;
}): Array<[string, T]>;
