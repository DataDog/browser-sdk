/**
 * Keep references on console methods to avoid triggering patched behaviors
 *
 * NB: in some setup, console could already be patched by another SDK.
 * In this case, some display messages can be sent by the other SDK
 * but we should be safe from infinite loop nonetheless.
 */
export declare const ConsoleApiName: {
    readonly log: "log";
    readonly debug: "debug";
    readonly info: "info";
    readonly warn: "warn";
    readonly error: "error";
};
export type ConsoleApiName = (typeof ConsoleApiName)[keyof typeof ConsoleApiName];
interface Display {
    debug: typeof console.debug;
    log: typeof console.log;
    info: typeof console.info;
    warn: typeof console.warn;
    error: typeof console.error;
}
/**
 * When building JS bundles, some users might use a plugin[1] or configuration[2] to remove
 * "console.*" references. This causes some issue as we expect `console.*` to be defined.
 * As a workaround, let's use a variable alias, so those expressions won't be taken into account by
 * simple static analysis.
 *
 * [1]: https://babeljs.io/docs/babel-plugin-transform-remove-console/
 * [2]: https://github.com/terser/terser#compress-options (look for drop_console)
 */
export declare const globalConsole: Console;
export declare const originalConsoleMethods: Display;
export declare const display: Display;
export declare const DOCS_ORIGIN = "https://docs.datadoghq.com";
export declare const DOCS_TROUBLESHOOTING = "https://docs.datadoghq.com/real_user_monitoring/browser/troubleshooting";
export declare const MORE_DETAILS = "More details:";
export {};
