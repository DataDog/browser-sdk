export declare const mockableReplacements: Map<unknown, unknown>;
/**
 * Wraps a value to make it mockable in tests. In production builds, this is a no-op
 * that returns the value as-is. In test builds, it checks if a mock replacement has
 * been registered and returns that instead.
 *
 * @example
 * // In source file:
 * import { mockable } from '../tools/mockable'
 * export function formatNavigationEntry(): string {
 *   const navigationEntry = mockable(getNavigationEntry)()
 *   ...
 * }
 *
 * // In test file:
 * import { replaceMockable } from '@datadog/browser-core/test'
 * it('...', () => {
 *   replaceMockable(getNavigationEntry, () => FAKE_NAVIGATION_ENTRY)
 *   expect(formatNavigationEntry()).toEqual(...)
 * })
 */
export declare function mockable<T>(value: T): T;
