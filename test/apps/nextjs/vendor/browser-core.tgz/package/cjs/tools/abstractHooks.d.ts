export declare const enum HookNames {
    Assemble = 0,
    AssembleTelemetry = 1
}
export declare const HookNamesAsConst: {
    ASSEMBLE: HookNames.Assemble;
    ASSEMBLE_TELEMETRY: HookNames.AssembleTelemetry;
};
export type RecursivePartial<T> = {
    [P in keyof T]?: T[P] extends Array<infer U> ? Array<RecursivePartial<U>> : T[P] extends object | undefined ? RecursivePartial<T[P]> : T[P];
};
export declare const DISCARDED = "DISCARDED";
export declare const SKIPPED = "SKIPPED";
export type DISCARDED = typeof DISCARDED;
export type SKIPPED = typeof SKIPPED;
export type AbstractHooks = ReturnType<typeof abstractHooks>;
export declare function abstractHooks<T extends {
    [K in HookNames]: (...args: any[]) => unknown;
}>(): {
    register<K extends HookNames>(hookName: K, callback: T[K]): {
        unregister: () => void;
    };
    triggerHook<K extends HookNames>(hookName: K, param: Parameters<T[K]>[0]): Exclude<ReturnType<T[K]>, SKIPPED> | DISCARDED | undefined;
};
