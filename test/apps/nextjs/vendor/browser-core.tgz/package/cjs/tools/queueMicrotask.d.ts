export declare function queueMicrotask(callback: () => void): void;
