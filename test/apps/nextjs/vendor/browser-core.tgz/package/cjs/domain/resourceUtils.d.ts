export declare const ResourceType: {
    readonly DOCUMENT: "document";
    readonly XHR: "xhr";
    readonly BEACON: "beacon";
    readonly FETCH: "fetch";
    readonly CSS: "css";
    readonly JS: "js";
    readonly IMAGE: "image";
    readonly FONT: "font";
    readonly MEDIA: "media";
    readonly OTHER: "other";
};
export type ResourceType = (typeof ResourceType)[keyof typeof ResourceType];
export declare const RequestType: {
    readonly FETCH: "fetch";
    readonly XHR: "xhr";
};
export type RequestType = (typeof RequestType)[keyof typeof RequestType];
