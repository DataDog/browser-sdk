import type { Payload } from '../../transport';
import type { InitConfiguration } from './configuration';
export type TrackType = 'logs' | 'rum' | 'replay' | 'profile' | 'exposures' | 'flagevaluation';
export type ApiType = 'fetch' | 'beacon' | 'manual';
export type EndpointBuilder = ReturnType<typeof createEndpointBuilder>;
export declare function createEndpointBuilder(initConfiguration: InitConfiguration, trackType: TrackType, extraParameters?: string[]): {
    build(api: ApiType, payload: Payload): string;
    trackType: TrackType;
};
export declare function buildEndpointHost(trackType: TrackType, initConfiguration: InitConfiguration & {
    usePciIntake?: boolean;
}): string;
