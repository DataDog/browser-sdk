import type { InitConfiguration } from './configuration';
export declare const ERROR_DOES_NOT_HAVE_ALLOWED_TRACKING_ORIGIN = "Running the Browser SDK in a Web extension content script is forbidden unless the `allowedTrackingOrigins` option is provided.";
export declare const ERROR_NOT_ALLOWED_TRACKING_ORIGIN = "SDK initialized on a non-allowed domain.";
export declare function isAllowedTrackingOrigins(configuration: InitConfiguration, errorStack: string): boolean;
