import type { AbstractHooks } from '../../tools/abstractHooks';
import type { Configuration } from '../configuration';
export declare function startGlobalContext(hooks: AbstractHooks, configuration: Configuration, productKey: string, useContextNamespace: boolean): {
    getContext: () => import("../..").Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: import("../..").Observable<void>;
};
export declare function buildGlobalContextManager(): {
    getContext: () => import("../..").Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: import("../..").Observable<void>;
};
