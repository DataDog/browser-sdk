export declare const SESSION_ENTRY_REGEXP: RegExp;
export declare const SESSION_ENTRY_SEPARATOR = "&";
export declare function isValidSessionString(sessionString: string | undefined | null): sessionString is string;
