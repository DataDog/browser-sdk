import type { Site } from '../intakeSites';
import type { InitConfiguration } from './configuration';
import type { EndpointBuilder } from './endpointBuilder';
export interface TransportConfiguration {
    logsEndpointBuilder: EndpointBuilder;
    rumEndpointBuilder: EndpointBuilder;
    sessionReplayEndpointBuilder: EndpointBuilder;
    profilingEndpointBuilder: EndpointBuilder;
    exposuresEndpointBuilder: EndpointBuilder;
    flagEvaluationEndpointBuilder: EndpointBuilder;
    datacenter?: string | undefined;
    replica?: ReplicaConfiguration;
    site: Site;
    source: 'browser' | 'flutter' | 'unity';
}
export interface ReplicaConfiguration {
    logsEndpointBuilder: EndpointBuilder;
    rumEndpointBuilder: EndpointBuilder;
}
export declare function computeTransportConfiguration(initConfiguration: InitConfiguration): TransportConfiguration;
export declare function isIntakeUrl(url: string): boolean;
