import type { Context } from '../../tools/serialisation/context';
import { Observable } from '../../tools/observable';
export type ContextManager = ReturnType<typeof createContextManager>;
export interface PropertiesConfig {
    [key: string]: {
        required?: boolean;
        type?: 'string';
    };
}
export declare function createContextManager(name?: string, { propertiesConfig, }?: {
    propertiesConfig?: PropertiesConfig;
}): {
    getContext: () => Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: Observable<void>;
};
