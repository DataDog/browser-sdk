import type { Context } from '../../tools/serialisation/context';
/**
 * Simple check to ensure an object is a valid context
 */
export declare function checkContext(maybeContext: unknown): maybeContext is Context;
