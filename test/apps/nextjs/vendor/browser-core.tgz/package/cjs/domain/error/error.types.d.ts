import type { Context } from '../../tools/serialisation/context';
import type { ClocksState } from '../../tools/utils/timeUtils';
export interface ErrorWithCause extends Omit<Error, 'cause'> {
    cause?: unknown;
}
export interface RawErrorCause {
    message: string;
    source: ErrorSource;
    type?: string;
    stack?: string;
}
export interface Csp {
    disposition: 'enforce' | 'report';
}
export interface RawError {
    startClocks: ClocksState;
    message: string;
    type?: string;
    stack?: string;
    source: ErrorSource;
    originalError?: unknown;
    handling?: ErrorHandling;
    handlingStack?: string;
    componentStack?: string;
    causes?: RawErrorCause[];
    fingerprint?: string;
    csp?: Csp;
    context?: Context;
}
export declare const ErrorSource: {
    readonly AGENT: "agent";
    readonly CONSOLE: "console";
    readonly CUSTOM: "custom";
    readonly LOGGER: "logger";
    readonly NETWORK: "network";
    readonly SOURCE: "source";
    readonly REPORT: "report";
};
export declare const enum NonErrorPrefix {
    UNCAUGHT = "Uncaught",
    PROVIDED = "Provided"
}
export declare const enum ErrorHandling {
    HANDLED = "handled",
    UNHANDLED = "unhandled"
}
export type ErrorSource = (typeof ErrorSource)[keyof typeof ErrorSource];
