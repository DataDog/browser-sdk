export declare const EXTENSION_PREFIXES: string[];
export declare function containsExtensionUrl(str: string): boolean;
/**
 * Utility function to detect if the SDK is being initialized in an unsupported browser extension environment.
 *
 * @param windowLocation - The current window location to check
 * @param stack - The error stack to check for extension URLs
 * @returns true if running in an unsupported browser extension environment
 */
export declare function isUnsupportedExtensionEnvironment(windowLocation: string, stack?: string): boolean;
