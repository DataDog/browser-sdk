export declare const enum CustomerDataType {
    FeatureFlag = 0,
    User = 1,
    GlobalContext = 2,
    View = 3,
    Account = 4
}
export declare const CustomerContextKey: {
    readonly userContext: "userContext";
    readonly globalContext: "globalContext";
    readonly accountContext: "accountContext";
};
export type CustomerContextKey = (typeof CustomerContextKey)[keyof typeof CustomerContextKey];
export declare const ContextManagerMethod: {
    readonly getContext: "getContext";
    readonly setContext: "setContext";
    readonly setContextProperty: "setContextProperty";
    readonly removeContextProperty: "removeContextProperty";
    readonly clearContext: "clearContext";
};
export type ContextManagerMethod = (typeof ContextManagerMethod)[keyof typeof ContextManagerMethod];
