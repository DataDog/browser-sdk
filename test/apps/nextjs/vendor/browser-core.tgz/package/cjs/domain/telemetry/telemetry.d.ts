import type { Context } from '../../tools/serialisation/context';
import type { Configuration } from '../configuration';
import { BufferedObservable, Observable } from '../../tools/observable';
import type { StackTrace } from '../../tools/stackTrace/computeStackTrace';
import type { AbstractHooks } from '../../tools/abstractHooks';
import type { TelemetryEvent } from './telemetryEvent.types';
import type { RawTelemetryConfiguration, RawTelemetryEvent, RawTelemetryUsage } from './rawTelemetryEvent.types';
export declare const enum TelemetryService {
    LOGS = "browser-logs-sdk",
    RUM = "browser-rum-sdk"
}
export interface Telemetry {
    stop: () => void;
    enabled: boolean;
    metricsEnabled: boolean;
}
export declare const enum TelemetryMetrics {
    CUSTOMER_DATA_METRIC_NAME = "Customer data measures",
    REMOTE_CONFIGURATION_METRIC_NAME = "remote configuration metrics",
    RECORDER_INIT_METRICS_TELEMETRY_NAME = "Recorder init metrics",
    SEGMENT_METRICS_TELEMETRY_NAME = "Segment network request metrics",
    INITIAL_VIEW_METRICS_TELEMETRY_NAME = "Initial view metrics"
}
export declare function getTelemetryObservable(): BufferedObservable<{
    rawEvent: RawTelemetryEvent;
    metricName?: string;
}>;
export declare function startTelemetry(telemetryService: TelemetryService, configuration: Configuration, hooks: AbstractHooks): Telemetry;
export declare function startTelemetryCollection(telemetryService: TelemetryService, configuration: Configuration, hooks: AbstractHooks, observable: Observable<TelemetryEvent & Context>, metricSampleRate?: number, maxTelemetryEventsPerPage?: number): {
    enabled: boolean;
    metricsEnabled: boolean;
};
export declare function startTelemetryTransport(configuration: Configuration, telemetryObservable: Observable<TelemetryEvent & Context>): {
    stop: () => void;
};
export declare function resetTelemetry(): void;
export declare function addTelemetryDebug(message: string, context?: Context): void;
export declare function addTelemetryError(e: unknown, context?: Context): void;
export declare function addTelemetryConfiguration(configuration: RawTelemetryConfiguration): void;
export declare function addTelemetryMetrics(metricName: TelemetryMetrics, context?: Context): void;
export declare function addTelemetryUsage(usage: RawTelemetryUsage): void;
export declare function formatError(e: unknown): {
    error: {
        kind: string | undefined;
        stack: string;
    };
    message: string;
} | {
    error: {
        stack: string;
        kind?: undefined;
    };
    message: string;
};
export declare function scrubCustomerFrames(stackTrace: StackTrace): StackTrace;
