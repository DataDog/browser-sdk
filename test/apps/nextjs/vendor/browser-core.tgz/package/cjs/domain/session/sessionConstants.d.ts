export declare const SESSION_TIME_OUT_DELAY: number;
export declare const SESSION_EXPIRATION_DELAY: number;
export declare const SESSION_COOKIE_EXPIRATION_DELAY: number;
export declare const SESSION_NOT_TRACKED = "0";
/**
 * @internal
 */
export declare const SessionPersistence: {
    readonly COOKIE: "cookie";
    readonly MEMORY: "memory";
    readonly LOCAL_STORAGE: "local-storage";
};
/**
 * @inline
 */
export type SessionPersistence = (typeof SessionPersistence)[keyof typeof SessionPersistence];
