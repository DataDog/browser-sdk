export type Site = 'datadoghq.com' | 'us3.datadoghq.com' | 'us5.datadoghq.com' | 'datadoghq.eu' | 'ddog-gov.com' | 'ap1.datadoghq.com' | 'ap2.datadoghq.com' | (string & {});
export declare const INTAKE_SITE_STAGING: Site;
export declare const INTAKE_SITE_FED_STAGING: Site;
export declare const INTAKE_SITE_US1: Site;
export declare const INTAKE_SITE_EU1: Site;
export declare const INTAKE_SITE_US1_FED: Site;
export declare const PCI_INTAKE_HOST_US1 = "pci.browser-intake-datadoghq.com";
export declare const INTAKE_URL_PARAMETERS: string[];
