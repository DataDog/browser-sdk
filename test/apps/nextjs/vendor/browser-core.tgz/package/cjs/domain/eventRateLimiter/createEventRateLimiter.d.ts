import type { RawError } from '../error/error.types';
export type EventRateLimiter = ReturnType<typeof createEventRateLimiter>;
export declare function createEventRateLimiter(eventType: string, onLimitReached: (limitError: RawError) => void, limit?: number): {
    isLimitReached(): boolean;
};
