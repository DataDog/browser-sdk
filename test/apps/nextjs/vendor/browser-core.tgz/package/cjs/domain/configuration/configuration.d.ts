import type { SessionStoreStrategyType } from '../session/storeStrategies/sessionStoreStrategy';
import { TrackingConsent } from '../trackingConsent';
import type { SessionPersistence } from '../session/sessionConstants';
import type { MatchOption } from '../../tools/matchOption';
import type { Site } from '../intakeSites';
import type { TransportConfiguration } from './transportConfiguration';
/**
 * Default privacy level for the browser SDK.
 *
 * [Replay Privacy Options](https://docs.datadoghq.com/real_user_monitoring/session_replay/browser/privacy_options) for further information.
 */
export declare const DefaultPrivacyLevel: {
    readonly ALLOW: "allow";
    readonly MASK: "mask";
    readonly MASK_USER_INPUT: "mask-user-input";
    readonly MASK_UNLESS_ALLOWLISTED: "mask-unless-allowlisted";
};
export type DefaultPrivacyLevel = (typeof DefaultPrivacyLevel)[keyof typeof DefaultPrivacyLevel];
/**
 * Trace context injection option.
 *
 * See [Connect RUM and Traces](https://docs.datadoghq.com/real_user_monitoring/platform/connect_rum_and_traces/?tab=browserrum) for further information.
 */
export declare const TraceContextInjection: {
    readonly ALL: "all";
    readonly SAMPLED: "sampled";
};
/**
 * Trace context injection option.
 *
 * See [Connect RUM and Traces](https://docs.datadoghq.com/real_user_monitoring/platform/connect_rum_and_traces/?tab=browserrum) for further information.
 *
 */
export type TraceContextInjection = (typeof TraceContextInjection)[keyof typeof TraceContextInjection];
export interface InitConfiguration {
    /**
     * The client token for Datadog. Required for authenticating your application with Datadog.
     *
     * @category Authentication
     */
    clientToken: string;
    /**
     * A callback function that can be used to modify events before they are sent to Datadog.
     *
     * @category Data Collection
     */
    beforeSend?: GenericBeforeSendCallback | undefined;
    /**
     * The percentage of sessions tracked. A value between 0 and 100.
     *
     * @category Data Collection
     * @defaultValue 100
     */
    sessionSampleRate?: number | undefined;
    /**
     * The percentage of telemetry events sent. A value between 0 and 100.
     *
     * @category Data Collection
     * @defaultValue 20
     */
    telemetrySampleRate?: number | undefined;
    /**
     * Initialization fails silently if the RUM Browser SDK is already initialized on the page.
     *
     * @defaultValue false
     */
    silentMultipleInit?: boolean | undefined;
    /**
     * Which storage strategy to use for persisting sessions. Can be 'cookie', 'local-storage', or 'memory'.
     * When an array is provided, the SDK will attempt each persistence type in the order specified.
     *
     * Important: If you are using the RUM and Logs Browser SDKs, this option must be configured with identical values
     *
     * Note: 'memory' option is only for use with single-page applications. All page loads will start a new session, likely resulting in an increase in total number of RUM sessions
     *
     * @category Session Persistence
     * @defaultValue "cookie"
     */
    sessionPersistence?: SessionPersistence | SessionPersistence[] | undefined;
    /**
     * Allows the use of localStorage when cookies cannot be set. This enables the RUM Browser SDK to run in environments that do not provide cookie support.
     *
     * Important: If you are using the RUM and Logs Browser SDKs, this option must be configured with identical values
     * See [Monitor Electron Applications Using the Browser SDK](https://docs.datadoghq.com/real_user_monitoring/guide/monitor-electron-applications-using-browser-sdk) for further information.
     *
     * @category Session Persistence
     * @deprecated use `sessionPersistence: local-storage` where you want to use localStorage instead
     */
    allowFallbackToLocalStorage?: boolean | undefined;
    /**
     * Allow listening to DOM events dispatched programmatically ([untrusted events](https://developer.mozilla.org/en-US/docs/Web/API/Event/isTrusted)). Enabling this option can be useful if you heavily rely on programmatic events, such as in an automated UI test environment.
     *
     * @defaultValue false
     */
    allowUntrustedEvents?: boolean | undefined;
    /**
     * Store global context and user context in localStorage to preserve them along the user navigation.
     * See [Contexts life cycle](https://docs.datadoghq.com/real_user_monitoring/browser/advanced_configuration/?tab=npm#contexts-life-cycle) for further information.
     *
     * @defaultValue false
     */
    storeContextsAcrossPages?: boolean | undefined;
    /**
     * Set the initial user tracking consent state.
     * See [User tracking consent](https://docs.datadoghq.com/real_user_monitoring/browser/advanced_configuration/?tab=npm#user-tracking-consent) for further information.
     *
     * @category Privacy
     * @defaultValue granted
     */
    trackingConsent?: TrackingConsent | undefined;
    /**
     * List of origins where the SDK is allowed to run when used in a browser extension context.
     * Matches urls against the extensions origin.
     * If not provided and the SDK is running in a browser extension, the SDK will not run.
     */
    allowedTrackingOrigins?: MatchOption[] | undefined;
    /**
     * Optional proxy URL, for example: https://www.proxy.com/path.
     * See [Proxy Your Browser RUM Data](https://docs.datadoghq.com/real_user_monitoring/guide/proxy-rum-data) for further information.
     *
     * @category Transport
     */
    proxy?: string | ProxyFn | undefined;
    /**
     * The Datadog [site](https://docs.datadoghq.com/getting_started/site) parameter of your organization.
     *
     * @category Transport
     * @defaultValue datadoghq.com
     */
    site?: Site | undefined;
    /**
     * The service name for your application. Follows the [tag syntax requirements](https://docs.datadoghq.com/getting_started/tagging/#define-tags).
     *
     * @category Data Collection
     */
    service?: string | undefined | null;
    /**
     * The application’s environment, for example: prod, pre-prod, and staging. Follows the [tag syntax requirements](https://docs.datadoghq.com/getting_started/tagging/#define-tags).
     *
     * @category Data Collection
     */
    env?: string | undefined | null;
    /**
     * The application’s version, for example: 1.2.3, 6c44da20, and 2020.02.13. Follows the [tag syntax requirements](https://docs.datadoghq.com/getting_started/tagging/#define-tags).
     *
     * @category Data Collection
     */
    version?: string | undefined | null;
    /**
     * Use a partitioned secure cross-site session cookie. This allows the RUM Browser SDK to run when the site is loaded from another one (iframe). Implies `useSecureSessionCookie`.
     *
     * Important: If you are using the RUM and Logs Browser SDKs, this option must be configured with identical values
     *
     * @category Session Persistence
     * @defaultValue false
     */
    usePartitionedCrossSiteSessionCookie?: boolean | undefined;
    /**
     * Use a secure session cookie. This disables RUM events sent on insecure (non-HTTPS) connections.
     *
     * Important: If you are using the RUM and Logs Browser SDKs, this option must be configured with identical values
     *
     * @category Session Persistence
     * @defaultValue false
     */
    useSecureSessionCookie?: boolean | undefined;
    /**
     * Preserve the session across subdomains for the same site.
     *
     * Important: If you are using the RUM and Logs Browser SDKs, this option must be configured with identical values
     *
     * @category Session Persistence
     * @defaultValue false
     */
    trackSessionAcrossSubdomains?: boolean | undefined;
    /**
     * Track anonymous user for the same site and extend cookie expiration date
     *
     * @category Data Collection
     * @defaultValue true
     */
    trackAnonymousUser?: boolean | undefined;
    /**
     * Encode cookie options in the cookie value. This can be used as a mitigation for microssession issues.
     * ⚠️ This is a beta feature and may be changed or removed in the future.
     *
     * @category Beta
     * @defaultValue false
     */
    betaEncodeCookieOptions?: boolean | undefined;
    /**
     * [Internal option] Enable experimental features
     *
     * @internal
     */
    enableExperimentalFeatures?: string[] | undefined;
    /**
     * [Internal option] Configure the dual shipping to another datacenter
     *
     * @internal
     */
    replica?: ReplicaUserConfiguration | undefined;
    /**
     * [Internal option] Set the datacenter from where the data is dual shipped
     *
     * @internal
     */
    datacenter?: string;
    /**
     * [Internal option] Datadog internal analytics subdomain
     *
     * @internal
     */
    internalAnalyticsSubdomain?: string;
    /**
     * [Internal option] The percentage of telemetry configuration sent. A value between 0 and 100.
     *
     * @internal
     * @defaultValue 5
     */
    telemetryConfigurationSampleRate?: number;
    /**
     * [Internal option] The percentage of telemetry usage sent. A value between 0 and 100.
     *
     * @internal
     * @defaultValue 5
     */
    telemetryUsageSampleRate?: number;
    /**
     * [Internal option] Additional configuration for the SDK.
     *
     * @internal
     */
    source?: 'browser' | 'flutter' | 'unity' | undefined;
    /**
     * [Internal option] Additional configuration for the SDK.
     *
     * @internal
     */
    sdkVersion?: string | undefined;
    /**
     * [Internal option] Additional configuration for the SDK.
     *
     * @internal
     */
    variant?: string | undefined;
}
type GenericBeforeSendCallback = (event: any, context?: any) => unknown;
/**
 * path: /api/vX/product
 * parameters: xxx=yyy&zzz=aaa
 */
export type ProxyFn = (options: {
    path: string;
    parameters: string;
}) => string;
/**
 * @internal
 */
export interface ReplicaUserConfiguration {
    applicationId?: string;
    clientToken: string;
}
export interface Configuration extends TransportConfiguration {
    beforeSend: GenericBeforeSendCallback | undefined;
    sessionStoreStrategyType: SessionStoreStrategyType | undefined;
    sessionSampleRate: number;
    telemetrySampleRate: number;
    telemetryConfigurationSampleRate: number;
    telemetryUsageSampleRate: number;
    service?: string | undefined;
    version?: string | undefined;
    env?: string | undefined;
    silentMultipleInit: boolean;
    allowUntrustedEvents: boolean;
    trackingConsent: TrackingConsent;
    storeContextsAcrossPages: boolean;
    trackAnonymousUser?: boolean;
    betaEncodeCookieOptions: boolean;
    sdkVersion: string | undefined;
    source: 'browser' | 'flutter' | 'unity';
    variant: string | undefined;
}
export declare function isSampleRate(sampleRate: unknown, name: string): boolean;
export declare function validateAndBuildConfiguration(initConfiguration: InitConfiguration, errorStack?: string): Configuration | undefined;
export declare function serializeConfiguration(initConfiguration: InitConfiguration): {
    session_sample_rate: number | undefined;
    telemetry_sample_rate: number | undefined;
    telemetry_configuration_sample_rate: number | undefined;
    telemetry_usage_sample_rate: number | undefined;
    use_before_send: boolean;
    use_partitioned_cross_site_session_cookie: boolean | undefined;
    use_secure_session_cookie: boolean | undefined;
    use_proxy: boolean;
    silent_multiple_init: boolean | undefined;
    track_session_across_subdomains: boolean | undefined;
    track_anonymous_user: boolean | undefined;
    session_persistence: SessionPersistence | undefined;
    allow_fallback_to_local_storage: boolean;
    store_contexts_across_pages: boolean;
    allow_untrusted_events: boolean;
    tracking_consent: TrackingConsent | undefined;
    use_allowed_tracking_origins: boolean;
    beta_encode_cookie_options: boolean | undefined;
    source: "browser" | "flutter" | "unity" | undefined;
    sdk_version: string | undefined;
    variant: string | undefined;
};
export {};
