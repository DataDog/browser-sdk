import type { Configuration } from '../../configuration';
import type { SessionStoreStrategy, SessionStoreStrategyType } from './sessionStoreStrategy';
/**
 * Key used to store session state in the global object.
 * This allows RUM and Logs SDKs to share the same session when using memory storage.
 */
export declare const MEMORY_SESSION_STORE_KEY = "_DD_SESSION";
export declare function selectMemorySessionStoreStrategy(): SessionStoreStrategyType;
export declare function initMemorySessionStoreStrategy(configuration: Configuration): SessionStoreStrategy;
