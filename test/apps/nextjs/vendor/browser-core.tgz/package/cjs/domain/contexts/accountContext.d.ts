import type { Configuration } from '../configuration';
import type { AbstractHooks } from '../../tools/abstractHooks';
/**
 * Account information for the browser SDK.
 */
export interface Account {
    id: string;
    name?: string | undefined;
    [key: string]: unknown;
}
export declare function startAccountContext(hooks: AbstractHooks, configuration: Configuration, productKey: string): {
    getContext: () => import("../..").Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: import("../..").Observable<void>;
};
export declare function buildAccountContextManager(): {
    getContext: () => import("../..").Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: import("../..").Observable<void>;
};
