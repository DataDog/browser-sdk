import { Observable } from '../../tools/observable';
import type { InitConfiguration, Configuration } from '../configuration';
import type { SessionStoreStrategy, SessionStoreStrategyType } from './storeStrategies/sessionStoreStrategy';
import type { SessionState } from './sessionState';
export interface SessionStore {
    expandOrRenewSession: () => void;
    expandSession: () => void;
    getSession: () => SessionState;
    restartSession: () => void;
    renewObservable: Observable<void>;
    expireObservable: Observable<void>;
    sessionStateUpdateObservable: Observable<{
        previousState: SessionState;
        newState: SessionState;
    }>;
    expire: (hasConsent?: boolean) => void;
    stop: () => void;
    updateSessionState: (state: Partial<SessionState>) => void;
}
/**
 * Every second, the storage will be polled to check for any change that can occur
 * to the session state in another browser tab, or another window.
 * This value has been determined from our previous cookie-only implementation.
 */
export declare const STORAGE_POLL_DELAY = 1000;
/**
 * Selects the correct session store strategy type based on the configuration and storage
 * availability. When an array is provided, tries each persistence type in order until one
 * successfully initializes.
 */
export declare function selectSessionStoreStrategyType(initConfiguration: InitConfiguration): SessionStoreStrategyType | undefined;
export declare function getSessionStoreStrategy(sessionStoreStrategyType: SessionStoreStrategyType, configuration: Configuration): SessionStoreStrategy;
/**
 * Different session concepts:
 * - tracked, the session has an id and is updated along the user navigation
 * - not tracked, the session does not have an id but it is updated along the user navigation
 * - inactive, no session in store or session expired, waiting for a renew session
 */
export declare function startSessionStore<TrackingType extends string>(sessionStoreStrategyType: SessionStoreStrategyType, configuration: Configuration, productKey: string, computeTrackingType: (rawTrackingType?: string) => TrackingType, sessionStoreStrategy?: SessionStoreStrategy): SessionStore;
