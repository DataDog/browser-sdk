import { Observable } from '../../tools/observable';
import { ConsoleApiName } from '../../tools/display';
import type { RawError } from '../error/error.types';
export type ConsoleLog = NonErrorConsoleLog | ErrorConsoleLog;
interface NonErrorConsoleLog extends ConsoleLogBase {
    api: Exclude<ConsoleApiName, typeof ConsoleApiName.error>;
    error: undefined;
}
export interface ErrorConsoleLog extends ConsoleLogBase {
    api: typeof ConsoleApiName.error;
    error: RawError;
}
interface ConsoleLogBase {
    message: string;
    api: ConsoleApiName;
    handlingStack: string;
}
type ConsoleLogForApi<T extends ConsoleApiName> = T extends typeof ConsoleApiName.error ? ErrorConsoleLog : NonErrorConsoleLog;
export declare function initConsoleObservable<T extends ConsoleApiName[]>(apis: T): Observable<ConsoleLogForApi<T[number]>>;
export declare function resetConsoleObservable(): void;
export {};
