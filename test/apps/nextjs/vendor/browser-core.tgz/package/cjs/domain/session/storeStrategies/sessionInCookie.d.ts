import type { CookieOptions } from '../../../browser/cookie';
import type { InitConfiguration, Configuration } from '../../configuration';
import type { SessionState } from '../sessionState';
import type { SessionStoreStrategy, SessionStoreStrategyType } from './sessionStoreStrategy';
export declare function selectCookieStrategy(initConfiguration: InitConfiguration): SessionStoreStrategyType | undefined;
export declare function initCookieStrategy(configuration: Configuration, cookieOptions: CookieOptions): SessionStoreStrategy;
/**
 * Retrieve the session state from the cookie that was set with the same cookie options
 * If there is no match, return the first cookie, because that's how `getCookie()` works
 */
export declare function retrieveSessionCookie(cookieOptions: CookieOptions, configuration: Configuration): SessionState;
export declare function buildCookieOptions(initConfiguration: InitConfiguration): CookieOptions | undefined;
