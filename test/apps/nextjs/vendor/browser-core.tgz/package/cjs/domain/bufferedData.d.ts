import { BufferedObservable } from '../tools/observable';
import type { RawError } from './error/error.types';
export declare const enum BufferedDataType {
    RUNTIME_ERROR = 0
}
export interface BufferedData {
    type: BufferedDataType.RUNTIME_ERROR;
    error: RawError;
}
export declare function startBufferingData(): {
    observable: BufferedObservable<BufferedData>;
    stop: () => void;
};
