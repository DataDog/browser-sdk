import type { AbstractHooks } from '../../tools/abstractHooks';
import type { Configuration } from '../configuration';
import type { RelativeTime } from '../../tools/utils/timeUtils';
export interface User {
    id?: string | undefined;
    email?: string | undefined;
    name?: string | undefined;
    [key: string]: unknown;
}
export declare function startUserContext(hooks: AbstractHooks, configuration: Configuration, sessionManager: {
    findTrackedSession: (startTime?: RelativeTime) => {
        anonymousId?: string;
    } | undefined;
}, productKey: string): {
    getContext: () => import("../..").Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: import("../..").Observable<void>;
};
export declare function buildUserContextManager(): {
    getContext: () => import("../..").Context;
    setContext: (newContext: unknown) => void;
    setContextProperty: (key: string, property: any) => void;
    removeContextProperty: (key: string) => void;
    clearContext: () => void;
    changeObservable: import("../..").Observable<void>;
};
