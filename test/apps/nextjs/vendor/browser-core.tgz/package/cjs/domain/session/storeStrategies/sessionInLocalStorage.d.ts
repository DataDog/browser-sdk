import type { Configuration } from '../../configuration';
import type { SessionState } from '../sessionState';
import type { SessionStoreStrategy, SessionStoreStrategyType } from './sessionStoreStrategy';
export declare function selectLocalStorageStrategy(): SessionStoreStrategyType | undefined;
export declare function initLocalStorageStrategy(configuration: Configuration): SessionStoreStrategy;
export declare function retrieveSessionFromLocalStorage(): SessionState;
