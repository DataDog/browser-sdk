import type { RawTelemetryUsageFeature } from '../telemetry';
import type { BoundedBuffer } from '../../tools/boundedBuffer';
import type { ContextManager } from './contextManager';
import type { ContextManagerMethod, CustomerContextKey } from './contextConstants';
export declare function defineContextMethod<MethodName extends ContextManagerMethod, Key extends CustomerContextKey>(getStrategy: () => Record<Key, ContextManager>, contextName: Key, methodName: MethodName, usage?: RawTelemetryUsageFeature): ContextManager[MethodName];
export declare function bufferContextCalls<Key extends string, StartResult extends Record<Key, ContextManager>>(preStartContextManager: ContextManager, name: Key, bufferApiCalls: BoundedBuffer<StartResult>): void;
