import { Observable } from '../../tools/observable';
import type { Configuration } from '../configuration';
import type { RawError } from '../error/error.types';
import type { InterventionReport, DeprecationReport } from './browser.types';
export declare const RawReportType: {
    readonly intervention: "intervention";
    readonly deprecation: "deprecation";
    readonly cspViolation: "csp_violation";
};
export type RawReportType = (typeof RawReportType)[keyof typeof RawReportType];
export type RawReportError = RawError & {
    originalError: SecurityPolicyViolationEvent | DeprecationReport | InterventionReport;
};
export declare function initReportObservable(configuration: Configuration, apis: RawReportType[]): Observable<RawReportError>;
