import { Observable } from '../../tools/observable';
import type { StackTrace } from '../../tools/stackTrace/computeStackTrace';
import type { RawError } from './error.types';
export type UnhandledErrorCallback = (originalError: unknown, stackTrace?: StackTrace) => any;
export declare function trackRuntimeError(): Observable<RawError>;
export declare function instrumentOnError(callback: UnhandledErrorCallback): {
    stop: typeof import("../..").noop;
};
export declare function instrumentUnhandledRejection(callback: UnhandledErrorCallback): {
    stop: typeof import("../..").noop;
};
