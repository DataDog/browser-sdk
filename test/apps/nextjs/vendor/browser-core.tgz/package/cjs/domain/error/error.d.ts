import type { ClocksState } from '../../tools/utils/timeUtils';
import type { Context } from '../../tools/serialisation/context';
import type { StackTrace } from '../../tools/stackTrace/computeStackTrace';
import type { ErrorSource, ErrorHandling, RawError, RawErrorCause, ErrorWithCause, NonErrorPrefix } from './error.types';
export declare const NO_ERROR_STACK_PRESENT_MESSAGE = "No stack, consider using an instance of Error";
interface RawErrorParams {
    stackTrace?: StackTrace;
    originalError: unknown;
    handlingStack?: string;
    componentStack?: string;
    startClocks: ClocksState;
    nonErrorPrefix: NonErrorPrefix;
    useFallbackStack?: boolean;
    source: ErrorSource;
    handling: ErrorHandling;
}
export declare function computeRawError({ stackTrace, originalError, handlingStack, componentStack, startClocks, nonErrorPrefix, useFallbackStack, source, handling, }: RawErrorParams): RawError;
export declare function tryToGetFingerprint(originalError: unknown): string | undefined;
export declare function tryToGetErrorContext(originalError: unknown): Context | undefined;
export declare function getFileFromStackTraceString(stack: string): string | undefined;
export declare function isError(error: unknown): error is Error;
export declare function flattenErrorCauses(error: ErrorWithCause, parentSource: ErrorSource): RawErrorCause[] | undefined;
export {};
