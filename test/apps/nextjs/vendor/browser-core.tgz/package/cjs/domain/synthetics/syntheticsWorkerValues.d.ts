export declare const SYNTHETICS_TEST_ID_COOKIE_NAME = "datadog-synthetics-public-id";
export declare const SYNTHETICS_RESULT_ID_COOKIE_NAME = "datadog-synthetics-result-id";
export declare const SYNTHETICS_INJECTS_RUM_COOKIE_NAME = "datadog-synthetics-injects-rum";
export declare const SYNTHETICS_CONTEXT_COOKIE_NAME = "datadog-synthetics-rum-context";
export interface BrowserWindow extends Window {
    _DATADOG_SYNTHETICS_PUBLIC_ID?: unknown;
    _DATADOG_SYNTHETICS_RESULT_ID?: unknown;
    _DATADOG_SYNTHETICS_INJECTS_RUM?: unknown;
    _DATADOG_SYNTHETICS_RUM_CONTEXT?: unknown;
}
export interface SyntheticsContext {
    test_id: string;
    result_id: string;
    [key: string]: unknown;
}
export declare function willSyntheticsInjectRum(): boolean;
export declare function getSyntheticsContext(): SyntheticsContext | undefined;
export declare function isSyntheticsTest(): boolean;
