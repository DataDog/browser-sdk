import type { Configuration } from './configuration';
export declare const TAG_SIZE_LIMIT = 200;
export declare function buildTags(configuration: Configuration): string[];
export declare function buildTag(key: string, rawValue?: string): string;
export declare function sanitizeTag(tag: string): string;
export declare function supportUnicodePropertyEscapes(): boolean;
