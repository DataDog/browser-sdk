import type { Context } from '../tools/serialisation/context';
import type { Encoder } from '../tools/encoder';
import type { HttpRequest } from './httpRequest';
import type { FlushController } from './flushController';
export declare const MESSAGE_BYTES_LIMIT: number;
export interface Batch {
    flushController: FlushController;
    add: (message: Context) => void;
    upsert: (message: Context, key: string) => void;
    stop: () => void;
}
export declare function createBatch({ encoder, request, flushController, }: {
    encoder: Encoder;
    request: HttpRequest;
    flushController: FlushController;
}): Batch;
