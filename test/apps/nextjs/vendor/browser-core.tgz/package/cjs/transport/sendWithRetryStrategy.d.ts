import type { TrackType } from '../domain/configuration';
import type { RawError } from '../domain/error/error.types';
import type { Observable } from '../tools/observable';
import type { Payload, HttpRequestEvent, HttpResponse, BandwidthStats } from './httpRequest';
export declare const MAX_ONGOING_BYTES_COUNT: number;
export declare const MAX_ONGOING_REQUESTS = 32;
export declare const MAX_QUEUE_BYTES_COUNT: number;
export declare const MAX_BACKOFF_TIME: number;
export declare const INITIAL_BACKOFF_TIME = 1000;
declare const enum TransportStatus {
    UP = 0,
    FAILURE_DETECTED = 1,
    DOWN = 2
}
export interface RetryState<Body extends Payload> {
    transportStatus: TransportStatus;
    currentBackoffTime: number;
    bandwidthMonitor: ReturnType<typeof newBandwidthMonitor>;
    queuedPayloads: ReturnType<typeof newPayloadQueue<Body>>;
    queueFullReported: boolean;
}
type SendStrategy<Body extends Payload> = (payload: Body, onResponse: (r: HttpResponse) => void) => void;
export declare function sendWithRetryStrategy<Body extends Payload>(payload: Body, state: RetryState<Body>, sendStrategy: SendStrategy<Body>, trackType: TrackType, reportError: (error: RawError) => void, requestObservable: Observable<HttpRequestEvent<Body>>): void;
export declare function newRetryState<Body extends Payload>(): RetryState<Body>;
declare function newPayloadQueue<Body extends Payload>(): {
    bytesCount: number;
    enqueue(payload: Body): boolean;
    first(): Body;
    dequeue(): Body | undefined;
    size(): number;
    isFull(): boolean;
};
declare function newBandwidthMonitor(): {
    ongoingRequestCount: number;
    ongoingByteCount: number;
    canHandle(payload: Payload): boolean;
    add(payload: Payload): void;
    remove(payload: Payload): void;
    stats(): BandwidthStats;
};
export {};
