import type { EndpointBuilder } from '../domain/configuration';
import type { Context } from '../tools/serialisation/context';
import type { RawError } from '../domain/error/error.types';
import { Observable } from '../tools/observable';
/**
 * beacon payload max queue size implementation is 64kb
 * ensure that we leave room for logs, rum and potential other users
 */
export declare const RECOMMENDED_REQUEST_BYTES_LIMIT: number;
/**
 * Use POST request without content type to:
 * - avoid CORS preflight requests
 * - allow usage of sendBeacon
 *
 * multiple elements are sent separated by \n in order
 * to be parsed correctly without content type header
 */
export interface HttpRequest<Body extends Payload = Payload> {
    observable: Observable<HttpRequestEvent<Body>>;
    send(this: void, payload: Body): void;
    sendOnExit(this: void, payload: Body): void;
}
export interface HttpResponse extends Context {
    status: number;
    type?: ResponseType;
}
export interface BandwidthStats {
    ongoingByteCount: number;
    ongoingRequestCount: number;
}
export type HttpRequestEvent<Body extends Payload = Payload> = {
    type: 'failure';
    bandwidth: BandwidthStats;
    payload: Body;
} | {
    type: 'queue-full';
    bandwidth: BandwidthStats;
    payload: Body;
} | {
    type: 'success';
    bandwidth: BandwidthStats;
    payload: Body;
};
export interface Payload {
    data: string | FormData | Blob;
    bytesCount: number;
    retry?: RetryInfo;
    encoding?: 'deflate';
}
export interface RetryInfo {
    count: number;
    lastFailureStatus: number;
}
export declare function createHttpRequest<Body extends Payload = Payload>(endpointBuilders: EndpointBuilder[], reportError: (error: RawError) => void, bytesLimit?: number): HttpRequest<Body>;
export declare function fetchStrategy(endpointBuilder: EndpointBuilder, payload: Payload, onResponse?: (r: HttpResponse) => void): void;
