import type { Configuration } from '../domain/configuration';
export declare function runOnReadyState(configuration: Configuration, expectedReadyState: 'complete' | 'interactive', callback: () => void): {
    stop: () => void;
};
export declare function asyncRunOnReadyState(configuration: Configuration, expectedReadyState: 'complete' | 'interactive'): Promise<void>;
