export interface CookieOptions {
    secure?: boolean;
    crossSite?: boolean;
    partitioned?: boolean;
    domain?: string;
}
export declare function setCookie(name: string, value: string, expireDelay?: number, options?: CookieOptions): void;
/**
 * Returns the value of the cookie with the given name
 * If there are multiple cookies with the same name, returns the first one
 */
export declare function getCookie(name: string): string | undefined;
/**
 * Returns all the values of the cookies with the given name
 */
export declare function getCookies(name: string): string[];
/**
 * Returns a cached value of the cookie. Use this during SDK initialization (and whenever possible)
 * to avoid accessing document.cookie multiple times.
 *
 * ⚠️ If there are multiple cookies with the same name, returns the LAST one (unlike `getCookie()`)
 */
export declare function getInitCookie(name: string): string | undefined;
export declare function resetInitCookies(): void;
export declare function deleteCookie(name: string, options?: CookieOptions): void;
export declare function areCookiesAuthorized(options: CookieOptions): boolean;
export declare function getCurrentSite(hostname?: string, referrer?: string): string | undefined;
export declare function resetGetCurrentSite(): void;
