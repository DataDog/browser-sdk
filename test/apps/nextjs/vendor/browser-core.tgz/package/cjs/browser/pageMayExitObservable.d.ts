import { Observable } from '../tools/observable';
import type { Configuration } from '../domain/configuration';
export declare const PageExitReason: {
    readonly HIDDEN: "visibility_hidden";
    readonly UNLOADING: "before_unload";
    readonly PAGEHIDE: "page_hide";
    readonly FROZEN: "page_frozen";
};
export type PageExitReason = (typeof PageExitReason)[keyof typeof PageExitReason];
export interface PageMayExitEvent {
    reason: PageExitReason;
}
export declare function createPageMayExitObservable(configuration: Configuration): Observable<PageMayExitEvent>;
export declare function isPageExitReason(reason: string): reason is PageExitReason;
