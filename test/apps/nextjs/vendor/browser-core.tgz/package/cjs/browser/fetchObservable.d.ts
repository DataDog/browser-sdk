import { Observable } from '../tools/observable';
import type { ClocksState } from '../tools/utils/timeUtils';
interface FetchContextBase {
    method: string;
    startClocks: ClocksState;
    input: unknown;
    init?: RequestInit;
    url: string;
    handlingStack?: string;
    isAbortedOnStart: boolean;
}
export interface FetchStartContext extends FetchContextBase {
    state: 'start';
}
export interface FetchResolveContext extends FetchContextBase {
    state: 'resolve';
    status: number;
    response?: Response;
    responseBody?: string;
    responseType?: string;
    isAborted: boolean;
    error?: Error;
}
export type FetchContext = FetchStartContext | FetchResolveContext;
type ResponseBodyActionGetter = (context: FetchResolveContext) => ResponseBodyAction;
/**
 * Action to take with the response body of a fetch request.
 * Values are ordered by priority: higher values take precedence when multiple actions are requested.
 */
export declare const enum ResponseBodyAction {
    IGNORE = 0,
    WAIT = 1,
    COLLECT = 2
}
export declare function initFetchObservable({ responseBodyAction }?: {
    responseBodyAction?: ResponseBodyActionGetter;
}): Observable<FetchContext>;
export declare function resetFetchObservable(): void;
export {};
