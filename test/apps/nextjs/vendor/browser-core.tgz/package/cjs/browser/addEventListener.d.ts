import type { CookieStore, CookieStoreEventMap, VisualViewport, VisualViewportEventMap } from './browser.types';
export type TrustableEvent<E extends Event = Event> = E & {
    __ddIsTrusted?: boolean;
};
export declare const enum DOM_EVENT {
    BEFORE_UNLOAD = "beforeunload",
    CLICK = "click",
    DBL_CLICK = "dblclick",
    KEY_DOWN = "keydown",
    LOAD = "load",
    POP_STATE = "popstate",
    SCROLL = "scroll",
    TOUCH_START = "touchstart",
    TOUCH_END = "touchend",
    TOUCH_MOVE = "touchmove",
    VISIBILITY_CHANGE = "visibilitychange",
    PAGE_SHOW = "pageshow",
    FREEZE = "freeze",
    RESUME = "resume",
    DOM_CONTENT_LOADED = "DOMContentLoaded",
    POINTER_DOWN = "pointerdown",
    POINTER_UP = "pointerup",
    POINTER_CANCEL = "pointercancel",
    HASH_CHANGE = "hashchange",
    PAGE_HIDE = "pagehide",
    MOUSE_DOWN = "mousedown",
    MOUSE_UP = "mouseup",
    MOUSE_MOVE = "mousemove",
    FOCUS = "focus",
    BLUR = "blur",
    CONTEXT_MENU = "contextmenu",
    RESIZE = "resize",
    CHANGE = "change",
    INPUT = "input",
    PLAY = "play",
    PAUSE = "pause",
    SECURITY_POLICY_VIOLATION = "securitypolicyviolation",
    SELECTION_CHANGE = "selectionchange",
    STORAGE = "storage"
}
interface AddEventListenerOptions {
    once?: boolean;
    capture?: boolean;
    passive?: boolean;
}
type EventMapFor<T> = T extends Window ? WindowEventMap & {
    freeze: Event;
    resume: Event;
    visibilitychange: Event;
} : T extends Document ? DocumentEventMap : T extends HTMLElement ? HTMLElementEventMap : T extends VisualViewport ? VisualViewportEventMap : T extends ShadowRoot ? GlobalEventHandlersEventMap : T extends XMLHttpRequest ? XMLHttpRequestEventMap : T extends Performance ? PerformanceEventMap : T extends Worker ? WorkerEventMap : T extends CookieStore ? CookieStoreEventMap : Record<never, never>;
/**
 * Add an event listener to an event target object (Window, Element, mock object...).  This provides
 * a few conveniences compared to using `element.addEventListener` directly:
 *
 * * supports IE11 by: using an option object only if needed and emulating the `once` option
 *
 * * wraps the listener with a `monitor` function
 *
 * * returns a `stop` function to remove the listener
 */
export declare function addEventListener<Target extends EventTarget, EventName extends keyof EventMapFor<Target> & string>(configuration: {
    allowUntrustedEvents?: boolean | undefined;
}, eventTarget: Target, eventName: EventName, listener: (event: EventMapFor<Target>[EventName] & {
    type: EventName;
}) => void, options?: AddEventListenerOptions): {
    stop: () => void;
};
/**
 * Add event listeners to an event target object (Window, Element, mock object...).  This provides
 * a few conveniences compared to using `element.addEventListener` directly:
 *
 * * supports IE11 by: using an option object only if needed and emulating the `once` option
 *
 * * wraps the listener with a `monitor` function
 *
 * * returns a `stop` function to remove the listener
 *
 * * with `once: true`, the listener will be called at most once, even if different events are listened
 */
export declare function addEventListeners<Target extends EventTarget, EventName extends keyof EventMapFor<Target> & string>(configuration: {
    allowUntrustedEvents?: boolean | undefined;
}, eventTarget: Target, eventNames: EventName[], listener: (event: EventMapFor<Target>[EventName] & {
    type: EventName;
}) => void, { once, capture, passive }?: AddEventListenerOptions): {
    stop: () => void;
};
export {};
