/**
 * Make a fetch request using the native implementation, bypassing Zone.js patching.
 * This prevents unnecessary Angular change detection cycles.
 *
 * @param input - The resource to fetch (URL or Request object)
 * @param init - Optional fetch options
 * @returns A Promise that resolves to the Response
 */
export declare function fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>;
