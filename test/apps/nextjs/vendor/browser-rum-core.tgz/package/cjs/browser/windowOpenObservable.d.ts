import { Observable } from '@datadog/browser-core';
export declare function createWindowOpenObservable(): {
    observable: Observable<void>;
    stop: typeof import("@datadog/browser-core").noop;
};
