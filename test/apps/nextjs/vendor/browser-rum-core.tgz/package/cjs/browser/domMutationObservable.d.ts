import { Observable } from '@datadog/browser-core';
export interface RumCharacterDataMutationRecord {
    type: 'characterData';
    target: Node;
    oldValue: string | null;
}
export interface RumAttributesMutationRecord {
    type: 'attributes';
    target: Element;
    oldValue: string | null;
    attributeName: string;
}
export interface RumChildListMutationRecord {
    type: 'childList';
    target: Node;
    addedNodes: NodeList;
    removedNodes: NodeList;
}
export type RumMutationRecord = RumCharacterDataMutationRecord | RumAttributesMutationRecord | RumChildListMutationRecord;
export declare function createDOMMutationObservable(): Observable<RumMutationRecord[]>;
type MutationObserverConstructor = new (callback: (records: RumMutationRecord[]) => void) => MutationObserver;
export interface BrowserWindow extends Window {
    MutationObserver?: MutationObserverConstructor;
    Zone?: unknown;
}
export declare function getMutationObserverConstructor(): MutationObserverConstructor | undefined;
export {};
