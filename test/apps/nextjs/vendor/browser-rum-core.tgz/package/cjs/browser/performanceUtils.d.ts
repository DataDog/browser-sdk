import type { RelativeTime } from '@datadog/browser-core';
import type { RelevantNavigationTiming } from '../domain/view/viewMetrics/trackNavigationTimings';
import type { RumPerformanceNavigationTiming } from './performanceObservable';
export declare function getNavigationEntry(): RumPerformanceNavigationTiming;
export type TimingsFromDeprecatedPerformanceTiming = {
    -readonly [key in keyof Omit<PerformanceTiming, 'toJSON'>]: RelativeTime;
};
export declare function computeTimingsFromDeprecatedPerformanceTiming(): TimingsFromDeprecatedPerformanceTiming;
export declare function sanitizeFirstByte(entry: RelevantNavigationTiming): RelativeTime | undefined;
export declare function getResourceEntries(): PerformanceEntryList | undefined;
/**
 * Find the most relevant resource entry for an LCP element.
 *
 * Resource entries persist for the entire page lifetime and can include multiple requests
 * for the same URL (preloads, cache-busting reloads, SPA route changes, etc.).
 * This function returns the most recent matching entry that started before the LCP time,
 * which is most likely the one that triggered the LCP paint.
 */
export declare function findLcpResourceEntry(resourceUrl: string, lcpStartTime: RelativeTime): PerformanceResourceTiming | undefined;
