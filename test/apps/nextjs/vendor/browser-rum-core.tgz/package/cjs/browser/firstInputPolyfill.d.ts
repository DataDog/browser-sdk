import type { RumConfiguration } from '../domain/configuration';
/**
 * first-input timing entry polyfill based on
 * https://github.com/GoogleChrome/web-vitals/blob/master/src/lib/polyfills/firstInputPolyfill.ts
 */
export declare function retrieveFirstInputTiming(configuration: RumConfiguration, callback: (timing: PerformanceEventTiming) => void): {
    stop: () => void;
};
