import type { Duration, RelativeTime } from '@datadog/browser-core';
import { Observable } from '@datadog/browser-core';
import type { RumConfiguration } from '../domain/configuration';
type RumPerformanceObserverConstructor = new (callback: PerformanceObserverCallback) => RumPerformanceObserver;
export interface BrowserWindow extends Window {
    PerformanceObserver: RumPerformanceObserverConstructor;
    performance: Performance & {
        interactionCount?: number;
    };
}
export interface RumPerformanceObserver extends PerformanceObserver {
    observe(options?: PerformanceObserverInit & {
        durationThreshold?: number;
    }): void;
}
export declare enum RumPerformanceEntryType {
    EVENT = "event",
    FIRST_INPUT = "first-input",
    LARGEST_CONTENTFUL_PAINT = "largest-contentful-paint",
    LAYOUT_SHIFT = "layout-shift",
    LONG_TASK = "longtask",
    LONG_ANIMATION_FRAME = "long-animation-frame",
    NAVIGATION = "navigation",
    PAINT = "paint",
    RESOURCE = "resource",
    VISIBILITY_STATE = "visibility-state"
}
export interface RumPerformanceLongTaskTiming {
    name: string;
    entryType: RumPerformanceEntryType.LONG_TASK;
    startTime: RelativeTime;
    duration: Duration;
    toJSON(): Omit<PerformanceEntry, 'toJSON'>;
}
export interface RumPerformanceResourceTiming {
    entryType: RumPerformanceEntryType.RESOURCE;
    initiatorType: string;
    responseStatus?: number;
    name: string;
    startTime: RelativeTime;
    duration: Duration;
    fetchStart: RelativeTime;
    workerStart: RelativeTime;
    domainLookupStart: RelativeTime;
    domainLookupEnd: RelativeTime;
    connectStart: RelativeTime;
    secureConnectionStart: RelativeTime;
    connectEnd: RelativeTime;
    requestStart: RelativeTime;
    responseStart: RelativeTime;
    responseEnd: RelativeTime;
    redirectStart: RelativeTime;
    redirectEnd: RelativeTime;
    decodedBodySize?: number;
    encodedBodySize?: number;
    transferSize?: number;
    nextHopProtocol?: string;
    renderBlockingStatus?: string;
    traceId?: string;
    spanId?: string;
    traceIdHigh?: string;
    deliveryType?: 'cache' | 'navigational-prefetch' | '';
    contentType?: string;
    toJSON(): Omit<PerformanceEntry, 'toJSON'>;
}
export interface RumPerformancePaintTiming {
    entryType: RumPerformanceEntryType.PAINT;
    name: 'first-paint' | 'first-contentful-paint';
    startTime: RelativeTime;
    toJSON(): Omit<RumPerformancePaintTiming, 'toJSON'>;
}
export interface RumPerformanceNavigationTiming extends Omit<RumPerformanceResourceTiming, 'entryType'> {
    entryType: RumPerformanceEntryType.NAVIGATION;
    initiatorType: 'navigation';
    name: string;
    domComplete: RelativeTime;
    domContentLoadedEventEnd: RelativeTime;
    domInteractive: RelativeTime;
    loadEventEnd: RelativeTime;
    toJSON(): Omit<RumPerformanceNavigationTiming, 'toJSON'>;
}
export interface RumLargestContentfulPaintTiming {
    entryType: RumPerformanceEntryType.LARGEST_CONTENTFUL_PAINT;
    startTime: RelativeTime;
    size: number;
    element?: Element;
    url?: string;
    toJSON(): Omit<RumLargestContentfulPaintTiming, 'toJSON'>;
}
export interface RumFirstInputTiming {
    entryType: RumPerformanceEntryType.FIRST_INPUT;
    startTime: RelativeTime;
    processingStart: RelativeTime;
    processingEnd: RelativeTime;
    duration: Duration;
    target?: Node;
    interactionId?: number;
    toJSON(): Omit<RumFirstInputTiming, 'toJSON'>;
}
export interface RumPerformanceEventTiming {
    entryType: RumPerformanceEntryType.EVENT;
    startTime: RelativeTime;
    processingStart: RelativeTime;
    processingEnd: RelativeTime;
    duration: Duration;
    interactionId?: number;
    target?: Node;
    name: string;
    toJSON(): Omit<RumPerformanceEventTiming, 'toJSON'>;
}
export interface RumLayoutShiftAttribution {
    node: Node | null;
    previousRect: DOMRectReadOnly;
    currentRect: DOMRectReadOnly;
}
export interface RumLayoutShiftTiming {
    entryType: RumPerformanceEntryType.LAYOUT_SHIFT;
    startTime: RelativeTime;
    value: number;
    hadRecentInput: boolean;
    sources: RumLayoutShiftAttribution[];
    toJSON(): Omit<RumLayoutShiftTiming, 'toJSON'>;
}
export interface RumPerformanceScriptTiming {
    duration: Duration;
    entryType: 'script';
    executionStart: RelativeTime;
    forcedStyleAndLayoutDuration: Duration;
    invoker: string;
    invokerType: 'user-callback' | 'event-listener' | 'resolve-promise' | 'reject-promise' | 'classic-script' | 'module-script';
    name: 'script';
    pauseDuration: Duration;
    sourceCharPosition: number;
    sourceFunctionName: string;
    sourceURL: string;
    startTime: RelativeTime;
    window: Window;
    windowAttribution: string;
}
export interface RumPerformanceLongAnimationFrameTiming {
    blockingDuration: Duration;
    duration: Duration;
    entryType: RumPerformanceEntryType.LONG_ANIMATION_FRAME;
    firstUIEventTimestamp: RelativeTime;
    name: 'long-animation-frame';
    renderStart: RelativeTime;
    scripts: RumPerformanceScriptTiming[];
    startTime: RelativeTime;
    styleAndLayoutStart: RelativeTime;
    toJSON(): Omit<RumPerformanceLongAnimationFrameTiming, 'toJSON'>;
}
export interface RumFirstHiddenTiming {
    entryType: RumPerformanceEntryType.VISIBILITY_STATE;
    name: 'hidden' | 'visible';
    startTime: RelativeTime;
    toJSON(): Omit<RumFirstHiddenTiming, 'toJSON'>;
}
export type RumPerformanceEntry = RumPerformanceResourceTiming | RumPerformanceLongTaskTiming | RumPerformanceLongAnimationFrameTiming | RumPerformancePaintTiming | RumPerformanceNavigationTiming | RumLargestContentfulPaintTiming | RumFirstInputTiming | RumPerformanceEventTiming | RumLayoutShiftTiming | RumFirstHiddenTiming;
export interface EntryTypeToReturnType {
    [RumPerformanceEntryType.EVENT]: RumPerformanceEventTiming;
    [RumPerformanceEntryType.FIRST_INPUT]: RumFirstInputTiming;
    [RumPerformanceEntryType.LARGEST_CONTENTFUL_PAINT]: RumLargestContentfulPaintTiming;
    [RumPerformanceEntryType.LAYOUT_SHIFT]: RumLayoutShiftTiming;
    [RumPerformanceEntryType.PAINT]: RumPerformancePaintTiming;
    [RumPerformanceEntryType.LONG_TASK]: RumPerformanceLongTaskTiming;
    [RumPerformanceEntryType.LONG_ANIMATION_FRAME]: RumPerformanceLongAnimationFrameTiming;
    [RumPerformanceEntryType.NAVIGATION]: RumPerformanceNavigationTiming;
    [RumPerformanceEntryType.RESOURCE]: RumPerformanceResourceTiming;
    [RumPerformanceEntryType.VISIBILITY_STATE]: RumFirstHiddenTiming;
}
export declare function createPerformanceObservable<T extends RumPerformanceEntryType>(configuration: RumConfiguration, options: {
    type: T;
    buffered?: boolean;
    durationThreshold?: number;
}): Observable<EntryTypeToReturnType[T][]>;
export declare function supportPerformanceTimingEvent(entryType: RumPerformanceEntryType): boolean;
export {};
