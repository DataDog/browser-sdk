import type { DISCARDED, Duration, HookNamesAsConst, RecursivePartial, RelativeTime, SKIPPED, TelemetryEvent } from '@datadog/browser-core';
import type { RumEvent } from '../rumEvent.types';
import type { RawRumEvent } from '../rawRumEvent.types';
import type { RumEventDomainContext } from '../domainContext.types';
export type DefaultRumEventAttributes = RecursivePartial<RumEvent> & {
    type: RumEvent['type'];
};
export type DefaultTelemetryEventAttributes = RecursivePartial<TelemetryEvent>;
type DeepReadonly<T> = {
    readonly [K in keyof T]: DeepReadonly<T[K]>;
};
export interface AssembleHookParams {
    readonly eventType: RumEvent['type'];
    rawRumEvent: DeepReadonly<RawRumEvent>;
    domainContext: DeepReadonly<RumEventDomainContext<RawRumEvent['type']>>;
    readonly startTime: RelativeTime;
    readonly duration?: Duration | undefined;
}
export interface HookCallbackMap {
    [HookNamesAsConst.ASSEMBLE]: (param: AssembleHookParams) => DefaultRumEventAttributes | SKIPPED | DISCARDED;
    [HookNamesAsConst.ASSEMBLE_TELEMETRY]: (param: {
        startTime: RelativeTime;
    }) => DefaultTelemetryEventAttributes | SKIPPED | DISCARDED;
}
export type Hooks = ReturnType<typeof createHooks>;
export declare const createHooks: () => {
    register<K extends import("@datadog/browser-core").HookNames>(hookName: K, callback: HookCallbackMap[K]): {
        unregister: () => void;
    };
    triggerHook<K extends import("@datadog/browser-core").HookNames>(hookName: K, param: Parameters<HookCallbackMap[K]>[0]): "DISCARDED" | Exclude<ReturnType<HookCallbackMap[K]>, "SKIPPED"> | undefined;
};
export {};
