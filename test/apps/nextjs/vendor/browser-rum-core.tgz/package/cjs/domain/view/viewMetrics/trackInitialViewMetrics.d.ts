import type { ClocksState, Duration } from '@datadog/browser-core';
import type { RumConfiguration } from '../../configuration';
import type { FirstInput } from './trackFirstInput';
import type { NavigationTimings } from './trackNavigationTimings';
import type { LargestContentfulPaint } from './trackLargestContentfulPaint';
export interface InitialViewMetrics {
    firstContentfulPaint?: Duration;
    navigationTimings?: NavigationTimings;
    largestContentfulPaint?: LargestContentfulPaint;
    firstInput?: FirstInput;
}
export declare function trackInitialViewMetrics(configuration: RumConfiguration, viewStart: ClocksState, setLoadEvent: (loadEnd: Duration) => void, scheduleViewUpdate: () => void): {
    stop: () => void;
    initialViewMetrics: InitialViewMetrics;
};
