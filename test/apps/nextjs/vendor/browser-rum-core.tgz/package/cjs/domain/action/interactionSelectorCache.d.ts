import type { RelativeTime } from '@datadog/browser-core';
export declare const CLICK_ACTION_MAX_DURATION: number;
export declare const interactionSelectorCache: Map<RelativeTime, string>;
export declare function getInteractionSelector(relativeTimestamp: RelativeTime): string | undefined;
export declare function updateInteractionSelector(relativeTimestamp: RelativeTime, selector: string): void;
