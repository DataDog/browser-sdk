import type { Duration } from '@datadog/browser-core';
import { ResourceType } from '@datadog/browser-core';
import type { RumPerformanceResourceTiming } from '../../browser/performanceObservable';
import type { ResourceEntryDetailsElement, DeliveryType } from '../../rawRumEvent.types';
export interface ResourceEntryDetails {
    worker?: ResourceEntryDetailsElement;
    redirect?: ResourceEntryDetailsElement;
    dns?: ResourceEntryDetailsElement;
    connect?: ResourceEntryDetailsElement;
    ssl?: ResourceEntryDetailsElement;
    first_byte?: ResourceEntryDetailsElement;
    download?: ResourceEntryDetailsElement;
}
export declare const FAKE_INITIAL_DOCUMENT = "initial_document";
export declare function computeResourceEntryType(entry: RumPerformanceResourceTiming): ResourceType;
export declare function isResourceEntryRequestType(entry: RumPerformanceResourceTiming): boolean;
export declare function computeResourceEntryDuration(entry: RumPerformanceResourceTiming): Duration;
export declare function computeResourceEntryDetails(entry: RumPerformanceResourceTiming): ResourceEntryDetails | undefined;
/**
 * Entries with negative duration are unexpected and should be dismissed. The intake will ignore RUM
 * Resource events with negative durations anyway.
 * Since Chromium 128, more entries have unexpected negative durations, see
 * https://issues.chromium.org/issues/363031537
 */
export declare function hasValidResourceEntryDuration(entry: RumPerformanceResourceTiming): boolean;
export declare function hasValidResourceEntryTimings(entry: RumPerformanceResourceTiming): boolean;
/**
 * The 'nextHopProtocol' is an empty string for cross-origin resources without CORS headers,
 * meaning the protocol is unknown, and we shouldn't report it.
 * https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming/nextHopProtocol#cross-origin_resources
 */
export declare function computeResourceEntryProtocol(entry: RumPerformanceResourceTiming): string | undefined;
/**
 * Handles the 'deliveryType' property to distinguish between supported values ('cache', 'navigational-prefetch'),
 * undefined (unsupported in some browsers), and other cases ('other' for unknown or unrecognized values).
 * see: https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming/deliveryType
 */
export declare function computeResourceEntryDeliveryType(entry: RumPerformanceResourceTiming): DeliveryType | undefined;
export declare function computeResourceEntrySize(entry: RumPerformanceResourceTiming): {
    size: number | undefined;
    encoded_body_size: number | undefined;
    decoded_body_size: number | undefined;
    transfer_size: number | undefined;
};
export declare function isAllowedRequestUrl(url: string): boolean | "";
export declare const MAX_RESOURCE_VALUE_CHAR_LENGTH = 24000;
export declare function sanitizeIfLongDataUrl(url: string, lengthLimit?: number): string;
