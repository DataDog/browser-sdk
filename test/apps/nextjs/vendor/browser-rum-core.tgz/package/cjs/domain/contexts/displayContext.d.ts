import type { RumConfiguration } from '../configuration';
import type { Hooks } from '../hooks';
export type DisplayContext = ReturnType<typeof startDisplayContext>;
export declare function startDisplayContext(hooks: Hooks, configuration: RumConfiguration): {
    stop: () => void;
};
