import type { Hooks } from '../hooks';
interface SourceCodeContext {
    service: string;
    version?: string;
}
export interface BrowserWindow {
    DD_SOURCE_CODE_CONTEXT?: {
        [stack: string]: SourceCodeContext;
    };
}
export declare function startSourceCodeContext(hooks: Hooks): void;
export {};
