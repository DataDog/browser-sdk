import type { RumConfiguration, GraphQlUrlOption } from '../configuration';
import type { RequestCompleteEvent } from '../requestCollection';
export interface GraphQlError {
    message: string;
    code?: string;
    locations?: Array<{
        line: number;
        column: number;
    }>;
    path?: Array<string | number>;
}
export interface GraphQlMetadata {
    operationType?: 'query' | 'mutation' | 'subscription';
    operationName?: string;
    variables?: string;
    payload?: string;
    error_count?: number;
    errors?: GraphQlError[];
}
export declare function extractGraphQlMetadata(request: RequestCompleteEvent, graphQlConfig: GraphQlUrlOption): GraphQlMetadata | undefined;
export declare function parseGraphQlResponse(responseText: string): GraphQlError[] | undefined;
export declare function findGraphQlConfiguration(url: string, configuration: RumConfiguration): GraphQlUrlOption | undefined;
export declare function extractGraphQlRequestMetadata(request: Pick<RequestCompleteEvent, 'method' | 'url' | 'requestBody'>, trackPayload?: boolean): GraphQlMetadata | undefined;
