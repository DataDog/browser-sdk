import type { Configuration } from '@datadog/browser-core';
import type { Hooks } from '../hooks';
export declare const CI_VISIBILITY_TEST_ID_COOKIE_NAME = "datadog-ci-visibility-test-execution-id";
export interface CiTestWindow extends Window {
    Cypress?: {
        env: (key: string) => string | undefined;
    };
}
export type CiVisibilityContext = ReturnType<typeof startCiVisibilityContext>;
export declare function startCiVisibilityContext(configuration: Configuration, hooks: Hooks, cookieObservable?: import("@datadog/browser-core").Observable<string | undefined>): {
    stop: () => void;
};
