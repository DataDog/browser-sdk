import type { RelativeTime, ClocksState, Context } from '@datadog/browser-core';
import type { LifeCycle } from '../lifeCycle';
export declare const VIEW_CONTEXT_TIME_OUT_DELAY: number;
export interface ViewHistoryEntry {
    service?: string;
    version?: string;
    context?: Context | undefined;
    id: string;
    name?: string;
    startClocks: ClocksState;
    sessionIsActive?: boolean;
}
export interface ViewHistory {
    findView: (startTime?: RelativeTime) => ViewHistoryEntry | undefined;
    stop: () => void;
}
export declare function startViewHistory(lifeCycle: LifeCycle): ViewHistory;
