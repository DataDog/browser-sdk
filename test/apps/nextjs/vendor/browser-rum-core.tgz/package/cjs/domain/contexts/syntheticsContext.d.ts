import type { Hooks } from '../hooks';
export declare function startSyntheticsContext(hooks: Hooks): void;
