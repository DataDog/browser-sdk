import type { RelativeTime } from '@datadog/browser-core';
import type { RumConfiguration } from '../configuration';
export interface ExtraPointerEventFields {
    target: Element;
    timeStamp: RelativeTime;
}
export type MouseEventOnElement = PointerEvent & ExtraPointerEventFields;
export interface UserActivity {
    selection: boolean;
    input: boolean;
    scroll: boolean;
}
export interface ActionEventsHooks<ClickContext> {
    onPointerDown: (event: MouseEventOnElement) => ClickContext | undefined;
    onPointerUp: (context: ClickContext, event: MouseEventOnElement, getUserActivity: () => UserActivity) => void;
}
export declare function listenActionEvents<ClickContext>(configuration: RumConfiguration, { onPointerDown, onPointerUp }: ActionEventsHooks<ClickContext>): {
    stop: () => void;
};
