import type { RumConfiguration } from './configuration';
import type { ViewHistoryEntry } from './contexts/viewHistory';
import type { RumSession } from './rumSessionManager';
export declare function getSessionReplayUrl(configuration: RumConfiguration, { session, viewContext, errorType, }: {
    session?: RumSession;
    viewContext?: ViewHistoryEntry;
    errorType?: string;
}): string;
export declare function getDatadogSiteUrl(rumConfiguration: RumConfiguration): string;
