import type { Configuration } from '@datadog/browser-core';
export declare function onBFCacheRestore(configuration: Configuration, callback: (event: PageTransitionEvent) => void): () => void;
