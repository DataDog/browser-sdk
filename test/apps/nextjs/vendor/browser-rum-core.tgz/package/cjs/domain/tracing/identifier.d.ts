interface BaseIdentifier {
    toString(radix?: number): string;
}
export interface TraceIdentifier extends BaseIdentifier {
    __brand: 'traceIdentifier';
}
export interface SpanIdentifier extends BaseIdentifier {
    __brand: 'spanIdentifier';
}
export declare function createTraceIdentifier(): TraceIdentifier;
export declare function createSpanIdentifier(): SpanIdentifier;
export declare function toPaddedHexadecimalString(id: BaseIdentifier): string;
export {};
