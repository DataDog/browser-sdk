import type { RumInternalContext } from '@datadog/browser-core';
import type { RumSessionManager } from '../rumSessionManager';
import type { ActionContexts } from '../action/actionCollection';
import type { ViewHistory } from './viewHistory';
import type { UrlContexts } from './urlContexts';
/**
 * Internal context keep returning v1 format
 * to not break compatibility with logs data format
 */
export declare function startInternalContext(applicationId: string, sessionManager: RumSessionManager, viewHistory: ViewHistory, actionContexts: ActionContexts, urlContexts: UrlContexts): {
    get: (startTime?: number) => RumInternalContext | undefined;
};
