import type { Configuration, InitConfiguration, MatchOption } from '@datadog/browser-core';
import { DefaultPrivacyLevel, TraceContextInjection } from '@datadog/browser-core';
import type { RumEventDomainContext } from '../../domainContext.types';
import type { RumEvent } from '../../rumEvent.types';
import type { RumPlugin } from '../plugins';
import type { PropagatorType, TracingOption } from '../tracing/tracer.types';
export declare const DEFAULT_PROPAGATOR_TYPES: PropagatorType[];
/**
 * Init Configuration for the RUM browser SDK.
 *
 * @category Main
 * @example NPM
 * ```ts
 * import { datadogRum } from '@datadog/browser-rum'
 *
 * datadogRum.init({
 *   applicationId: '<DATADOG_APPLICATION_ID>',
 *   clientToken: '<DATADOG_CLIENT_TOKEN>',
 *   site: '<DATADOG_SITE>',
 *   // ...
 * })
 * ```
 * @example CDN
 * ```ts
 * DD_RUM.init({
 *   applicationId: '<DATADOG_APPLICATION_ID>',
 *   clientToken: '<DATADOG_CLIENT_TOKEN>',
 *   site: '<DATADOG_SITE>',
 *   ...
 * })
 * ```
 */
export interface RumInitConfiguration extends InitConfiguration {
    /**
     * The RUM application ID.
     *
     * @category Authentication
     */
    applicationId: string;
    /**
     * Whether to propagate user and account IDs in the baggage header of trace requests.
     *
     * @category Tracing
     * @defaultValue false
     */
    propagateTraceBaggage?: boolean | undefined;
    /**
     * Access to every event collected by the RUM SDK before they are sent to Datadog.
     * It allows:
     * - Enrich your RUM events with additional context attributes
     * - Modify your RUM events to modify their content, or redact sensitive sequences (see the list of editable properties)
     * - Discard selected RUM events
     *
     * See [Enrich And Control Browser RUM Data With beforeSend](https://docs.datadoghq.com/real_user_monitoring/guide/enrich-and-control-rum-data) for further information.
     *
     * @category Data Collection
     */
    beforeSend?: RumBeforeSend | undefined;
    /**
     * A list of request origins ignored when computing the page activity.
     * See [How page activity is calculated](https://docs.datadoghq.com/real_user_monitoring/browser/monitoring_page_performance/#how-page-activity-is-calculated) for further information.
     */
    excludedActivityUrls?: MatchOption[] | undefined;
    /**
     * URL pointing to the Datadog Browser SDK Worker JavaScript file. The URL can be relative or absolute, but is required to have the same origin as the web application.
     * See [Content Security Policy guidelines](https://docs.datadoghq.com/integrations/content_security_policy_logs/?tab=firefox#use-csp-with-real-user-monitoring-and-session-replay) for further information.
     *
     * @category Transport
     */
    workerUrl?: string;
    /**
     * Compress requests sent to the Datadog intake to reduce bandwidth usage when sending large amounts of data. The compression is done in a Worker thread.
     * See [Content Security Policy guidelines](https://docs.datadoghq.com/integrations/content_security_policy_logs/?tab=firefox#use-csp-with-real-user-monitoring-and-session-replay) for further information.
     *
     * @category Transport
     */
    compressIntakeRequests?: boolean | undefined;
    /**
     * [Internal option] Id of the remote configuration
     *
     * @internal
     */
    remoteConfigurationId?: string | undefined;
    /**
     * [Internal option] set a proxy URL for the remote configuration
     *
     * @internal
     */
    remoteConfigurationProxy?: string | undefined;
    /**
     * A list of request URLs used to inject tracing headers.
     * See [Connect RUM and Traces](https://docs.datadoghq.com/real_user_monitoring/platform/connect_rum_and_traces/?tab=browserrum) for further information.
     *
     * @category Tracing
     */
    allowedTracingUrls?: Array<MatchOption | {
        match: MatchOption;
        propagatorTypes?: PropagatorType[] | null | undefined;
    }> | undefined;
    /**
     * The percentage of requests to trace: 100 for all, 0 for none.
     * See [Connect RUM and Traces](https://docs.datadoghq.com/real_user_monitoring/platform/connect_rum_and_traces/?tab=browserrum) for further information.
     *
     * @category Tracing
     * @defaultValue 100
     */
    traceSampleRate?: number | undefined;
    /**
     * If you set a `traceSampleRate`, to ensure backend services' sampling decisions are still applied, configure the `traceContextInjection` initialization parameter to sampled.
     *
     * See [Connect RUM and Traces](https://docs.datadoghq.com/real_user_monitoring/platform/connect_rum_and_traces/?tab=browserrum) for further information.
     *
     * @category Tracing
     * @defaultValue sampled
     */
    traceContextInjection?: TraceContextInjection | undefined;
    /**
     * Allow to protect end user privacy and prevent sensitive organizational information from being collected.
     *
     * See [Replay Privacy Options](https://docs.datadoghq.com/real_user_monitoring/session_replay/browser/privacy_options) for further information.
     *
     * @category Privacy
     * @defaultValue mask
     */
    defaultPrivacyLevel?: DefaultPrivacyLevel | undefined;
    /**
     * If you are accessing Datadog through a custom subdomain, you can set `subdomain` to include your custom domain in the `getSessionReplayLink()` returned URL .
     *
     * See [Connect Session Replay To Your Third-Party Tools](https://docs.datadoghq.com/real_user_monitoring/guide/connect-session-replay-to-your-third-party-tools) for further information.
     *
     */
    subdomain?: string;
    /**
     * The percentage of tracked sessions with [Browser RUM & Session Replay pricing](https://www.datadoghq.com/pricing/?product=real-user-monitoring--session-replay#real-user-monitoring--session-replay) features: 100 for all, 0 for none.
     *
     * See [Configure Your Setup For Browser RUM and Browser RUM & Session Replay Sampling](https://docs.datadoghq.com/real_user_monitoring/guide/sampling-browser-plans) for further information.
     *
     * @category Session Replay
     * @defaultValue 0
     */
    sessionReplaySampleRate?: number | undefined;
    /**
     * If the session is sampled for Session Replay, only start the recording when `startSessionReplayRecording()` is called, instead of at the beginning of the session. Default: if startSessionReplayRecording is 0, true; otherwise, false.
     *
     * See [Session Replay Usage](https://docs.datadoghq.com/real_user_monitoring/session_replay/browser/#usage) for further information.
     *
     * @category Session Replay
     */
    startSessionReplayRecordingManually?: boolean | undefined;
    /**
     * Enables privacy control for action names.
     *
     * @category Privacy
     */
    enablePrivacyForActionName?: boolean | undefined;
    /**
     * Enables automatic collection of users actions.
     *
     * See [Tracking User Actions](https://docs.datadoghq.com/real_user_monitoring/browser/tracking_user_actions) for further information.
     *
     * @category Data Collection
     * @defaultValue true
     */
    trackUserInteractions?: boolean | undefined;
    /**
     * Specify your own attribute to use to name actions.
     *
     * See [Declare a name for click actions](https://docs.datadoghq.com/real_user_monitoring/browser/tracking_user_actions/#declare-a-name-for-click-actions) for further information.
     *
     * @category Data Collection
     */
    actionNameAttribute?: string | undefined;
    /**
     * Enables accurate action names for clicks inside Shadow DOM elements.
     * ⚠️ This is a beta feature and will be updated in the future with selector tracking.
     *
     * @category Beta
     * @defaultValue false
     */
    betaTrackActionsInShadowDom?: boolean | undefined;
    /**
     * Allows you to control RUM views creation. See [Override default RUM view names](https://docs.datadoghq.com/real_user_monitoring/browser/advanced_configuration/?tab=npm#override-default-rum-view-names) for further information.
     *
     * @category Data Collection
     */
    trackViewsManually?: boolean | undefined;
    /**
     * Enable the creation of dedicated views for pages restored from the Back-Forward cache.
     *
     * @category Data Collection
     * @defaultValue false
     */
    trackBfcacheViews?: boolean | undefined;
    /**
     * Enables collection of resource events.
     *
     * @category Data Collection
     * @defaultValue true
     */
    trackResources?: boolean | undefined;
    /**
     * Enables collection of long task events.
     *
     * @category Data Collection
     * @defaultValue true
     */
    trackLongTasks?: boolean | undefined;
    /**
     * Enables early request collection before resource timing entries are available.
     *
     * @category Data Collection
     * @defaultValue false
     */
    trackEarlyRequests?: boolean | undefined;
    /**
     * List of plugins to enable. The plugins API is unstable and experimental, and may change without
     * notice. Please use only plugins provided by Datadog matching the version of the SDK you are
     * using.
     */
    plugins?: RumPlugin[] | undefined;
    /**
     * Enables collection of features flags in additional events (e.g. long task, resource, action, vital).
     *
     * @category Data Collection
     */
    trackFeatureFlagsForEvents?: FeatureFlagsForEvents[];
    /**
     * The percentage of users profiled. A value between 0 and 100.
     *
     * @category Profiling
     * @defaultValue 0
     */
    profilingSampleRate?: number | undefined;
    /**
     * A list of GraphQL endpoint URLs to track and enrich with GraphQL-specific metadata.
     *
     * @category Data Collection
     */
    allowedGraphQlUrls?: Array<MatchOption | GraphQlUrlOption> | undefined;
}
export type HybridInitConfiguration = Omit<RumInitConfiguration, 'applicationId' | 'clientToken'>;
export type FeatureFlagsForEvents = 'vital' | 'action' | 'long_task' | 'resource';
/**
 * Function called before a RUM event is sent to Datadog. See {@link RumInitConfiguration.beforeSend}
 *
 * @param event - The RUM event
 * @param context - The RUM event domain context providing access to native browser data based on the event type (e.g. error, performance entry).
 * @returns true if the event should be sent to Datadog, false otherwise
 */
export type RumBeforeSend = (event: RumEvent, context: RumEventDomainContext) => boolean;
export interface GraphQlUrlOption {
    match: MatchOption;
    trackPayload?: boolean;
    trackResponseErrors?: boolean;
}
export interface RumConfiguration extends Configuration {
    actionNameAttribute: string | undefined;
    betaTrackActionsInShadowDom: boolean;
    traceSampleRate: number;
    rulePsr: number | undefined;
    allowedTracingUrls: TracingOption[];
    excludedActivityUrls: MatchOption[];
    workerUrl: string | undefined;
    compressIntakeRequests: boolean;
    applicationId: string;
    defaultPrivacyLevel: DefaultPrivacyLevel;
    enablePrivacyForActionName: boolean;
    sessionReplaySampleRate: number;
    startSessionReplayRecordingManually: boolean;
    trackUserInteractions: boolean;
    trackViewsManually: boolean;
    trackResources: boolean;
    trackLongTasks: boolean;
    trackBfcacheViews: boolean;
    trackEarlyRequests: boolean;
    subdomain?: string;
    traceContextInjection: TraceContextInjection;
    plugins: RumPlugin[];
    trackFeatureFlagsForEvents: FeatureFlagsForEvents[];
    profilingSampleRate: number;
    propagateTraceBaggage: boolean;
    allowedGraphQlUrls: GraphQlUrlOption[];
}
export declare function validateAndBuildRumConfiguration(initConfiguration: RumInitConfiguration, errorStack?: string): RumConfiguration | undefined;
export declare function serializeRumConfiguration(configuration: RumInitConfiguration): {
    session_sample_rate: number | undefined;
    telemetry_sample_rate: number | undefined;
    telemetry_configuration_sample_rate: number | undefined;
    telemetry_usage_sample_rate: number | undefined;
    use_before_send: boolean;
    use_partitioned_cross_site_session_cookie: boolean | undefined;
    use_secure_session_cookie: boolean | undefined;
    use_proxy: boolean;
    silent_multiple_init: boolean | undefined;
    track_session_across_subdomains: boolean | undefined;
    track_anonymous_user: boolean | undefined;
    session_persistence: import("@datadog/browser-core").SessionPersistence | undefined;
    allow_fallback_to_local_storage: boolean;
    store_contexts_across_pages: boolean;
    allow_untrusted_events: boolean;
    tracking_consent: import("@datadog/browser-core").TrackingConsent | undefined;
    use_allowed_tracking_origins: boolean;
    beta_encode_cookie_options: boolean | undefined;
    source: "browser" | "flutter" | "unity" | undefined;
    sdk_version: string | undefined;
    variant: string | undefined;
    session_replay_sample_rate: number | undefined;
    start_session_replay_recording_manually: boolean | undefined;
    trace_sample_rate: number | undefined;
    trace_context_injection: TraceContextInjection | undefined;
    propagate_trace_baggage: boolean | undefined;
    action_name_attribute: string | undefined;
    use_allowed_tracing_urls: boolean;
    use_allowed_graph_ql_urls: boolean;
    use_track_graph_ql_payload: boolean;
    use_track_graph_ql_response_errors: boolean;
    selected_tracing_propagators: PropagatorType[];
    default_privacy_level: DefaultPrivacyLevel | undefined;
    enable_privacy_for_action_name: boolean | undefined;
    use_excluded_activity_urls: boolean;
    use_worker_url: boolean;
    compress_intake_requests: boolean | undefined;
    track_views_manually: boolean | undefined;
    track_user_interactions: boolean | undefined;
    track_resources: boolean | undefined;
    track_long_task: boolean | undefined;
    track_bfcache_views: boolean | undefined;
    track_early_requests: boolean | undefined;
    plugins: {
        name: string;
    }[] | undefined;
    track_feature_flags_for_events: FeatureFlagsForEvents[] | undefined;
    remote_configuration_id: string | undefined;
    profiling_sample_rate: number | undefined;
    use_remote_configuration_proxy: boolean;
};
