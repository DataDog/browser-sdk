import type { RumConfiguration } from '../configuration';
import type { Hooks } from '../hooks';
export type SdkName = 'rum' | 'rum-slim' | 'rum-synthetics';
export declare function startDefaultContext(hooks: Hooks, configuration: RumConfiguration, sdkName: SdkName | undefined): void;
