import type { Duration } from '@datadog/browser-core';
import type { RumPerformanceNavigationTiming } from '../../../browser/performanceObservable';
import type { RumConfiguration } from '../../configuration';
export interface NavigationTimings {
    domComplete: Duration;
    domContentLoaded: Duration;
    domInteractive: Duration;
    loadEvent: Duration;
    firstByte: Duration | undefined;
}
export type RelevantNavigationTiming = Pick<RumPerformanceNavigationTiming, 'domComplete' | 'domContentLoadedEventEnd' | 'domInteractive' | 'loadEventEnd' | 'responseStart'>;
export declare function trackNavigationTimings(configuration: RumConfiguration, callback: (timings: NavigationTimings) => void): {
    stop: () => void;
};
