import type { Duration, Observable, RelativeTime } from '@datadog/browser-core';
import type { LifeCycle } from '../lifeCycle';
import type { RumConfiguration } from '../configuration';
import type { Hooks } from '../hooks';
import type { RumMutationRecord } from '../../browser/domMutationObservable';
import type { ClickAction } from './trackClickActions';
import type { ManualAction } from './trackManualActions';
export type AutoAction = ClickAction;
export interface ActionContexts {
    findActionId: (startTime?: RelativeTime) => string[];
}
export declare const LONG_TASK_START_TIME_CORRECTION: Duration;
export declare function startActionCollection(lifeCycle: LifeCycle, hooks: Hooks, domMutationObservable: Observable<RumMutationRecord[]>, windowOpenObservable: Observable<void>, configuration: RumConfiguration): {
    addAction: (action: Omit<ManualAction, "id" | "duration" | "counts" | "frustrationTypes">) => void;
    startAction: (name: string, options?: import("./trackManualActions").ActionOptions, startClocks?: {
        relative: RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopAction: (name: string, options?: import("./trackManualActions").ActionOptions, stopClocks?: {
        relative: RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    actionContexts: ActionContexts;
    stop: () => void;
};
