import type { Duration, RelativeTime } from '@datadog/browser-core';
import { ViewLoadingType } from '../../../rawRumEvent.types';
import type { RumConfiguration } from '../../configuration';
export declare const MAX_INP_VALUE: Duration;
export interface InteractionToNextPaint {
    value: Duration;
    targetSelector?: string;
    time?: Duration;
    subParts?: {
        inputDelay: Duration;
        processingDuration: Duration;
        presentationDelay: Duration;
    };
}
/**
 * Track the interaction to next paint (INP).
 * To avoid outliers, return the p98 worst interaction of the view.
 * Documentation: https://web.dev/inp/
 * Reference implementation: https://github.com/GoogleChrome/web-vitals/blob/main/src/onINP.ts
 */
export declare function trackInteractionToNextPaint(configuration: RumConfiguration, viewStart: RelativeTime, viewLoadingType: ViewLoadingType): {
    getInteractionToNextPaint: () => InteractionToNextPaint | undefined;
    setViewEnd: (viewEndTime: RelativeTime) => void;
    stop: () => void;
};
/**
 * Tracks the number of interactions that occurred during the current view. Freezes the count
 * when the view ends so that the p98 estimate remains stable after `setViewEnd` is called.
 */
export declare function trackViewInteractionCount(viewLoadingType: ViewLoadingType): {
    getViewInteractionCount: () => number;
    stopViewInteractionCount: () => void;
};
export declare function isInteractionToNextPaintSupported(): boolean;
