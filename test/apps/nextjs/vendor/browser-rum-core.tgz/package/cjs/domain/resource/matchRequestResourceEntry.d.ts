import type { RumPerformanceResourceTiming } from '../../browser/performanceObservable';
import type { RequestCompleteEvent } from '../requestCollection';
/**
 * Look for corresponding timing in resource timing buffer
 *
 * Observations:
 * - Timing (start, end) are nested inside the request (start, end)
 * - Some timing can be not exactly nested, being off by < 1 ms
 *
 * Strategy:
 * - from valid nested entries (with 1 ms error margin)
 * - filter out timing that were already matched to a request
 * - then, if a single timing match, return the timing
 * - otherwise we can't decide, return undefined
 */
export declare function matchRequestResourceEntry(request: RequestCompleteEvent): RumPerformanceResourceTiming | undefined;
