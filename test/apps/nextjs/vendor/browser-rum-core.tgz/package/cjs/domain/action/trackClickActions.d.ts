import type { Duration, ClocksState, TimeStamp } from '@datadog/browser-core';
import { Observable } from '@datadog/browser-core';
import type { FrustrationType } from '../../rawRumEvent.types';
import { ActionType } from '../../rawRumEvent.types';
import type { LifeCycle } from '../lifeCycle';
import type { RumConfiguration } from '../configuration';
import type { RumMutationRecord } from '../../browser/domMutationObservable';
import type { EventTracker } from '../eventTracker';
import type { ActionNameSource } from './actionNameConstants';
import type { MouseEventOnElement, UserActivity } from './listenActionEvents';
interface ActionCounts {
    errorCount: number;
    longTaskCount: number;
    resourceCount: number;
}
export interface ClickAction {
    type: typeof ActionType.CLICK;
    id: string;
    name: string;
    nameSource: ActionNameSource;
    target?: {
        selector: string | undefined;
        width: number;
        height: number;
    };
    position?: {
        x: number;
        y: number;
    };
    startClocks: ClocksState;
    duration?: Duration;
    counts: ActionCounts;
    event: MouseEventOnElement;
    frustrationTypes: FrustrationType[];
    events: Event[];
}
export declare function trackClickActions(lifeCycle: LifeCycle, domMutationObservable: Observable<RumMutationRecord[]>, windowOpenObservable: Observable<void>, configuration: RumConfiguration): {
    stop: () => void;
    findActionId: (startTime?: import("@datadog/browser-core").RelativeTime) => string[];
};
export type ClickActionBase = Pick<ClickAction, 'type' | 'name' | 'nameSource' | 'target' | 'position'>;
export type Click = ReturnType<typeof newClick>;
declare function newClick(lifeCycle: LifeCycle, actionTracker: EventTracker<ClickActionBase>, getUserActivity: () => UserActivity, clickActionBase: ClickActionBase, startEvent: MouseEventOnElement): {
    event: MouseEventOnElement;
    stop: (activityEndTime?: TimeStamp) => void;
    stopObservable: Observable<void>;
    readonly hasError: boolean;
    readonly hasPageActivity: boolean | undefined;
    getUserActivity: () => UserActivity;
    addFrustration: (frustrationType: FrustrationType) => void;
    readonly startClocks: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: TimeStamp;
    };
    isStopped: () => boolean;
    clone: () => {
        event: MouseEventOnElement;
        stop: (activityEndTime?: TimeStamp) => void;
        stopObservable: Observable<void>;
        readonly hasError: boolean;
        readonly hasPageActivity: boolean | undefined;
        getUserActivity: () => UserActivity;
        addFrustration: (frustrationType: FrustrationType) => void;
        readonly startClocks: {
            relative: import("@datadog/browser-core").RelativeTime;
            timeStamp: TimeStamp;
        };
        isStopped: () => boolean;
        clone: /*elided*/ any;
        validate: (domEvents?: Event[]) => void;
        discard: () => void;
    };
    validate: (domEvents?: Event[]) => void;
    discard: () => void;
};
export declare function finalizeClicks(clicks: Click[], rageClick: Click): void;
export {};
