import type { RumConfiguration } from '../configuration';
import type { LifeCycle } from '../lifeCycle';
import type { PageStateHistory } from '../contexts/pageStateHistory';
export declare function startResourceCollection(lifeCycle: LifeCycle, configuration: RumConfiguration, pageStateHistory: PageStateHistory): {
    startResource: (url: string, options?: import("./trackManualResources").ResourceOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopResource: (url: string, options?: import("./trackManualResources").ResourceStopOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stop: () => void;
};
