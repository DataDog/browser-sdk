import type { Context, ClocksState, BufferedData } from '@datadog/browser-core';
import { Observable } from '@datadog/browser-core';
import type { RumConfiguration } from '../configuration';
import type { LifeCycle } from '../lifeCycle';
export interface ProvidedError {
    startClocks: ClocksState;
    error: unknown;
    context?: Context;
    handlingStack: string;
    componentStack?: string;
}
export declare function startErrorCollection(lifeCycle: LifeCycle, configuration: RumConfiguration, bufferedDataObservable: Observable<BufferedData>): {
    addError: ({ error, handlingStack, componentStack, startClocks, context }: ProvidedError) => void;
};
export declare function doStartErrorCollection(lifeCycle: LifeCycle): {
    addError: ({ error, handlingStack, componentStack, startClocks, context }: ProvidedError) => void;
};
