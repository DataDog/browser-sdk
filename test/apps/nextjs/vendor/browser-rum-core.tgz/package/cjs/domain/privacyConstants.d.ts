export declare const NodePrivacyLevel: {
    readonly IGNORE: "ignore";
    readonly HIDDEN: "hidden";
    readonly ALLOW: "allow";
    readonly MASK: "mask";
    readonly MASK_USER_INPUT: "mask-user-input";
    readonly MASK_UNLESS_ALLOWLISTED: "mask-unless-allowlisted";
};
export type NodePrivacyLevel = (typeof NodePrivacyLevel)[keyof typeof NodePrivacyLevel];
export declare const PRIVACY_ATTR_NAME = "data-dd-privacy";
export declare const PRIVACY_ATTR_VALUE_ALLOW = "allow";
export declare const PRIVACY_ATTR_VALUE_MASK = "mask";
export declare const PRIVACY_ATTR_VALUE_MASK_USER_INPUT = "mask-user-input";
export declare const PRIVACY_ATTR_VALUE_MASK_UNLESS_ALLOWLISTED = "mask-unless-allowlisted";
export declare const PRIVACY_ATTR_VALUE_HIDDEN = "hidden";
export declare const PRIVACY_CLASS_PREFIX = "dd-privacy-";
export declare const CENSORED_STRING_MARK = "***";
export declare const CENSORED_IMG_MARK = "data:image/gif;base64,R0lGODlhAQABAIAAAMLCwgAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==";
export declare const FORM_PRIVATE_TAG_NAMES: {
    [tagName: string]: true;
};
export declare const TEXT_MASKING_CHAR = "x";
export declare function getPrivacySelector(privacyLevel: string): string;
