import type { FlushEvent, Observable, Telemetry } from '@datadog/browser-core';
import type { LifeCycle } from './lifeCycle';
export declare const MEASURES_PERIOD_DURATION: number;
export declare function startCustomerDataTelemetry(telemetry: Telemetry, lifeCycle: LifeCycle, batchFlushObservable: Observable<FlushEvent>): void;
