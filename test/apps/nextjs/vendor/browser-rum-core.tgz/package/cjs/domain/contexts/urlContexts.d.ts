import type { RelativeTime, Observable } from '@datadog/browser-core';
import type { LocationChange } from '../../browser/locationChangeObservable';
import type { LifeCycle } from '../lifeCycle';
import type { Hooks } from '../hooks';
/**
 * We want to attach to an event:
 * - the url corresponding to its start
 * - the referrer corresponding to the previous view url (or document referrer for initial view)
 */
export declare const URL_CONTEXT_TIME_OUT_DELAY: number;
export interface UrlContext {
    url: string;
    referrer: string;
}
export interface UrlContexts {
    findUrl: (startTime?: RelativeTime) => UrlContext | undefined;
    stop: () => void;
}
export declare function startUrlContexts(lifeCycle: LifeCycle, hooks: Hooks, locationChangeObservable: Observable<LocationChange>): {
    findUrl: (startTime?: RelativeTime) => UrlContext | undefined;
    stop: () => void;
};
