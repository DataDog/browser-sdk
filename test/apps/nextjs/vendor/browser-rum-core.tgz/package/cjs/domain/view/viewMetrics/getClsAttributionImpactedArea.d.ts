import type { RumLayoutShiftAttribution } from '../../../browser/performanceObservable';
/**
 * Calculates the total impacted area of a layout shift source
 * This is the sum of the previous and current areas minus their intersection
 */
export declare const getClsAttributionImpactedArea: (source: RumLayoutShiftAttribution) => number;
