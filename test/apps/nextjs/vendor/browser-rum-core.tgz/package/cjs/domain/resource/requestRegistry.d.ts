import type { RumPerformanceResourceTiming } from '../../browser/performanceObservable';
import type { LifeCycle } from '../lifeCycle';
import type { RequestCompleteEvent } from '../requestCollection';
export interface RequestRegistry {
    getMatchingRequest(entry: RumPerformanceResourceTiming): RequestCompleteEvent | undefined;
    stop(): void;
}
export declare const MAX_REQUESTS = 1000;
export declare function createRequestRegistry(lifeCycle: LifeCycle): RequestRegistry;
