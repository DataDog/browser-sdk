import type { TrackingConsentState } from '@datadog/browser-core';
import type { Hooks } from '../hooks';
export declare function startTrackingConsentContext(hooks: Hooks, trackingConsentState: TrackingConsentState): void;
