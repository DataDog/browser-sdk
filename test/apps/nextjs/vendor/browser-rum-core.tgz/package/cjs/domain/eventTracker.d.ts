import type { ClocksState, Duration, RelativeTime, ValueHistoryEntry } from '@datadog/browser-core';
import type { RumActionEvent, RumErrorEvent, RumLongTaskEvent, RumResourceEvent } from '../rumEvent.types';
import type { LifeCycle } from './lifeCycle';
import type { EventCounts } from './trackEventCounts';
import { trackEventCounts } from './trackEventCounts';
export declare const EVENT_CONTEXT_TIME_OUT_DELAY: number;
type BaseTrackedEvent<TData = object> = TData & {
    id: string;
    startClocks: ClocksState;
    counts?: EventCounts;
};
export type StoppedEvent<TData> = BaseTrackedEvent<TData> & {
    duration: Duration;
};
export type DiscardedEvent<TData> = BaseTrackedEvent<TData>;
export interface StartOptions {
    isChildEvent?: (id: string) => (event: RumActionEvent | RumErrorEvent | RumLongTaskEvent | RumResourceEvent) => boolean;
}
export interface EventTracker<TData> {
    start: (key: string, startClocks: ClocksState, data: TData, options?: StartOptions) => TrackedEventData<TData>;
    stop: (key: string, stopClocks: ClocksState, data?: Partial<TData>) => StoppedEvent<TData> | undefined;
    discard: (key: string) => DiscardedEvent<TData> | undefined;
    getCounts: (key: string) => EventCounts | undefined;
    findId: (startTime?: RelativeTime) => string[];
    stopAll: () => void;
}
export interface TrackedEventData<TData> {
    id: string;
    key: string;
    startClocks: ClocksState;
    data: TData;
    historyEntry: ValueHistoryEntry<string>;
    eventCounts?: ReturnType<typeof trackEventCounts>;
}
export declare function startEventTracker<TData>(lifeCycle: LifeCycle): EventTracker<TData>;
export {};
