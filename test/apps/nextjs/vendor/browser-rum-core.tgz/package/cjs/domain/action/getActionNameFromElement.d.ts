import { NodePrivacyLevel } from '../privacyConstants';
import type { RumConfiguration } from '../configuration';
import type { ActionName } from './actionNameConstants';
export declare function getActionNameFromElement(element: Element, rumConfiguration: RumConfiguration, nodePrivacyLevel?: NodePrivacyLevel): ActionName;
