import { noop } from '@datadog/browser-core';
import type { Duration, RelativeTime } from '@datadog/browser-core';
import type { RumConfiguration } from '../../configuration';
import type { RumRect } from '../../../rumEvent.types';
export interface CumulativeLayoutShift {
    value: number;
    targetSelector?: string;
    time?: Duration;
    previousRect?: RumRect;
    currentRect?: RumRect;
    devicePixelRatio?: number;
}
/**
 * Track the cumulative layout shifts (CLS).
 * Layout shifts are grouped into session windows.
 * The minimum gap between session windows is 1 second.
 * The maximum duration of a session window is 5 second.
 * The session window layout shift value is the sum of layout shifts inside it.
 * The CLS value is the max of session windows values.
 *
 * This yields a new value whenever the CLS value is updated (a higher session window value is computed).
 *
 * See isLayoutShiftSupported to check for browser support.
 *
 * Documentation:
 * https://web.dev/cls/
 * https://web.dev/evolving-cls/
 * Reference implementation: https://github.com/GoogleChrome/web-vitals/blob/master/src/getCLS.ts
 */
export declare function trackCumulativeLayoutShift(configuration: RumConfiguration, viewStart: RelativeTime, callback: (cumulativeLayoutShift: CumulativeLayoutShift) => void): {
    stop: typeof noop;
};
export declare const MAX_WINDOW_DURATION: number;
/**
 * Check whether `layout-shift` is supported by the browser.
 */
export declare function isLayoutShiftSupported(): boolean;
