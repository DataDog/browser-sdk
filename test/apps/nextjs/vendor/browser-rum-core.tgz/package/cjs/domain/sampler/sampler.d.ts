export declare function isSampled(sessionId: string, sampleRate: number): boolean;
export declare function resetSampleDecisionCache(): void;
/**
 * Perform sampling using the Knuth factor method. This method offer consistent sampling result
 * based on the provided identifier.
 *
 * @param identifier - The identifier to use for sampling.
 * @param sampleRate - The sample rate in percentage between 0 and 100.
 */
export declare function sampleUsingKnuthFactor(identifier: bigint, sampleRate: number): boolean;
