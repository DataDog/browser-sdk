/**
 * Terminology inspired from https://www.rfc-editor.org/rfc/rfc9535.html
 *
 * jsonpath-query      = segment*
 * segment             = .name-shorthand / bracketed-selection
 * bracketed-selection = ['name-selector'] / ["name-selector"] / [index-selector]
 *
 * Useful references:
 * - https://goessner.net/articles/JsonPath/
 * - https://jsonpath.com/
 * - https://github.com/jsonpath-standard
 */
/**
 * Extract selectors from a simple JSON path expression, return [] for an invalid path
 *
 * Supports:
 * - Dot notation: `foo.bar.baz`
 * - Bracket notation: `['foo']["bar"]`
 * - Array indices: `items[0]`, `data['users'][1]`
 *
 * Examples:
 * parseJsonPath("['foo'].bar[12]")
 * => ['foo', 'bar', '12']
 *
 * parseJsonPath("['foo")
 * => []
 */
export declare function parseJsonPath(path: string): string[];
