import type { Duration, RelativeTime } from '@datadog/browser-core';
import type { RumConfiguration } from '../../configuration';
import type { FirstHidden } from './trackFirstHidden';
export declare const FCP_MAXIMUM_DELAY: number;
export declare function trackFirstContentfulPaint(configuration: RumConfiguration, firstHidden: FirstHidden, callback: (fcpTiming: RelativeTime) => void): {
    stop: () => void;
};
/**
 * Measure the First Contentful Paint after a BFCache restoration.
 * The DOM is restored synchronously, so we approximate the FCP with the first frame
 * rendered just after the pageshow event, using two nested requestAnimationFrame calls.
 */
export declare function trackRestoredFirstContentfulPaint(viewStartRelative: RelativeTime, callback: (fcp: Duration) => void): void;
