import type { ClocksState, Duration } from '@datadog/browser-core';
import type { LifeCycle } from '../lifeCycle';
import { VitalType } from '../../rawRumEvent.types';
import type { PageStateHistory } from '../contexts/pageStateHistory';
/**
 * Vital options
 */
export interface VitalOptions {
    /**
     * Vital context
     */
    context?: any;
    /**
     * Vital description
     */
    description?: string;
}
/**
 * Duration vital options
 */
export interface DurationVitalOptions extends VitalOptions {
}
export interface FeatureOperationOptions extends VitalOptions {
    operationKey?: string;
}
export type FailureReason = 'error' | 'abandoned' | 'other';
/**
 * Add duration vital options
 */
export interface AddDurationVitalOptions extends DurationVitalOptions {
    /**
     * Vital start time, expects a UNIX timestamp in milliseconds (the number of milliseconds since January 1, 1970)
     */
    startTime: number;
    /**
     * Vital duration, expects a duration in milliseconds
     */
    duration: number;
}
export interface DurationVitalReference {
    __dd_vital_reference: true;
}
export interface DurationVitalStart extends DurationVitalOptions {
    id: string;
    name: string;
    startClocks: ClocksState;
    handlingStack?: string;
}
interface BaseVital extends VitalOptions {
    name: string;
    startClocks: ClocksState;
    handlingStack?: string;
}
export interface DurationVital extends BaseVital {
    id: string;
    type: typeof VitalType.DURATION;
    duration: Duration;
}
export interface OperationStepVital extends BaseVital {
    type: typeof VitalType.OPERATION_STEP;
    stepType: 'start' | 'end';
    operationKey?: string;
    failureReason?: string;
}
export interface CustomVitalsState {
    vitalsByName: Map<string, DurationVitalStart>;
    vitalsByReference: WeakMap<DurationVitalReference, DurationVitalStart>;
}
export declare function createCustomVitalsState(): {
    vitalsByName: Map<string, DurationVitalStart>;
    vitalsByReference: WeakMap<DurationVitalReference, DurationVitalStart>;
};
export declare function startVitalCollection(lifeCycle: LifeCycle, pageStateHistory: PageStateHistory, customVitalsState: CustomVitalsState): {
    addOperationStepVital: (name: string, stepType: "start" | "end", options?: FeatureOperationOptions & {
        handlingStack?: string;
    }, failureReason?: FailureReason) => void;
    addDurationVital: (vital: DurationVital) => void;
    startDurationVital: (name: string, options?: DurationVitalOptions & {
        handlingStack?: string;
    }) => DurationVitalReference;
    stopDurationVital: (nameOrRef: string | DurationVitalReference, options?: DurationVitalOptions) => void;
};
export declare function startDurationVital({ vitalsByName, vitalsByReference }: CustomVitalsState, name: string, options?: DurationVitalOptions & {
    handlingStack?: string;
}): DurationVitalReference;
export declare function stopDurationVital(stopCallback: (vital: DurationVital) => void, { vitalsByName, vitalsByReference }: CustomVitalsState, nameOrRef: string | DurationVitalReference, options?: DurationVitalOptions): void;
export {};
