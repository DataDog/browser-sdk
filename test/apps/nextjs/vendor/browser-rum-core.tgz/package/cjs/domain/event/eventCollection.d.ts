import type { Context, Duration, RelativeTime } from '@datadog/browser-core';
import type { RumEventDomainContext } from '../../domainContext.types';
import type { LifeCycle } from '../lifeCycle';
import type { RawRumActionEvent, RawRumErrorEvent, RawRumLongAnimationFrameEvent, RawRumLongTaskEvent, RawRumResourceEvent, RawRumVitalEvent } from '../../rawRumEvent.types';
export type AllowedRawRumEvent = (RawRumErrorEvent | RawRumResourceEvent | RawRumLongTaskEvent | RawRumLongAnimationFrameEvent | RawRumActionEvent | RawRumVitalEvent) & {
    context?: Context;
};
export declare function startEventCollection(lifeCycle: LifeCycle): {
    addEvent: (startTime: RelativeTime, event: AllowedRawRumEvent, domainContext: RumEventDomainContext, duration?: Duration) => void;
};
