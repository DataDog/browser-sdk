import type { RumSessionManager } from '../rumSessionManager';
import type { RecorderApi } from '../../boot/rumPublicApi';
import type { Hooks } from '../hooks';
import type { ViewHistory } from './viewHistory';
export declare function startSessionContext(hooks: Hooks, sessionManager: RumSessionManager, recorderApi: RecorderApi, viewHistory: ViewHistory): void;
