import type { ClocksState, Context, Duration } from '@datadog/browser-core';
import type { ActionType, FrustrationType } from '../../rawRumEvent.types';
import type { EventCounts } from '../trackEventCounts';
import type { LifeCycle } from '../lifeCycle';
export type ActionCounts = EventCounts;
export interface ActionOptions {
    /**
     * Action Type
     *
     * @default 'custom'
     */
    type?: ActionType;
    /**
     * Action context
     */
    context?: any;
    /**
     * Action key
     */
    actionKey?: string;
}
export interface ManualAction {
    id: string;
    type: ActionType;
    name: string;
    startClocks: ClocksState;
    duration?: Duration;
    context?: Context;
    handlingStack?: string;
    counts?: ActionCounts;
    frustrationTypes: FrustrationType[];
}
export interface ActionEventData {
    name: string;
    type?: ActionType;
    context?: Context;
}
export declare function trackManualActions(lifeCycle: LifeCycle, onManualActionCompleted: (action: ManualAction) => void): {
    addAction: (action: Omit<ManualAction, "id" | "duration" | "counts" | "frustrationTypes">) => void;
    startAction: (name: string, options?: ActionOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopAction: (name: string, options?: ActionOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    findActionId: (startTime?: import("@datadog/browser-core").RelativeTime) => string[];
    stop: () => void;
};
