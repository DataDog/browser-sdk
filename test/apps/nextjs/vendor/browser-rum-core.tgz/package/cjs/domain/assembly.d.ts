import type { RawError } from '@datadog/browser-core';
import type { LifeCycle } from './lifeCycle';
import type { RumConfiguration } from './configuration';
import type { Hooks } from './hooks';
export declare function startRumAssembly(configuration: RumConfiguration, lifeCycle: LifeCycle, hooks: Hooks, reportError: (error: RawError) => void, eventRateLimit?: number): void;
