import type { Observable } from '@datadog/browser-core';
import type { RecorderApi } from '../../boot/rumPublicApi';
import type { LifeCycle } from '../lifeCycle';
import type { LocationChange } from '../../browser/locationChangeObservable';
import type { RumConfiguration } from '../configuration';
import type { ViewHistory } from '../contexts/viewHistory';
import type { Hooks } from '../hooks';
import type { RumMutationRecord } from '../../browser/domMutationObservable';
import type { ViewOptions } from './trackViews';
export declare function startViewCollection(lifeCycle: LifeCycle, hooks: Hooks, configuration: RumConfiguration, domMutationObservable: Observable<RumMutationRecord[]>, pageOpenObservable: Observable<void>, locationChangeObservable: Observable<LocationChange>, recorderApi: RecorderApi, viewHistory: ViewHistory, initialViewOptions?: ViewOptions): {
    addTiming: (name: string, time?: import("@datadog/browser-core").RelativeTime | import("@datadog/browser-core").TimeStamp) => void;
    setLoadingTime: (callTimestamp?: import("@datadog/browser-core").TimeStamp) => void;
    startView: (options?: ViewOptions, startClocks?: import("@datadog/browser-core").ClocksState) => void;
    setViewContext: (context: import("@datadog/browser-core").Context) => void;
    setViewContextProperty: (key: string, value: import("@datadog/browser-core").ContextValue) => void;
    setViewName: (name: string) => void;
    getViewContext: () => import("@datadog/browser-core").Context;
    stop: () => void;
};
