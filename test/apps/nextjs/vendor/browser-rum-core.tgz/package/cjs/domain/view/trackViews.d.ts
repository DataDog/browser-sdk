import type { Duration, ClocksState, TimeStamp, RelativeTime, Context, ContextValue } from '@datadog/browser-core';
import { Observable } from '@datadog/browser-core';
import type { ViewCustomTimings } from '../../rawRumEvent.types';
import { ViewLoadingType } from '../../rawRumEvent.types';
import type { LifeCycle } from '../lifeCycle';
import type { EventCounts } from '../trackEventCounts';
import type { LocationChange } from '../../browser/locationChangeObservable';
import type { RumConfiguration, RumInitConfiguration } from '../configuration';
import type { RumMutationRecord } from '../../browser/domMutationObservable';
import type { InitialViewMetrics } from './viewMetrics/trackInitialViewMetrics';
import type { CommonViewMetrics } from './viewMetrics/trackCommonViewMetrics';
export interface ViewEvent {
    id: string;
    name?: string;
    service?: string;
    version?: string;
    context?: Context;
    location: Readonly<Location>;
    handlingStack?: string;
    commonViewMetrics: CommonViewMetrics;
    initialViewMetrics: InitialViewMetrics;
    customTimings: ViewCustomTimings;
    eventCounts: EventCounts;
    documentVersion: number;
    startClocks: ClocksState;
    duration: Duration;
    isActive: boolean;
    sessionIsActive: boolean;
    loadingType: ViewLoadingType;
}
export interface ViewCreatedEvent {
    id: string;
    name?: string;
    service?: string;
    version?: string;
    context?: Context;
    startClocks: ClocksState;
    url?: string;
}
export interface BeforeViewUpdateEvent {
    id: string;
    name?: string;
    context?: Context;
    startClocks: ClocksState;
    sessionIsActive: boolean;
}
export interface ViewEndedEvent {
    endClocks: ClocksState;
}
export declare const THROTTLE_VIEW_UPDATE_PERIOD = 3000;
export declare const SESSION_KEEP_ALIVE_INTERVAL: number;
export declare const KEEP_TRACKING_AFTER_VIEW_DELAY: number;
export interface ViewOptions {
    name?: string;
    service?: RumInitConfiguration['service'];
    version?: RumInitConfiguration['version'];
    context?: Context;
    handlingStack?: string;
    url?: string;
}
export declare function trackViews(lifeCycle: LifeCycle, domMutationObservable: Observable<RumMutationRecord[]>, windowOpenObservable: Observable<void>, configuration: RumConfiguration, locationChangeObservable: Observable<LocationChange>, areViewsTrackedAutomatically: boolean, initialViewOptions?: ViewOptions): {
    addTiming: (name: string, time?: RelativeTime | TimeStamp) => void;
    setLoadingTime: (callTimestamp?: TimeStamp) => void;
    startView: (options?: ViewOptions, startClocks?: ClocksState) => void;
    setViewContext: (context: Context) => void;
    setViewContextProperty: (key: string, value: ContextValue) => void;
    setViewName: (name: string) => void;
    getViewContext: () => Context;
    stop: () => void;
};
