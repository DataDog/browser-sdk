import type { ClocksState, RelativeTime } from '@datadog/browser-core';
import type { RumConfiguration } from '../../configuration';
export type FirstHidden = ReturnType<typeof trackFirstHidden>;
export interface Options {
    viewStart: ClocksState;
}
export declare function trackFirstHidden(configuration: RumConfiguration, viewStart: ClocksState, eventTarget?: Window): {
    readonly timeStamp: RelativeTime;
    stop: () => void;
};
