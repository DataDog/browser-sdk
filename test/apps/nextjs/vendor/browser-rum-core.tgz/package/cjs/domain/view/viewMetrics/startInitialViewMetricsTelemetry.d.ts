import type { Telemetry } from '@datadog/browser-core';
import { noop } from '@datadog/browser-core';
import type { LifeCycle } from '../../lifeCycle';
export declare function startInitialViewMetricsTelemetry(lifeCycle: LifeCycle, telemetry: Telemetry): {
    stop: typeof noop;
};
