import type { ClocksState, Duration, Observable, RelativeTime, TimeStamp } from '@datadog/browser-core';
import type { ViewLoadingType } from '../../../rawRumEvent.types';
import type { RumConfiguration } from '../../configuration';
import type { LifeCycle } from '../../lifeCycle';
import type { RumMutationRecord } from '../../../browser/domMutationObservable';
import type { CumulativeLayoutShift } from './trackCumulativeLayoutShift';
import type { InteractionToNextPaint } from './trackInteractionToNextPaint';
import type { ScrollMetrics } from './trackScrollMetrics';
export interface CommonViewMetrics {
    loadingTime?: Duration;
    cumulativeLayoutShift?: CumulativeLayoutShift;
    interactionToNextPaint?: InteractionToNextPaint;
    scroll?: ScrollMetrics;
}
export declare function trackCommonViewMetrics(lifeCycle: LifeCycle, domMutationObservable: Observable<RumMutationRecord[]>, windowOpenObservable: Observable<void>, configuration: RumConfiguration, scheduleViewUpdate: () => void, loadingType: ViewLoadingType, viewStart: ClocksState): {
    stop: () => void;
    stopINPTracking: () => void;
    setLoadEvent: (loadEvent: Duration) => void;
    setViewEnd: (viewEndTime: RelativeTime) => void;
    getCommonViewMetrics: () => CommonViewMetrics;
    setLoadingTime: (callTimestamp?: TimeStamp) => void;
};
