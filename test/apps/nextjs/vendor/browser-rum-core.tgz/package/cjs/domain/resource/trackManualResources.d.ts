import type { Context, ResourceType } from '@datadog/browser-core';
import type { LifeCycle } from '../lifeCycle';
import type { EventTracker } from '../eventTracker';
export interface ResourceOptions {
    /**
     * Resource type
     *
     * @default 'other'
     */
    type?: ResourceType;
    /**
     * HTTP method
     */
    method?: string;
    /**
     * Resource context
     */
    context?: Context;
    /**
     * Resource key
     */
    resourceKey?: string;
}
export interface ResourceStopOptions {
    /**
     * Resource type
     */
    type?: ResourceType;
    /**
     * HTTP status code
     */
    statusCode?: number;
    /**
     * Resource size in bytes
     */
    size?: number;
    /**
     * Resource context
     */
    context?: Context;
    /**
     * Resource key
     */
    resourceKey?: string;
}
export interface ManualResourceData {
    url: string;
    type?: ResourceType;
    method?: string;
    context?: Context;
}
export declare function trackManualResources(lifeCycle: LifeCycle, resourceTracker: EventTracker<ManualResourceData>): {
    startResource: (url: string, options?: ResourceOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopResource: (url: string, options?: ResourceStopOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
};
