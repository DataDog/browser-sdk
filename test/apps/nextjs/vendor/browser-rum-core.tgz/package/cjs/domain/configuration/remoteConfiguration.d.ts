import type { createContextManager, Context } from '@datadog/browser-core';
import type { RumInitConfiguration } from './configuration';
import type { RumSdkConfig, DynamicOption } from './remoteConfiguration.types';
export type RemoteConfiguration = RumSdkConfig;
export type RumRemoteConfiguration = Exclude<RemoteConfiguration['rum'], undefined>;
interface SupportedContextManagers {
    user: ReturnType<typeof createContextManager>;
    context: ReturnType<typeof createContextManager>;
}
export interface RemoteConfigurationMetrics extends Context {
    fetch: RemoteConfigurationMetricCounters;
    cookie?: RemoteConfigurationMetricCounters;
    dom?: RemoteConfigurationMetricCounters;
    js?: RemoteConfigurationMetricCounters;
    localStorage?: RemoteConfigurationMetricCounters;
}
interface RemoteConfigurationMetricCounters {
    success?: number;
    missing?: number;
    failure?: number;
    [key: string]: number | undefined;
}
export declare function fetchAndApplyRemoteConfiguration(initConfiguration: RumInitConfiguration, supportedContextManagers: SupportedContextManagers): Promise<RumInitConfiguration | undefined>;
export declare function applyRemoteConfiguration(initConfiguration: RumInitConfiguration, rumRemoteConfiguration: RumRemoteConfiguration & {
    [key: string]: unknown;
}, supportedContextManagers: SupportedContextManagers, metrics: ReturnType<typeof initMetrics>): RumInitConfiguration;
export declare function initMetrics(): {
    get: () => RemoteConfigurationMetrics;
    increment: (metricName: "fetch" | DynamicOption["strategy"], type: keyof RemoteConfigurationMetricCounters) => void;
};
type FetchRemoteConfigurationResult = {
    ok: true;
    value: RumRemoteConfiguration;
} | {
    ok: false;
    error: Error;
};
export declare function fetchRemoteConfiguration(configuration: RumInitConfiguration): Promise<FetchRemoteConfigurationResult>;
export declare function buildEndpoint(configuration: RumInitConfiguration): string;
export {};
