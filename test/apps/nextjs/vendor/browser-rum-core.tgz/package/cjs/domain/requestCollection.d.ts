import type { Duration, XhrCompleteContext, XhrStartContext, ClocksState, FetchStartContext, FetchResolveContext, ContextManager } from '@datadog/browser-core';
import { RequestType } from '@datadog/browser-core';
import type { RumSessionManager } from '..';
import type { RumConfiguration } from './configuration';
import type { LifeCycle } from './lifeCycle';
import type { Tracer } from './tracing/tracer';
import type { SpanIdentifier, TraceIdentifier } from './tracing/identifier';
export interface CustomContext {
    requestIndex: number;
    spanId?: SpanIdentifier;
    traceId?: TraceIdentifier;
    traceSampled?: boolean;
}
export interface RumFetchStartContext extends FetchStartContext, CustomContext {
}
export interface RumFetchResolveContext extends FetchResolveContext, CustomContext {
}
export interface RumXhrStartContext extends XhrStartContext, CustomContext {
}
export interface RumXhrCompleteContext extends XhrCompleteContext, CustomContext {
}
export interface RequestStartEvent {
    requestIndex: number;
    url: string;
}
export interface RequestCompleteEvent {
    requestIndex: number;
    type: RequestType;
    method: string;
    url: string;
    status: number;
    responseType?: string;
    startClocks: ClocksState;
    duration: Duration;
    spanId?: SpanIdentifier;
    traceId?: TraceIdentifier;
    traceSampled?: boolean;
    xhr?: XMLHttpRequest;
    response?: Response;
    input?: unknown;
    init?: RequestInit;
    error?: Error;
    isAborted: boolean;
    isAbortedOnStart: boolean;
    handlingStack?: string;
    requestBody?: unknown;
    responseBody?: string;
}
export declare function startRequestCollection(lifeCycle: LifeCycle, configuration: RumConfiguration, sessionManager: RumSessionManager, userContext: ContextManager, accountContext: ContextManager): void;
export declare function trackXhr(lifeCycle: LifeCycle, configuration: RumConfiguration, tracer: Tracer): {
    stop: () => void;
};
export declare function trackFetch(lifeCycle: LifeCycle, configuration: RumConfiguration, tracer: Tracer): {
    stop: () => void;
};
