import type { RumActionEvent, RumErrorEvent, RumLongTaskEvent, RumResourceEvent } from '../../rumEvent.types';
export declare function isActionChildEvent(id: string): (event: RumActionEvent | RumErrorEvent | RumLongTaskEvent | RumResourceEvent) => boolean;
