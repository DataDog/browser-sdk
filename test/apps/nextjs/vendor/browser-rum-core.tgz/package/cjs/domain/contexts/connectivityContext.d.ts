import type { Hooks } from '../hooks';
export declare function startConnectivityContext(hooks: Hooks): void;
