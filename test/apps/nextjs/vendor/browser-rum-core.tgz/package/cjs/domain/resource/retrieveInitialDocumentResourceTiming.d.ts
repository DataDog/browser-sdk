import type { RumPerformanceResourceTiming } from '../../browser/performanceObservable';
import type { RumConfiguration } from '../configuration';
export declare function retrieveInitialDocumentResourceTiming(configuration: RumConfiguration, callback: (timing: RumPerformanceResourceTiming) => void): void;
