import type { ClocksState, Duration, Observable } from '@datadog/browser-core';
import type { RumConfiguration } from '../../configuration';
import type { LifeCycle } from '../../lifeCycle';
import { ViewLoadingType } from '../../../rawRumEvent.types';
import type { RumMutationRecord } from '../../../browser/domMutationObservable';
/**
 * For non-initial views (such as route changes or BFCache restores), the regular load event does not fire
 * In these cases, trackLoadingTime can only emit a loadingTime  if waitPageActivityEnd detects some post-restore activity.
 * If nothing happens after the view starts,no candidate is recorded and loadingTime stays undefined.
 */
export declare function trackLoadingTime(lifeCycle: LifeCycle, domMutationObservable: Observable<RumMutationRecord[]>, windowOpenObservable: Observable<void>, configuration: RumConfiguration, loadType: ViewLoadingType, viewStart: ClocksState, callback: (loadingTime: Duration) => void): {
    stop: () => void;
    setLoadEvent: (loadEvent: Duration) => void;
};
