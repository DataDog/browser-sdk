import type { ClocksState, Context, Duration, PageMayExitEvent, RawError } from '@datadog/browser-core';
import { AbstractLifeCycle } from '@datadog/browser-core';
import type { RumEventDomainContext } from '../domainContext.types';
import type { RawRumEvent, AssembledRumEvent } from '../rawRumEvent.types';
import type { RequestCompleteEvent, RequestStartEvent } from './requestCollection';
import type { AutoAction } from './action/actionCollection';
import type { ViewEvent, ViewCreatedEvent, ViewEndedEvent, BeforeViewUpdateEvent } from './view/trackViews';
import type { DurationVitalStart } from './vital/vitalCollection';
import type { TrackedEventData } from './eventTracker';
import type { ActionEventData } from './action/trackManualActions';
export declare const enum LifeCycleEventType {
    AUTO_ACTION_COMPLETED = 0,
    BEFORE_VIEW_CREATED = 1,
    VIEW_CREATED = 2,
    BEFORE_VIEW_UPDATED = 3,
    VIEW_UPDATED = 4,
    VIEW_ENDED = 5,
    AFTER_VIEW_ENDED = 6,
    REQUEST_STARTED = 7,
    REQUEST_COMPLETED = 8,
    SESSION_EXPIRED = 9,
    SESSION_RENEWED = 10,
    PAGE_MAY_EXIT = 11,
    RAW_RUM_EVENT_COLLECTED = 12,
    RUM_EVENT_COLLECTED = 13,
    RAW_ERROR_COLLECTED = 14,
    ACTION_STARTED = 15,
    VITAL_STARTED = 16
}
declare const LifeCycleEventTypeAsConst: {
    ACTION_STARTED: LifeCycleEventType.ACTION_STARTED;
    AUTO_ACTION_COMPLETED: LifeCycleEventType.AUTO_ACTION_COMPLETED;
    BEFORE_VIEW_CREATED: LifeCycleEventType.BEFORE_VIEW_CREATED;
    VIEW_CREATED: LifeCycleEventType.VIEW_CREATED;
    BEFORE_VIEW_UPDATED: LifeCycleEventType.BEFORE_VIEW_UPDATED;
    VIEW_UPDATED: LifeCycleEventType.VIEW_UPDATED;
    VIEW_ENDED: LifeCycleEventType.VIEW_ENDED;
    AFTER_VIEW_ENDED: LifeCycleEventType.AFTER_VIEW_ENDED;
    REQUEST_STARTED: LifeCycleEventType.REQUEST_STARTED;
    REQUEST_COMPLETED: LifeCycleEventType.REQUEST_COMPLETED;
    SESSION_EXPIRED: LifeCycleEventType.SESSION_EXPIRED;
    SESSION_RENEWED: LifeCycleEventType.SESSION_RENEWED;
    PAGE_MAY_EXIT: LifeCycleEventType.PAGE_MAY_EXIT;
    RAW_RUM_EVENT_COLLECTED: LifeCycleEventType.RAW_RUM_EVENT_COLLECTED;
    RUM_EVENT_COLLECTED: LifeCycleEventType.RUM_EVENT_COLLECTED;
    RAW_ERROR_COLLECTED: LifeCycleEventType.RAW_ERROR_COLLECTED;
    VITAL_STARTED: LifeCycleEventType.VITAL_STARTED;
};
export interface LifeCycleEventMap {
    [LifeCycleEventTypeAsConst.ACTION_STARTED]: TrackedEventData<ActionEventData>;
    [LifeCycleEventTypeAsConst.AUTO_ACTION_COMPLETED]: AutoAction;
    [LifeCycleEventTypeAsConst.BEFORE_VIEW_CREATED]: ViewCreatedEvent;
    [LifeCycleEventTypeAsConst.VIEW_CREATED]: ViewCreatedEvent;
    [LifeCycleEventTypeAsConst.BEFORE_VIEW_UPDATED]: BeforeViewUpdateEvent;
    [LifeCycleEventTypeAsConst.VIEW_UPDATED]: ViewEvent;
    [LifeCycleEventTypeAsConst.VIEW_ENDED]: ViewEndedEvent;
    [LifeCycleEventTypeAsConst.AFTER_VIEW_ENDED]: ViewEndedEvent;
    [LifeCycleEventTypeAsConst.REQUEST_STARTED]: RequestStartEvent;
    [LifeCycleEventTypeAsConst.REQUEST_COMPLETED]: RequestCompleteEvent;
    [LifeCycleEventTypeAsConst.SESSION_EXPIRED]: void;
    [LifeCycleEventTypeAsConst.SESSION_RENEWED]: void;
    [LifeCycleEventTypeAsConst.PAGE_MAY_EXIT]: PageMayExitEvent;
    [LifeCycleEventTypeAsConst.RAW_RUM_EVENT_COLLECTED]: RawRumEventCollectedData;
    [LifeCycleEventTypeAsConst.RUM_EVENT_COLLECTED]: AssembledRumEvent;
    [LifeCycleEventTypeAsConst.RAW_ERROR_COLLECTED]: {
        error: RawError;
        customerContext?: Context;
    };
    [LifeCycleEventTypeAsConst.VITAL_STARTED]: DurationVitalStart;
}
export interface RawRumEventCollectedData<E extends RawRumEvent = RawRumEvent> {
    startClocks: ClocksState;
    duration?: Duration;
    rawRumEvent: E;
    domainContext: RumEventDomainContext<E['type']>;
}
export declare const LifeCycle: {
    new (): AbstractLifeCycle<LifeCycleEventMap>;
};
export type LifeCycle = AbstractLifeCycle<LifeCycleEventMap>;
export {};
