import type { Observable, RawError, PageMayExitEvent, Encoder } from '@datadog/browser-core';
import { DeflateEncoderStreamId } from '@datadog/browser-core';
import type { RumConfiguration } from '../domain/configuration';
import type { LifeCycle } from '../domain/lifeCycle';
export declare function startRumBatch(configuration: RumConfiguration, lifeCycle: LifeCycle, reportError: (error: RawError) => void, pageMayExitObservable: Observable<PageMayExitEvent>, sessionExpireObservable: Observable<void>, createEncoder: (streamId: DeflateEncoderStreamId) => Encoder): import("@datadog/browser-core/cjs/transport/batch").Batch;
