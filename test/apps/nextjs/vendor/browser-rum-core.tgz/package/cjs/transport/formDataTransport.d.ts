import type { Encoder, DeflateEncoderStreamId, Context } from '@datadog/browser-core';
import type { RumConfiguration } from '../domain/configuration';
import type { LifeCycle } from '../domain/lifeCycle';
/**
 * transport payload consist of an event and one or more attachments
 */
export interface TransportPayload {
    event: Context;
    [key: string]: Context;
}
export interface Transport<T extends TransportPayload> {
    send: (data: T) => Promise<void>;
}
export declare function createFormDataTransport<T extends TransportPayload>(configuration: RumConfiguration, lifeCycle: LifeCycle, createEncoder: (streamId: DeflateEncoderStreamId) => Encoder, streamId: DeflateEncoderStreamId): {
    send({ event, ...attachments }: T): Promise<void>;
};
