import type { TrackingConsentState, DeflateWorker, Telemetry } from '@datadog/browser-core';
import type { Hooks } from '../domain/hooks';
import type { RumConfiguration } from '../domain/configuration';
import type { ViewOptions } from '../domain/view/trackViews';
import type { CustomVitalsState } from '../domain/vital/vitalCollection';
import type { StartRumResult } from './startRum';
import type { RumPublicApiOptions, Strategy } from './rumPublicApi';
export type DoStartRum = (configuration: RumConfiguration, deflateWorker: DeflateWorker | undefined, initialViewOptions: ViewOptions | undefined, telemetry: Telemetry, hooks: Hooks) => StartRumResult;
export declare function createPreStartStrategy({ ignoreInitIfSyntheticsWillInjectRum, startDeflateWorker }: RumPublicApiOptions, trackingConsentState: TrackingConsentState, customVitalsState: CustomVitalsState, doStartRum: DoStartRum): Strategy;
