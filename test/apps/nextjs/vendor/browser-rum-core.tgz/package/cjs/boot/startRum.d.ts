import type { Observable, RawError, DeflateEncoderStreamId, Encoder, TrackingConsentState, BufferedData, BufferedObservable, Telemetry } from '@datadog/browser-core';
import { LifeCycle } from '../domain/lifeCycle';
import type { RumSessionManager } from '../domain/rumSessionManager';
import type { RumConfiguration } from '../domain/configuration';
import type { ViewOptions } from '../domain/view/trackViews';
import type { CustomVitalsState } from '../domain/vital/vitalCollection';
import type { SdkName } from '../domain/contexts/defaultContext';
import type { Hooks } from '../domain/hooks';
import type { RecorderApi, ProfilerApi } from './rumPublicApi';
export type StartRum = typeof startRum;
export type StartRumResult = ReturnType<StartRum>;
export declare function startRum(configuration: RumConfiguration, recorderApi: RecorderApi, profilerApi: ProfilerApi, initialViewOptions: ViewOptions | undefined, createEncoder: (streamId: DeflateEncoderStreamId) => Encoder, trackingConsentState: TrackingConsentState, customVitalsState: CustomVitalsState, bufferedDataObservable: BufferedObservable<BufferedData>, telemetry: Telemetry, hooks: Hooks, sdkName?: SdkName): {
    lifeCycle: import("@datadog/browser-core").AbstractLifeCycle<import("../domain/lifeCycle").LifeCycleEventMap>;
    session: RumSessionManager;
    stopSession: () => void;
    telemetry: Telemetry;
    stop: () => void;
    hooks: {
        register<K extends import("@datadog/browser-core").HookNames>(hookName: K, callback: import("../domain/hooks").HookCallbackMap[K]): {
            unregister: () => void;
        };
        triggerHook<K extends import("@datadog/browser-core").HookNames>(hookName: K, param: Parameters<import("../domain/hooks").HookCallbackMap[K]>[0]): "DISCARDED" | Exclude<ReturnType<import("../domain/hooks").HookCallbackMap[K]>, "SKIPPED"> | undefined;
    };
    addAction: (action: Omit<import("../domain/action/trackManualActions").ManualAction, "id" | "duration" | "counts" | "frustrationTypes">) => void;
    startAction: (name: string, options?: import("../domain/action/trackManualActions").ActionOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopAction: (name: string, options?: import("../domain/action/trackManualActions").ActionOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    startResource: (url: string, options?: import("../domain/resource/trackManualResources").ResourceOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopResource: (url: string, options?: import("../domain/resource/trackManualResources").ResourceStopOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    addEvent: (startTime: import("@datadog/browser-core").RelativeTime, event: import("../domain/event/eventCollection").AllowedRawRumEvent, domainContext: import("..").RumEventDomainContext, duration?: import("@datadog/browser-core").Duration) => void;
    addError: ({ error, handlingStack, componentStack, startClocks, context }: import("../domain/error/errorCollection").ProvidedError) => void;
    addTiming: (name: string, time?: import("@datadog/browser-core").RelativeTime | import("@datadog/browser-core").TimeStamp) => void;
    setLoadingTime: (callTimestamp?: import("@datadog/browser-core").TimeStamp) => void;
    addFeatureFlagEvaluation: (key: string, value: import("@datadog/browser-core").ContextValue) => void;
    startView: (options?: ViewOptions, startClocks?: import("@datadog/browser-core").ClocksState) => void;
    setViewContext: (context: import("@datadog/browser-core").Context) => void;
    setViewContextProperty: (key: string, value: import("@datadog/browser-core").ContextValue) => void;
    getViewContext: () => import("@datadog/browser-core").Context;
    setViewName: (name: string) => void;
    viewHistory: import("../domain/contexts/viewHistory").ViewHistory;
    getInternalContext: (startTime?: number) => import("@datadog/browser-core").RumInternalContext | undefined;
    startDurationVital: (name: string, options?: import("../domain/vital/vitalCollection").DurationVitalOptions & {
        handlingStack?: string;
    }) => import("../domain/vital/vitalCollection").DurationVitalReference;
    stopDurationVital: (nameOrRef: string | import("../domain/vital/vitalCollection").DurationVitalReference, options?: import("../domain/vital/vitalCollection").DurationVitalOptions) => void;
    addDurationVital: (vital: import("../domain/vital/vitalCollection").DurationVital) => void;
    addOperationStepVital: (name: string, stepType: "start" | "end", options?: import("../domain/vital/vitalCollection").FeatureOperationOptions & {
        handlingStack?: string;
    }, failureReason?: import("../domain/vital/vitalCollection").FailureReason) => void;
    globalContext: {
        getContext: () => import("@datadog/browser-core").Context;
        setContext: (newContext: unknown) => void;
        setContextProperty: (key: string, property: any) => void;
        removeContextProperty: (key: string) => void;
        clearContext: () => void;
        changeObservable: import("@datadog/browser-core").Observable<void>;
    };
    userContext: {
        getContext: () => import("@datadog/browser-core").Context;
        setContext: (newContext: unknown) => void;
        setContextProperty: (key: string, property: any) => void;
        removeContextProperty: (key: string) => void;
        clearContext: () => void;
        changeObservable: import("@datadog/browser-core").Observable<void>;
    };
    accountContext: {
        getContext: () => import("@datadog/browser-core").Context;
        setContext: (newContext: unknown) => void;
        setContextProperty: (key: string, property: any) => void;
        removeContextProperty: (key: string) => void;
        clearContext: () => void;
        changeObservable: import("@datadog/browser-core").Observable<void>;
    };
};
export declare function startRumEventCollection(lifeCycle: LifeCycle, hooks: Hooks, configuration: RumConfiguration, session: RumSessionManager, recorderApi: RecorderApi, initialViewOptions: ViewOptions | undefined, customVitalsState: CustomVitalsState, bufferedDataObservable: Observable<BufferedData>, sdkName: SdkName | undefined, reportError: (error: RawError) => void): {
    addAction: (action: Omit<import("../domain/action/trackManualActions").ManualAction, "id" | "duration" | "counts" | "frustrationTypes">) => void;
    startAction: (name: string, options?: import("../domain/action/trackManualActions").ActionOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopAction: (name: string, options?: import("../domain/action/trackManualActions").ActionOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    startResource: (url: string, options?: import("../domain/resource/trackManualResources").ResourceOptions, startClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    stopResource: (url: string, options?: import("../domain/resource/trackManualResources").ResourceStopOptions, stopClocks?: {
        relative: import("@datadog/browser-core").RelativeTime;
        timeStamp: import("@datadog/browser-core").TimeStamp;
    }) => void;
    addEvent: (startTime: import("@datadog/browser-core").RelativeTime, event: import("../domain/event/eventCollection").AllowedRawRumEvent, domainContext: import("..").RumEventDomainContext, duration?: import("@datadog/browser-core").Duration) => void;
    addError: ({ error, handlingStack, componentStack, startClocks, context }: import("../domain/error/errorCollection").ProvidedError) => void;
    addTiming: (name: string, time?: import("@datadog/browser-core").RelativeTime | import("@datadog/browser-core").TimeStamp) => void;
    setLoadingTime: (callTimestamp?: import("@datadog/browser-core").TimeStamp) => void;
    addFeatureFlagEvaluation: (key: string, value: import("@datadog/browser-core").ContextValue) => void;
    startView: (options?: ViewOptions, startClocks?: import("@datadog/browser-core").ClocksState) => void;
    setViewContext: (context: import("@datadog/browser-core").Context) => void;
    setViewContextProperty: (key: string, value: import("@datadog/browser-core").ContextValue) => void;
    getViewContext: () => import("@datadog/browser-core").Context;
    setViewName: (name: string) => void;
    viewHistory: import("../domain/contexts/viewHistory").ViewHistory;
    getInternalContext: (startTime?: number) => import("@datadog/browser-core").RumInternalContext | undefined;
    startDurationVital: (name: string, options?: import("../domain/vital/vitalCollection").DurationVitalOptions & {
        handlingStack?: string;
    }) => import("../domain/vital/vitalCollection").DurationVitalReference;
    stopDurationVital: (nameOrRef: string | import("../domain/vital/vitalCollection").DurationVitalReference, options?: import("../domain/vital/vitalCollection").DurationVitalOptions) => void;
    addDurationVital: (vital: import("../domain/vital/vitalCollection").DurationVital) => void;
    addOperationStepVital: (name: string, stepType: "start" | "end", options?: import("../domain/vital/vitalCollection").FeatureOperationOptions & {
        handlingStack?: string;
    }, failureReason?: import("../domain/vital/vitalCollection").FailureReason) => void;
    globalContext: {
        getContext: () => import("@datadog/browser-core").Context;
        setContext: (newContext: unknown) => void;
        setContextProperty: (key: string, property: any) => void;
        removeContextProperty: (key: string) => void;
        clearContext: () => void;
        changeObservable: import("@datadog/browser-core").Observable<void>;
    };
    userContext: {
        getContext: () => import("@datadog/browser-core").Context;
        setContext: (newContext: unknown) => void;
        setContextProperty: (key: string, property: any) => void;
        removeContextProperty: (key: string) => void;
        clearContext: () => void;
        changeObservable: import("@datadog/browser-core").Observable<void>;
    };
    accountContext: {
        getContext: () => import("@datadog/browser-core").Context;
        setContext: (newContext: unknown) => void;
        setContextProperty: (key: string, property: any) => void;
        removeContextProperty: (key: string) => void;
        clearContext: () => void;
        changeObservable: import("@datadog/browser-core").Observable<void>;
    };
    stop: () => void;
};
