import { mockable, runOnReadyState } from '@datadog/browser-core'
import { RumPerformanceEntryType } from '../../browser/performanceObservable'
import type { RumPerformanceResourceTiming } from '../../browser/performanceObservable'
import type { RumConfiguration } from '../configuration'
import { getDocumentTraceId } from '../tracing/getDocumentTraceId'
import { getNavigationEntry } from '../../browser/performanceUtils'
import { FAKE_INITIAL_DOCUMENT } from './resourceUtils'

export function retrieveInitialDocumentResourceTiming(
  configuration: RumConfiguration,
  callback: (timing: RumPerformanceResourceTiming) => void
) {
  runOnReadyState(configuration, 'interactive', () => {
    const navigationEntry = mockable(getNavigationEntry)()
    const documentTraceData = getDocumentTraceId(document)
    const entry: RumPerformanceResourceTiming = Object.assign(navigationEntry.toJSON(), {
      entryType: RumPerformanceEntryType.RESOURCE as const,
      initiatorType: FAKE_INITIAL_DOCUMENT,
      // The ResourceTiming duration entry should be `responseEnd - startTime`. With
      // NavigationTiming entries, `startTime` is always 0, so set it to `responseEnd`.
      duration: navigationEntry.responseEnd,
      traceId: documentTraceData?.traceId,
      spanId: documentTraceData?.spanId,
      toJSON: () => ({ ...entry, toJSON: undefined }),
    })
    callback(entry)
  })
}
